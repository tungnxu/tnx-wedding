export const environment = {
    production: true,
    layout: '',
    apiUrl: 'https://api.vinfastauto.com/msp/internal',
};
