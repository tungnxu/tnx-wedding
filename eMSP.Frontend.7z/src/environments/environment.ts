export const environment = {
    production: false,
    layout: '',
    // apiUrl: 'https://vf-api.southeastasia.cloudapp.azure.com/emsp-dev',
    apiUrl: 'https://vf-api.southeastasia.cloudapp.azure.com/msp-dev/internal',
};
