export const environment = {
    production: false,
    layout: '',
    apiUrl: 'https://vf-api.southeastasia.cloudapp.azure.com/msp-uat/internal',
};
