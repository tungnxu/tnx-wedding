import { Component, Injectable, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
    selector: '',
    template: '',
})
export abstract class BaseComponent implements OnDestroy {
    public destroyed$ = new Subject<void>();

    ngOnDestroy(): void {
        this.destroyed$.next();
    }
}
