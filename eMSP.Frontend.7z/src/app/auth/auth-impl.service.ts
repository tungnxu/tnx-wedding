import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { from, Observable } from 'rxjs';
import { Account, AuthResponse } from 'msal';
import * as moment from 'moment';
import { AuthService } from '../core/services/auth.service';
import { ExecutionContext } from '../shared/models/execution-context';
import { authActions } from '../root-store/auth/auth.actions';
import { State } from '../root-store/state';
import { Store } from '@ngrx/store';

@Injectable({
    providedIn: 'root',
})
export class AuthImplService extends AuthService {
    constructor(private readonly msalService: MsalService, private readonly store: Store<State>) {
        super();
    }

    public login(): Observable<ExecutionContext> {
        return from(
            this.msalService.loginPopup({
                forceRefresh: true,
                extraScopesToConsent: ['user.read', 'openid', 'profile'],
            })
        ).pipe(
            map((resp: AuthResponse) => {
                if (resp && resp.account) {
                    return new ExecutionContext(
                        resp.account.userName,
                        resp.account.accountIdentifier,
                        resp.account.name,
                        resp.idToken.rawIdToken,
                        resp.expiresOn
                    );
                }
                return null;
            })
        );
    }

    public logout(): void {
        this.store.dispatch(authActions.logoutSuccessedAction());
        this.msalService.logout();
    }

    // public getCurrentUser(): ExecutionContext {
    //     const user = this.msalService.getAccount();
    //     return new ExecutionContext(user.userName, user.accountIdentifier, user.name, user.idToken.rawIdToken);
    // }
}
