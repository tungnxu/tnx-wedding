import { UiStateService } from '../../core/services/ui-state.service';
import { Component, OnInit } from '@angular/core';
import { AuthStateService } from '../../core/services/auth-state.service';

@Component({
    templateUrl: 'login-page.component.html',
})
export class LoginPageComponent implements OnInit {
    constructor(private readonly authStateService: AuthStateService, private readonly uiStateService: UiStateService) {}

    ngOnInit(): void {}

    public login(): void {
        this.authStateService.doLogin();
        this.uiStateService.toggleShowLoading(true);
    }

    public checkIsIE(): boolean {
        if (navigator.userAgent.search(/(?:Edge|MSIE|Trident\/.*; rv:)/) !== -1) {
            return true;
        }
        return false;
    }
}
