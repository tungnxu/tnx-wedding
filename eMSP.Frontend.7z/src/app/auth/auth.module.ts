import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthRoutingModule } from './auth-routing.module';
import { MsalModule, MsalInterceptor, MsalService } from '@azure/msal-angular';
import { AuthService } from '../core/services/auth.service';
import { AuthImplService } from './auth-impl.service';
import { HttpClientModule } from '@angular/common/http';
import { LoginPageComponent } from './login-page/login-page.component';

const currentHost = window.location.host.toLocaleLowerCase();
const redirectUri = window.location.protocol + '//' + currentHost;

const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

@NgModule({
  declarations: [
    LoginPageComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    MsalModule.forRoot(
      {
          auth: {
              clientId: '52c0457c-4a6a-4975-a6e6-8fc435944d18',
              authority: 'https://login.microsoftonline.com/ed6a2939-d153-4f92-94f8-3d790d96c9f8',
              redirectUri,
          },
          cache: {
              cacheLocation: 'localStorage',
              storeAuthStateInCookie: isIE,
          },
      },
      {
          popUp: !isIE,
          consentScopes: ['user.read', 'openid', 'profile'],
          unprotectedResources: ['assets'],
          extraQueryParameters: {},
      }
  ),

  ],
  providers: [
    MsalService,
    {
      provide: AuthService,
      useClass: AuthImplService,
    },
  ],

})
export class AuthModule { }
