import { UiStateService } from './core/services/ui-state.service';
import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from './base.component';
import { Observable } from 'rxjs';
import { AppConfigurations } from './shared/models/abstractions/app-configurations';
import { AppConfigurationStateService } from './core/services/app-configuration-state.service';

@Component({
    selector: 'emsp-app',
    templateUrl: './app.component.html',
})
export class AppComponent extends BaseComponent implements OnInit {
    public showLoading$: Observable<boolean>;

    constructor(private readonly router: Router, private readonly uiStateService: UiStateService) {
        super();
    }

    ngOnInit(): void {
        this.showLoading$ = this.uiStateService.showLoading$.pipe(takeUntil(this.destroyed$));
    }
}
