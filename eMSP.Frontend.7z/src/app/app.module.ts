import { LocalStorageAppConfiguration } from './core/factories/local-storage-app-configuration';
import { SharedModule } from './shared/shared.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorHandler, NgModule } from '@angular/core';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { MsalService, BroadcastService } from '@azure/msal-angular';
import { GlobalErrorService } from './core/services/global-error.service';
import { ToastrModule } from 'ngx-toastr';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { ModalModule } from 'ngx-bootstrap/modal';
import { QuillModule } from 'ngx-quill';
import { TagInputModule } from 'ngx-chips';
import { IvyGalleryModule } from 'angular-gallery';
import { NgxMaskModule } from 'ngx-mask';
import { RootStoreModule } from './root-store/root-store.module';
import { AppConfigurations } from './shared/models/abstractions/app-configurations';
import { CookieService } from 'ngx-cookie-service';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { AuthModule } from './auth/auth.module';
import { AuthenticationGuard } from './core/guards/auth.guard';
import { AuthorizeInterceptor } from './core/interceptors/authorize.interceptor';
import { HttpErrorHandlerInterceptor } from './core/interceptors/http-error-handler.interceptor';
// import { DefaultLayoutComponent } from './core/layouts/default-layout/default-layout.component';
import { EmspLayoutComponent } from './core/layouts/emsp-layout/emsp-layout/emsp-layout.component';
import { HeaderComponent } from './core/layouts/emsp-layout/header/header.component';
import { SidebarComponent } from './core/layouts/emsp-layout/sidebar/sidebar.component';
import { P401Component } from './core/layouts/error/401.component';
import { P403Component } from './core/layouts/error/403.component';
import { P404Component } from './core/layouts/error/404.component';
import { P500Component } from './core/layouts/error/500.component';



@NgModule({
    imports: [
        HttpClientModule,
        BrowserModule,
        BrowserAnimationsModule,
        AuthModule,

        AppRoutingModule,
        RootStoreModule,
        BsDropdownModule.forRoot(),
        TabsModule.forRoot(),
        ToastrModule.forRoot({
            timeOut: 5000,
            positionClass: 'toast-bottom-right',
            preventDuplicates: true,
            tapToDismiss: true,
        }),
        PopoverModule.forRoot(),
        ModalModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        TagInputModule,
        IvyGalleryModule,
        AccordionModule.forRoot(),
        NgxMaskModule.forRoot(),
    ],
    declarations: [
        AppComponent,
        // DefaultLayoutComponent,
        P404Component,
        P500Component,
        P403Component,
        P401Component,
        HeaderComponent,
        SidebarComponent,
        EmspLayoutComponent,
    ],
    providers: [
        {
            provide: LocationStrategy,
            useClass: HashLocationStrategy,
        },
        BroadcastService,
        AuthenticationGuard,
        {
            provide: HTTP_INTERCEPTORS,
            useClass: MsalInterceptor,
            multi: true,
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthorizeInterceptor,
            multi: true,
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: HttpErrorHandlerInterceptor,
            multi: true,
        },
        {
            provide: ErrorHandler,
            useClass: GlobalErrorService,
        },
        {
            provide: AppConfigurations,
            useFactory: () => new LocalStorageAppConfiguration(),
        },
        CookieService,
    ],
    bootstrap: [AppComponent],
})
export class AppModule {}
