import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { ToastrService } from 'ngx-toastr';
import { Observable, Observer, of, Subject } from 'rxjs';
import { takeUntil, tap, catchError, map, share, debounceTime, switchMap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IReportDebtShowRoomDetailReq } from '../../../shared/interfaces/report-debt-showroom-detail-req.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { Showroom } from '../../../shared/models/showroom.model';
import { BatterySubscriptionPackageApiService } from '../../../shared/services/api-services/battery-subscription-package-api.service';
import { BillApiService } from '../../../shared/services/api-services/bill-api.service';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { DebtShowroomDetailReportViewModel } from '../../../shared/view-models/debt-showroom-detail.viewModel';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { BillType } from '../../../shared/enums/bill-type.enum';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';

@Component({
    selector: 'emsp-report-sr-revenue-detail',
    templateUrl: './report-sr-revenue-detail.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportSRRevenueDetailComponent extends BaseComponent implements OnInit {
    public requestFilter: IReportDebtShowRoomDetailReq;
    public gridData: IGridData<DebtShowroomDetailReportViewModel[]>;
    public export$ = new Subject<IReportDebtShowRoomDetailReq>();

    public vehicles$: Observable<string[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public showroom$: Observable<Showroom[]>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService,
        private readonly reportApiService: ReportApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly exportApiService: ExportApiService,
        private readonly billApiService: BillApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        vehicleId: '',
                        storeCode: '',
                        batterySerial: '',
                        customerName: '',
                        idCustomer: '',
                        vehicleModel: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportSRRevenueDetailReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.vehicles$ = this.batterySubscriptionPackageApiService.getVehicles().pipe(
            map((resp) => {
                if (resp?.success) {
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );

        this.showroom$ = new Observable((observer: Observer<string>) => {
            observer.next(this.requestFilter.storeCode);
        }).pipe(
            debounceTime(300),
            switchMap((search: string) => {
                if (search) {
                    return this.billApiService.seachShowroom(search).pipe(
                        catchError((ex) => {
                            return of(null);
                        }),
                        map((resp) => {
                            if (resp?.data) {
                                return resp.data;
                            }
                            return [];
                        })
                    );
                }

                return of([]);
            }),
            takeUntil(this.destroyed$)
        );
    }

    public search(request: IReportDebtShowRoomDetailReq): void {
        if (request.storeCode) {
            this.uiStateService.toggleShowLoading(true);
            this.reportApiService
                .getDebtShowRoomDetailReport(request)
                .pipe(
                    catchError((ex) => {
                        this.uiStateService.toggleShowLoading(false);
                        this.toastrService.error(getMessageEx(ex));
                        return of(null);
                    })
                )
                .subscribe((response) => {
                    if (response) {
                        this.gridData = {
                            data: response.data.items,
                            total: response.data.total,
                        };
                    }
                    this.uiStateService.toggleShowLoading(false);
                    this.cdr.detectChanges();
                });
        } else {
            this.gridData = {
                data: [],
                total: 0,
            };
            this.cdr.detectChanges();
        }
    }

    public onSelectVehicleModel(vehicleModel: string): void {
        this.requestFilter.vehicleModel = vehicleModel;
    }

    public getTypeDebtText(value: number): string {
        return BillType[value];
    }
}
