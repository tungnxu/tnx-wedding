import { SAPTransaction } from './../../../shared/models/sap-transaction.model';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { BaseComponent } from '../../../base.component';
import { IReportBookingFiltering, ISAPTransactionSearchRequest } from '../../../shared/interfaces/report-req.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { ToastrService } from 'ngx-toastr';
import { serviceTypeNameVi, transactionTypeNameVi } from '../../../shared/constants/report-transaction-detail-vi.constant';
import { combineLatest, Observable, Subject } from 'rxjs';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { catchError, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { debounceTime } from 'rxjs/operators';
import { UiStateService } from '../../../core/services/ui-state.service';
import { MIMEType } from '../../../shared/enums/mine-type.enum';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { of } from 'rxjs';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { billTypeVi } from '../../../shared/constants/bill-type-vi.constant';
import { billPaymentMethodVi } from '../../../shared/constants/report-bill-payment-method-vi.constant';

@Component({
    selector: 'emsp-report-transaction-detail',
    templateUrl: './report-transaction-detail.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportTransactionDetailComponent extends BaseComponent implements OnInit {
    public requestFilter: ISAPTransactionSearchRequest;
    public gridData: IGridData<SAPTransaction[]>;
    public export$ = new Subject<ISAPTransactionSearchRequest>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly reportApiService: ReportApiService,
        private readonly exportApiService: ExportApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        billId: '',
                        vehicleId: '',
                        customerId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportSAPTransaction(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: ISAPTransactionSearchRequest): void {
        this.reportApiService.searchSAPTransaction(request).subscribe((response) => {
            if (response.success) {
                this.gridData = {
                    data: response.data.items,
                    total: response.data.total,
                };
                this.cdr.detectChanges();
            }
        });
    }

    public getServiceTypeName(name: number): string {
        return billTypeVi[name];
    }

    public getTransactionTypeName(name: number): string {
        return transactionTypeNameVi[name];
    }

    public getTransactionMethodName(name: number): string {
        return billPaymentMethodVi[name];
    }
}
