import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { Odo } from '../../../shared/models/odo.model';

@Component({
    selector: 'emsp-report-odo-info-popup',
    templateUrl: './report-odo-info-popup.component.html',
})
export class ReportOdoInfoPopupComponent extends BaseComponent implements OnInit {
    @Input() public odo: Odo;
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    constructor() {
        super();
    }

    ngOnInit(): void {}
}
