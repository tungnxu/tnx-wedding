import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { takeUntil, tap, catchError, map, share, debounceTime, withLatestFrom, switchMap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { ChargingBlockStatus } from '../../../shared/enums/charging-blocking.enum';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IChargingBookingDetailSearchReq } from '../../../shared/interfaces/charging-booking-detail-req.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IOdoListSearchRequest } from '../../../shared/interfaces/odo-list-req.interface';
import { ChargingBlocking } from '../../../shared/models/charging-blocking.model';
import { BatterySubscriptionPackageApiService } from '../../../shared/services/api-services/battery-subscription-package-api.service';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-report-charging-booking-detail',
    templateUrl: './report-charging-booking-detail.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportChargingBookingDetailComponent extends BaseComponent implements OnInit {
    public requestFilter: IChargingBookingDetailSearchReq;
    public gridData: IGridData<ChargingBlocking[]>;
    public export$ = new Subject<IChargingBookingDetailSearchReq>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public vehicles$: Observable<string[]>;

    constructor(
        private readonly reportApiService: ReportApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly exportApiService: ExportApiService,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        key: '',
                        vehicleId: '',
                        customerId: '',
                        chargingBookingCode: '',
                        serialPin: '',
                        vehicleModel: '',
                        fullName: '',
                        idNumber: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.vehicles$ = this.batterySubscriptionPackageApiService.getVehicles().pipe(
            map((resp) => {
                if (resp?.success) {
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportChargingBookingReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: IOdoListSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.reportApiService
            .getChargingBookingDetailReport(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
                this.cdr.detectChanges();
            });
    }

    public getChargingStatus(status: number): string {
        return ChargingBlockStatus[status];
    }

    public getChargingStatusClass(status: number): string {
        switch (status) {
            case ChargingBlockStatus.New:
                return 'not_charge_yet';

            case ChargingBlockStatus.Failure:
                return 'charging';

            case ChargingBlockStatus.UnLocked:
                return 'charge_completed';

            case ChargingBlockStatus.Locked:
                return 'charge_noshow';
        }
    }

    public selectVehicleModel(item: string): void {
        this.requestFilter.vehicleModel = item;
    }
}
