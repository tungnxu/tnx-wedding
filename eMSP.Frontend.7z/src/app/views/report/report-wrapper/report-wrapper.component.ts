import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'emsp-report-wrapper',
    templateUrl: './report-wrapper.component.html',
    styleUrls: ['./report-wrapper.component.css'],
})
export class ReportWrapperComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
