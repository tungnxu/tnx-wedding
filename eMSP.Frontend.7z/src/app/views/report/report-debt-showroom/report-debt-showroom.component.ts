import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IReportDebtShowRoom } from '../../../shared/interfaces/debt-showroom-req.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { DebtShowroomReportViewModel } from '../../../shared/view-models/debt-showroom.viewModel';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-report-debt-showroom',
    templateUrl: './report-debt-showroom.component.html',
    styleUrls: ['./report-debt-showroom.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportDebtShowroomComponent extends BaseComponent implements OnInit {
    public requestFilter: IReportDebtShowRoom;
    public gridData: IGridData<DebtShowroomReportViewModel[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public export$ = new Subject<IReportDebtShowRoom>();

    constructor(
        private readonly reportApiService: ReportApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly exportApiService: ExportApiService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }
    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportDebtShowRoomReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }
    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.reportApiService
            .getDebtShowRoomReport(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
                this.cdr.detectChanges();
            });
    }
}
