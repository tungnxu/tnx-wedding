import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SharedModule } from '../../shared/shared.module';
import { QuillModule } from 'ngx-quill';
import { ReportRoutingModule } from './report.routing';
import { ReportWrapperComponent } from './report-wrapper/report-wrapper.component';
import { ReportTransactionDetailComponent } from './report-transaction-detail/report-transaction-detail.component';
import { ReportChargingBookingTransactionComponent } from './report-charging-booking-transaction/report-charging-booking-transaction.component';
import { ReportOdoComponent } from './report-odo/report-odo.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ReportChargingBlockingComponent } from './report-charging-blocking/report-charging-blocking.component';
import { ReportOdoComponentDetail } from './report-odo-detail/report-odo-detail.component';
import { ReportBatteryLeasingComponent } from './report-battery-leasing/report-battery-leasing.component';
import { ReportBatteryLeasingDetailComponent } from './report-battery-leasing-detail/report-battery-leasing-detail.component';
import { ReportDebtShowroomComponent } from './report-debt-showroom/report-debt-showroom.component';
import { ReportSRRevenueDetailComponent } from './report-sr-revenue-detail/report-sr-revenue-detail.component';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { ReportChargingBookingDetailComponent } from './report-charging-booking-detail/report-charging-booking-detail.component';
import { ReportOdoInfoPopupComponent } from './report-odo-info-popup/report-odo-info-popup.component';

@NgModule({
    imports: [
        ReportRoutingModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        TabsModule.forRoot(),
        PaginationModule.forRoot(),
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        CollapseModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        BsDropdownModule.forRoot(),
        TypeaheadModule.forRoot(),
    ],
    declarations: [
        ReportWrapperComponent,
        ReportTransactionDetailComponent,
        ReportChargingBookingTransactionComponent,
        ReportOdoComponent,
        ReportOdoComponentDetail,
        ReportChargingBlockingComponent,
        ReportBatteryLeasingComponent,
        ReportBatteryLeasingDetailComponent,
        ReportDebtShowroomComponent,
        ReportSRRevenueDetailComponent,
        ReportChargingBookingDetailComponent,
        ReportOdoInfoPopupComponent,
    ],
    providers: [],
})
export class ReportModule {}
