import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { takeUntil, tap, catchError, debounceTime, withLatestFrom, switchMap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { batterySubscriptionNewStatusVi } from '../../../shared/constants/battery-subscription.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { BatterySubscriptionStatus } from '../../../shared/enums/battery-subscription-status.enum';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { BatteryLeasingReportViewModel } from '../../../shared/view-models/battery-leasing-report.viewModel';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-report-battery-leasing',
    templateUrl: './report-battery-leasing.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportBatteryLeasingComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public gridData: IGridData<BatteryLeasingReportViewModel[]>;
    public export$ = new Subject<IMainFiltering>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public batterySubscriptionStatusVi = batterySubscriptionNewStatusVi;

    constructor(
        private readonly reportApiService: ReportApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly exportApiService: ExportApiService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        vehicleId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportBatteryLeasingReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.reportApiService
            .getBatteryLeasingReport(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
                this.cdr.detectChanges();
            });
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public getBatterySubscriptionStatusName(status: number): string {
        return batterySubscriptionNewStatusVi[status];
    }

    public getBatterySubscriptionStatusClass(status: number): string {
        switch (status) {
            case BatterySubscriptionStatus.Open:
                return 'onhold_stt';

            case BatterySubscriptionStatus.Active:
                return 'active_stt';

            case BatterySubscriptionStatus.Deactivate:
                return 'canceled_stt';

            case BatterySubscriptionStatus.Terminated:
                return 'terminated_stt';
        }
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.status = status;
    }
}
