import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { ReportBatteryLeasingDetailComponent } from './report-battery-leasing-detail/report-battery-leasing-detail.component';
import { ReportBatteryLeasingComponent } from './report-battery-leasing/report-battery-leasing.component';
import { ReportChargingBlockingComponent } from './report-charging-blocking/report-charging-blocking.component';
import { ReportChargingBookingDetailComponent } from './report-charging-booking-detail/report-charging-booking-detail.component';
import { ReportChargingBookingTransactionComponent } from './report-charging-booking-transaction/report-charging-booking-transaction.component';
import { ReportDebtShowroomComponent } from './report-debt-showroom/report-debt-showroom.component';
import { ReportOdoComponent } from './report-odo/report-odo.component';
import { ReportSRRevenueDetailComponent } from './report-sr-revenue-detail/report-sr-revenue-detail.component';
import { ReportTransactionDetailComponent } from './report-transaction-detail/report-transaction-detail.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        // component: ReportWrapperComponent,
        data: {
            title: 'Báo cáo vận hành',
            requiredPermission: appPermissions.ReportRead,
        },
        children: [
            {
                path: 'sap-transaction',
                component: ReportTransactionDetailComponent,
                data: {
                    title: 'Chi tiết giao dịch SAP',
                },
            },
            {
                path: 'battery-leasing',
                component: ReportBatteryLeasingComponent,
                data: {
                    title: 'Báo cáo tổng hợp thuê pin',
                },
            },
            {
                path: 'battery-leasing-detail',
                component: ReportBatteryLeasingDetailComponent,
                data: {
                    title: 'Báo cáo chi tiết thuê pin',
                },
            },
            {
                path: 'charging-booking-transaction',
                component: ReportChargingBookingTransactionComponent,
                data: {
                    title: 'Chi tiết giao dịch charging booking',
                },
            },
            // {
            //     path: 'other-transaction',
            //     component: ReportOtherTransactionComponent,
            //     data: {
            //         title: 'Chi tiết giao dịch khác',
            //     },
            // },
            // {
            //     path: 'booking',
            //     component: ReportChargingBookingComponent,
            //     data: {
            //         title: 'Báo cáo booking',
            //     },
            // },
            {
                path: 'odo',
                component: ReportOdoComponent,
                data: {
                    title: 'Báo cáo ODO',
                },
            },
            // {
            //     path: 'odo-detail',
            //     component: ReportOdoComponent,
            //     data: {
            //         title: 'Báo cáo chi tiết ODO',
            //     },
            // },
            {
                path: 'debt-showroom',
                component: ReportDebtShowroomComponent,
                data: {
                    title: 'Tổng hợp công nợ SR',
                },
            },
            {
                path: 'sr-revenue-detail',
                component: ReportSRRevenueDetailComponent,
                data: {
                    title: 'Chi tiết công nợ tại showroom',
                },
            },
            {
                path: 'charging-blocking',
                component: ReportChargingBlockingComponent,
                data: {
                    title: 'Danh sách chặn sạc',
                },
            },
            {
                path: 'charging-booking-detail',
                component: ReportChargingBookingDetailComponent,
                data: {
                    title: 'Danh sách chặn sạc',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ReportRoutingModule {}
