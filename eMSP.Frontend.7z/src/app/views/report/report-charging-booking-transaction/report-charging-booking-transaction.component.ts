import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { BaseComponent } from '../../../base.component';
import { IChargingBookingTransactionReportReq } from '../../../shared/interfaces/bill-req.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { debounceTime, switchMap, tap, catchError, takeUntil, withLatestFrom, map, share } from 'rxjs/operators';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { TransactionReportViewModel } from '../../../shared/view-models/transaction-report.viewModel';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { BatterySubscriptionPackageApiService } from '../../../shared/services/api-services/battery-subscription-package-api.service';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';

@Component({
    selector: 'emsp-report-charging-booking-transaction',
    templateUrl: './report-charging-booking-transaction.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportChargingBookingTransactionComponent extends BaseComponent implements OnInit {
    public requestFilter: IChargingBookingTransactionReportReq;
    public gridData: IGridData<TransactionReportViewModel[]>;
    public export$ = new Subject<IChargingBookingTransactionReportReq>();
    public errorMessages = errorMessages;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public vehicles$: Observable<string[]>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly reportApiService: ReportApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly exportApiService: ExportApiService,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        vehicleId: '',
                        chargingBookingCode: '',
                        chargingStationCity: '',
                        chargingStationState: '',
                        serialPin: '',
                        vehicleModel: '',
                        fullName: '',
                        idNumber: '',
                        key: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportChargingBookingTransactionReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.vehicles$ = this.batterySubscriptionPackageApiService.getVehicles().pipe(
            map((resp) => {
                if (resp?.success) {
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );
    }

    public search(request: IChargingBookingTransactionReportReq): void {
        this.uiStateService.toggleShowLoading(true);
        this.reportApiService
            .getChargingBookingTransactionReport(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
            });
    }

    public onSelectVehicleModel(vehicleModel: string): void {
        this.requestFilter.vehicleModel = vehicleModel;
    }
}
