import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { takeUntil, tap, catchError, map, share, debounceTime, withLatestFrom, switchMap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { dateTimeConfig } from '../../../shared/constants/common.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IOdoListSearchRequest } from '../../../shared/interfaces/odo-list-req.interface';
import { IReportOdoFiltering } from '../../../shared/interfaces/report-req.interface';
import { Odo } from '../../../shared/models/odo.model';
import { BatterySubscriptionPackageApiService } from '../../../shared/services/api-services/battery-subscription-package-api.service';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { ReportOdoInfoPopupComponent } from '../report-odo-info-popup/report-odo-info-popup.component';

@Component({
    selector: 'emsp-report-odo',
    templateUrl: './report-odo.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportOdoComponent extends BaseComponent implements OnInit {
    public requestFilter: IReportOdoFiltering;
    public gridData: IGridData<Odo[]>;
    public export$ = new Subject<IReportOdoFiltering>();

    public vehicles$: Observable<string[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public yearDroprownSelect: number[];

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly exportApiService: ExportApiService,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService,
        private readonly reportApiService: ReportApiService,
        private readonly modalService: ModalService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        vehicleId: '',
                        month: new Date().getMonth() + 1,
                        year: new Date().getFullYear(),
                        contractNo: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportOdoReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.vehicles$ = this.batterySubscriptionPackageApiService.getVehicles().pipe(
            map((resp) => {
                if (resp?.success) {
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );

        this.yearDroprownSelect = this.getListYearDropdown();
    }

    public getListYearDropdown(): number[] {
        const listYear = [dateTimeConfig.startYear];
        if (new Date().getFullYear() > dateTimeConfig.startYear) {
            for (let i = dateTimeConfig.startYear + 1; i <= new Date().getFullYear(); i++) {
                listYear.push(i);
            }
        }
        return listYear;
    }

    public search(request: IOdoListSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.reportApiService
            .getOdoReport(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
                this.cdr.detectChanges();
            });
    }

    public onSelectMonthFilter(month: number): void {
        this.requestFilter.month = month;
    }

    public onSelectYearFilter(year: number): void {
        this.requestFilter.year = year;
    }

    public viewDetail(item: Odo): void {
        this.modalService.openModal({
            title: `Lịch sử ODO ${item.month}/${item.year}`,
            inputs: [
                { key: 'odo', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: ReportOdoInfoPopupComponent,
        });
    }
}
