import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { takeUntil, tap, catchError } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { billPaymentMethodVi } from '../../../shared/constants/report-bill-payment-method-vi.constant';
import { serviceTypeNameVi } from '../../../shared/constants/report-transaction-detail-vi.constant';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IOdoListSearchRequest } from '../../../shared/interfaces/odo-list-req.interface';
import { Odo } from '../../../shared/models/odo.model';
import { OdoApiService } from '../../../shared/services/api-services/odo-api.service';
import { ReportApiService } from '../../../shared/services/api-services/report-api.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-report-odo-detail',
    templateUrl: './report-odo-detail.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportOdoComponentDetail extends BaseComponent implements OnInit {
    public requestFilter: IOdoListSearchRequest;
    public gridData: IGridData<Odo[]>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly odoApiService: OdoApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        vehicleId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IOdoListSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.odoApiService
            .getOdoList(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public onSelectMonthFilter(month: number): void {
        this.requestFilter.month = month;
    }
}
