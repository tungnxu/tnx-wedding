import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoiceDetailComponent } from './invoice-detail/invoice-detail.component';
import { InvoiceListComponent } from './invoice-list/invoice-list.component';
import { InvoiceRoutingModule } from './invoice.routing';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { SharedModule } from '../../shared/shared.module';

@NgModule({
    declarations: [InvoiceDetailComponent, InvoiceListComponent],
    imports: [CommonModule, FormsModule, InvoiceRoutingModule, SharedModule, HttpClientModule, TypeaheadModule.forRoot()],
    providers: [],
})
export class InvoiceModule {}
