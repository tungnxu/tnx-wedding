import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of } from 'rxjs';
import { takeUntil, map, tap, catchError } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { billStatusVi } from '../../../shared/constants/bill-status-vi.constant';
import { BillType } from '../../../shared/enums/bill-type.enum';
import { InvoiceType } from '../../../shared/enums/invoice.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IInvoiceSearchRequest } from '../../../shared/interfaces/invoice-req.interface';
import { BillBatteryLeasingDataInfo } from '../../../shared/models/bill-battery-leasing-data-info.model';
import { BillChargingDataInfo } from '../../../shared/models/bill-charging-data-info.model';
import { Bill } from '../../../shared/models/bill.model';
import { Invoice } from '../../../shared/models/invoice.model';
import { InvoiceApiService } from '../../../shared/services/api-services/invoice-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-invoice-detail',
    templateUrl: './invoice-detail.component.html',
    styleUrls: ['./invoice-detail.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InvoiceDetailComponent extends BaseComponent implements OnInit {
    @Input() public invoice: Invoice;
    @Input() public requestFilterInput: IInvoiceSearchRequest;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public invoiceGrid$: Observable<IGridData<Bill[]>>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public updatePermission$: Observable<boolean>;

    public requestFilter: IInvoiceSearchRequest;

    constructor(
        private readonly authStateService: AuthStateService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly invoiceService: InvoiceApiService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.BillUpdate);
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.requestFilter.transactionId = this.invoice.transactionId;

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        ...this.requestFilterInput,
                        transactionId: this.invoice.transactionId,
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.searchInvoice();
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public searchInvoice(): void {
        this.invoiceGrid$ = this.invoiceService.getDetailBill(this.requestFilter).pipe(
            tap(() => this.uiStateService.toggleShowLoading(true)),
            map((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response.success) {
                    return {
                        data: response.data.items,
                        total: response.data.total,
                    };
                }
                return null;
            }),
            catchError((ex) => {
                this.uiStateService.toggleShowLoading(false);
                this.toastrService.error(getMessageEx(ex));
                return of(null);
            })
        );
    }
    public getBillStatusName(name: string): string {
        return billStatusVi[name];
    }

    public getInvoiceServiceType(name: number): string {
        return InvoiceType[name];
    }
}
