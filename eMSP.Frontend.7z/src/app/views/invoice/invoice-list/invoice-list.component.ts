import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, combineLatest, of } from 'rxjs';
import { takeUntil, tap, catchError } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { billStatusVi, billPaymentStatusVi } from '../../../shared/constants/bill-status-vi.constant';
import { billTypeVi } from '../../../shared/constants/bill-type-vi.constant';
import { InvoiceType } from '../../../shared/enums/invoice.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IInvoiceSearchRequest } from '../../../shared/interfaces/invoice-req.interface';
import { Invoice } from '../../../shared/models/invoice.model';
import { BillApiService } from '../../../shared/services/api-services/bill-api.service';
import { InvoiceApiService } from '../../../shared/services/api-services/invoice-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { InvoiceDetailComponent } from '../invoice-detail/invoice-detail.component';

@Component({
    selector: 'emsp-invoice-list',
    templateUrl: './invoice-list.component.html',
    styleUrls: ['./invoice-list.component.css'],
})
export class InvoiceListComponent extends BaseComponent implements OnInit {
    public requestFilter: IInvoiceSearchRequest;
    public gridData: IGridData<Invoice[]>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public selectedKeys: string[] = [];
    public billStatusVi = billStatusVi;
    public billTypeVi = billTypeVi;
    public billPaymentStatusVi = billPaymentStatusVi;

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly modalService: ModalService,
        private readonly invoiceService: InvoiceApiService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.cdr.detectChanges();
    }

    public search(request: IInvoiceSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.invoiceService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public getBillStatusName(name: string): string {
        return billStatusVi[name];
    }

    public getInvoiceServiceType(name: number): string {
        return InvoiceType[name];
    }

    public viewDetail(item: Invoice): void {
        this.modalService.openModal({
            title: 'Xem chi tiết',
            inputs: [
                { key: 'invoice', value: item },
                { key: 'requestFilter', value: { ...this.requestFilter } },
            ],
            component: InvoiceDetailComponent,
        });
    }
}
