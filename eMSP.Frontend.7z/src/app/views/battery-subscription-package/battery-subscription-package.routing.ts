import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { BatterySubscriptionPackageListComponent } from './battery-subscription-package-list/battery-subscription-package-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: BatterySubscriptionPackageListComponent,
        data: {
            title: 'Cấu hình giá sạc pin',
            requiredPermission: appPermissions.BatterySubscriptionPackageRead,
        },
        children: [
            {
                path: 'battery-subcriptions-package',
                component: BatterySubscriptionPackageListComponent,
                data: {
                    title: 'Quản lý gói cước thuê pin',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class BatterySubscriptionPackageRoutingModule {}
