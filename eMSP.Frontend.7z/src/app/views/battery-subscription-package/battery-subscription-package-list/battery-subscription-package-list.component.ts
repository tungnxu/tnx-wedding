import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { map, takeUntil, tap, catchError, withLatestFrom, share } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { BatterySubscriptionPackageEditComponent } from '../battery-subscription-package-edit/battery-subscription-package-edit.component';
import { BatterySubscriptionPackageApiService } from '../../../shared/services/api-services/battery-subscription-package-api.service';
import { IBatterySubscriptionPackageSearchReq } from '../../../shared/interfaces/battery-subscription-req.interface';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { BatterySubscriptionPackage } from '../../../shared/models/battery-subscription-package.model';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';

@Component({
    selector: 'emsp-battery-subscription-package-list',
    templateUrl: './battery-subscription-package-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BatterySubscriptionPackageListComponent extends BaseComponent implements OnInit {
    public requestFilter: IBatterySubscriptionPackageSearchReq;
    public selectedKeys: string[] = [];
    public gridData: IGridData<BatterySubscriptionPackage[]>;

    public vehicles$: Observable<string[]>;
    public add$ = new Subject<void>();
    public viewDetail$ = new Subject<BatterySubscriptionPackage>();
    public edit$ = new Subject<BatterySubscriptionPackage>();
    private selectVehicleType$ = new Subject<string>();
    public updatePermission$: Observable<boolean>;
    private vehicleTypeSelected: string;
    private vehicleModelSelected: string;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly authStateService: AuthStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.BatterySubscriptionPackageUpdate);

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        vehicleModel: '',
                        vehicleType: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.vehicles$ = this.batterySubscriptionPackageApiService.getVehicles().pipe(
            map((resp) => {
                if (resp?.success) {
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );

        this.handleAdd();
        this.handleViewDetail();
        this.handleEdit();
        this.handleSelectVehicleType();
    }

    public search(request: IBatterySubscriptionPackageSearchReq): void {
        this.uiStateService.toggleShowLoading(true);
        if (this.vehicleTypeSelected) {
            request.vehicleType = this.vehicleTypeSelected;
        }

        if (this.vehicleModelSelected) {
            request.vehicleModel = this.vehicleModelSelected;
        }

        this.batterySubscriptionPackageApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
            });
    }

    public handleViewDetail(): void {
        this.viewDetail$
            .pipe(
                withLatestFrom(this.vehicles$),
                tap(([item, vehicles]) => {
                    this.modalService.openModal({
                        title: 'Chi tiết',
                        inputs: [
                            { key: 'batterySubscriptionPackage', value: item },
                            { key: 'vehicles', value: vehicles },
                            { key: 'viewOnly', value: true },
                        ],
                        component: BatterySubscriptionPackageEditComponent,
                    });
                })
            )
            .subscribe();
    }

    private handleAdd(): void {
        this.add$
            .pipe(
                withLatestFrom(this.vehicles$, this.uiConfigurations$),
                tap(([, vehicles, uiConfigurations]) => {
                    this.modalService.openModal(
                        {
                            title: 'Thêm mới',
                            inputs: [
                                { key: 'batterySubscriptionPackage', value: {} },
                                { key: 'vehicles', value: vehicles },
                            ],
                            component: BatterySubscriptionPackageEditComponent,
                            onSubmit: () => {
                                this.search(this.requestFilter);
                            },
                        },
                        {
                            ignoreBackdropClick: true,
                        }
                    );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public handleEdit(): void {
        this.edit$
            .pipe(
                withLatestFrom(this.vehicles$, this.uiConfigurations$),
                tap(([item, vehicles, uiConfigurations]) => {
                    this.modalService.openModal({
                        title: 'Chỉnh sửa',
                        inputs: [
                            { key: 'batterySubscriptionPackage', value: item },
                            { key: 'vehicles', value: vehicles },
                        ],
                        component: BatterySubscriptionPackageEditComponent,
                        onSubmit: () => {
                            this.search(this.requestFilter);
                        },
                    });
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public handleSelectVehicleType(): void {
        // this.selectVehicleType$
        //     .pipe(
        //         withLatestFrom(this.vehicles$),
        //         tap(([vehicleType, vehicles]) => {
        //             this.vehicleModelSelected = '';
        //             this.vehicleTypeSelected = vehicleType;
        //             this.vehiclesByType = vehicles.filter((vehicle) => vehicle.type === vehicleType);
        //         }),
        //         takeUntil(this.destroyed$)
        //     )
        //     .subscribe();
    }

    public selectVehicleModel(item: string): void {
        this.vehicleModelSelected = item;
    }
}
