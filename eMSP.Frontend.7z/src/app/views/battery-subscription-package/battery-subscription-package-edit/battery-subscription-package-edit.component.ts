import { ChangeDetectionStrategy, ChangeDetectorRef, EventEmitter, Input, Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, map, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { BatterySubscriptionPackageApiService } from '../../../shared/services/api-services/battery-subscription-package-api.service';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { BatterySubscriptionPackage } from '../../../shared/models/battery-subscription-package.model';
import { IBatterySubscriptionPackageEditReq } from '../../../shared/interfaces/battery-subscription-package-req.interface';
import { BatterySubscriptionPackageType } from '../../../shared/enums/battery-subscriptions-package.enum';

@Component({
    selector: 'emsp-battery-subscription-package-edit',
    templateUrl: './battery-subscription-package-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BatterySubscriptionPackageEditComponent extends BaseComponent implements OnInit {
    @Input() public batterySubscriptionPackage: BatterySubscriptionPackage;
    @Input() public vehicles: string[] = [];
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public save$ = new Subject<BatterySubscriptionPackage>();
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;
    public minDate: Date;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;
    // public dropdownTypeSelected: number;

    public rentalEditFromGroup: FormGroup;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly formBuilder: FormBuilder,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.rentalEditFromGroup = this.formBuilder.group({
            limitKm: [
                {
                    value: this.batterySubscriptionPackage?.limitKm,
                    disabled: this.viewOnly || this.checkDisableLimitKm(this.batterySubscriptionPackage?.packageType),
                },
                [Validators.required],
            ],
            price: [{ value: this.batterySubscriptionPackage?.price, disabled: this.viewOnly }, [Validators.required]],
            packageType: [this.batterySubscriptionPackage?.packageType, Validators.required],
            vehicleModel: [this.batterySubscriptionPackage.vehicleModel, Validators.required],
        });
        this.minDate = new Date();
        this.handleSave();
    }

    public getPackageTypeSelected(): string {
        return batterySubscriptionPackageTypeVi[this.batterySubscriptionPackage?.packageType];
    }

    public onSelectVehicleType(type: string): void {
        this.batterySubscriptionPackage.vehicleModel = type;
        this.rentalEditFromGroup.controls.vehicleModel.setErrors(null);
    }

    public changeDropdownPakageType(typeSelected: string): void {
        this.batterySubscriptionPackage.packageType = Number(typeSelected);
        this.cdr.detectChanges();
        this.rentalEditFromGroup.controls.packageType.setErrors(null);

        if (this.checkDisableLimitKm(Number(typeSelected))) {
            this.rentalEditFromGroup.controls.limitKm.disable();
            this.rentalEditFromGroup.controls.limitKm.setValue(0);
        } else {
            this.rentalEditFromGroup.controls.limitKm.enable();
        }
    }

    public checkDisableLimitKm(type: number): boolean {
        return type === BatterySubscriptionPackageType.FIXED; // loại gói cước cố định
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map((batterySubscriptionPackage) => this.mapToRentalEditReq(batterySubscriptionPackage)),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([batterySubscriptionPackage, uiConfigurations]) => {
                    if (!batterySubscriptionPackage?.id) {
                        return this.batterySubscriptionPackageApiService.create(batterySubscriptionPackage).pipe(
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            }),
                            tap((resp) => {
                                this.uiStateService.toggleShowLoading(false);
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                            })
                        );
                    } else {
                        return this.batterySubscriptionPackageApiService.update(batterySubscriptionPackage).pipe(
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            }),
                            tap((resp) => {
                                this.uiStateService.toggleShowLoading(false);
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                            })
                        );
                    }
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private mapToRentalEditReq(btsPackage: BatterySubscriptionPackage): IBatterySubscriptionPackageEditReq {
        return {
            id: btsPackage.id,
            packageType: btsPackage.packageType,
            vehicleModel: btsPackage.vehicleModel,
            price: parseFloat(this.rentalEditFromGroup.controls.price.value.toString()),
            limitKm: parseFloat(this.rentalEditFromGroup.controls.limitKm.value.toString()),
        } as IBatterySubscriptionPackageEditReq;
    }

    private isValid(): boolean {
        Object.keys(this.rentalEditFromGroup.controls).forEach((key) => {
            this.rentalEditFromGroup.get(key)?.markAsDirty();
        });
        this.cdr.detectChanges();
        return this.rentalEditFromGroup.valid;
    }
}
