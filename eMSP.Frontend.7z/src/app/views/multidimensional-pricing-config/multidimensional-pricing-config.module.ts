import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MultidimensionalPricingConfigListComponent } from './multidimensional-pricing-config-list/multidimensional-pricing-config-list.component';
import { MultidimensionalPricingConfigEditComponent } from './multidimensional-pricing-config-edit/multidimensional-pricing-config-edit.component';
import { MultidimensionalPricingConfigRoutingModule } from './multidimensional-pricing-config.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { TagInputModule } from 'ngx-chips';
import { QuillModule } from 'ngx-quill';
import { MultidimentionalRuleConfigListComponent } from './multidimentional-rule-config-list/multidimentional-rule-config-list.component';
import { MultidimentionalRuleConfigEditComponent } from './multidimentional-rule-config-edit/multidimentional-rule-config-edit.component';
import { MultidimentionalRuleSetConfigEditComponent } from './multidimentional-rule-set-config-edit/multidimentional-rule-set-config-edit.component';
import { MultidimentionalRuleSetConfigListComponent } from './multidimentional-rule-set-config-list/multidimentional-rule-set-config-list.component';

@NgModule({
    declarations: [
        MultidimensionalPricingConfigListComponent,
        MultidimensionalPricingConfigEditComponent,
        MultidimentionalRuleConfigListComponent,
        MultidimentionalRuleConfigEditComponent,
        MultidimentionalRuleSetConfigEditComponent,
        MultidimentionalRuleSetConfigListComponent,
    ],
    imports: [
        CommonModule,
        FormsModule,
        MultidimensionalPricingConfigRoutingModule,
        SharedModule,
        BsDropdownModule.forRoot(),
        PopoverModule.forRoot(),
        TabsModule.forRoot(),
        PaginationModule.forRoot(),
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        CollapseModule.forRoot(),
        QuillModule.forRoot(),
        TagInputModule,
        ReactiveFormsModule,
    ],
})
export class MultidimensionalPricingConfigModule {}
