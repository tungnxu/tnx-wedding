import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { MultidimensionalPricingConfigListComponent } from './multidimensional-pricing-config-list/multidimensional-pricing-config-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: MultidimensionalPricingConfigListComponent,
        data: {
            title: 'Quản trị vận hành',
            requiredPermission: appPermissions.AdminOnly,
        },
        children: [
            {
                path: 'multidimensional-charging',
                component: MultidimensionalPricingConfigListComponent,
                data: {
                    title: 'Cấu hình giá nhiều chiều',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class MultidimensionalPricingConfigRoutingModule {}
