import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { RulesetApiService } from '../../../shared/services/api-services/ruleset-api.service';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { filter, switchMap, tap, catchError, takeUntil, withLatestFrom } from 'rxjs/operators';
import { combineLatest, Observable, of } from 'rxjs';
import { MultidimentionalRuleSetConfigEditComponent } from '../multidimentional-rule-set-config-edit/multidimentional-rule-set-config-edit.component';
import { RuleSet } from '../multidimensional-pricing-config.model';
import { IRuleSearch } from '../../../shared/interfaces/rule-search.interface';
import { ToastrService } from 'ngx-toastr';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';

@Component({
    selector: 'emsp-multidimentional-rule-set-config-list',
    templateUrl: './multidimentional-rule-set-config-list.component.html',
    styleUrls: ['./multidimentional-rule-set-config-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultidimentionalRuleSetConfigListComponent extends BaseComponent implements OnInit {
    public requestFilter: IRuleSearch;
    public selectedKeys: string[] = [];
    public gridData: IGridData<RuleSet[]>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly rulesetApiServce: RulesetApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IRuleSearch): void {
        this.uiStateService.toggleShowLoading(true);
        this.rulesetApiServce
            .search(request)
            .pipe(
                catchError((ex) => {
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public viewDetail(item: RuleSet): void {
        this.modalService.openModal({
            title: 'Chi tiết',
            inputs: [
                { key: 'ruleSet', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: MultidimentionalRuleSetConfigEditComponent,
        });
    }

    public edit(item: RuleSet): void {
        this.modalService.openModal(
            {
                title: 'Chỉnh sửa',
                inputs: [{ key: 'ruleSet', value: item }],
                component: MultidimentionalRuleSetConfigEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(item: RuleSet): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn xóa không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() =>
                    this.rulesetApiServce.delete([item.id]).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                                this.search(this.requestFilter);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                        }),
                        catchError((ex) => {
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }
}
