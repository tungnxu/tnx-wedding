import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { RuleApiService } from '../../../shared/services/api-services/rule-api.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { tap, catchError, takeUntil, filter, switchMap, withLatestFrom } from 'rxjs/operators';
import { combineLatest, Observable, of } from 'rxjs';
import { MultidimentionalRuleConfigEditComponent } from '../multidimentional-rule-config-edit/multidimentional-rule-config-edit.component';
import { Rule } from '../multidimensional-pricing-config.model';
import { ToastrService } from 'ngx-toastr';
import { IRuleSearch } from '../../../shared/interfaces/rule-search.interface';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';

@Component({
    selector: 'emsp-multidimentional-rule-config-list',
    templateUrl: './multidimentional-rule-config-list.component.html',
    styleUrls: ['./multidimentional-rule-config-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultidimentionalRuleConfigListComponent extends BaseComponent implements OnInit {
    public requestFilter: IRuleSearch;
    public selectedKeys: string[] = [];
    public gridData: IGridData<Rule[]>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly ruleApiServce: RuleApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IRuleSearch): void {
        this.uiStateService.toggleShowLoading(true);
        this.ruleApiServce
            .search(request)
            .pipe(
                tap((resp) => {
                    if (!resp?.success) {
                        this.uiStateService.toggleShowLoading(false);
                        return null;
                    }
                }),
                catchError((ex) => {
                    // this.toastrService.error(uiConfigurations.labelConfiguration.errorMessage);
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                this.gridData = {
                    data: response.data.items,
                    total: response.data.total,
                };
                this.cdr.detectChanges();
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public viewDetail(item: Rule): void {
        this.modalService.openModal({
            title: 'Chi tiết',
            inputs: [
                { key: 'rule', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: MultidimentionalRuleConfigEditComponent,
        });
    }

    public edit(item: Rule): void {
        this.modalService.openModal(
            {
                title: 'Chỉnh sửa',
                inputs: [{ key: 'item', value: item }],
                component: MultidimentionalRuleConfigEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(item: Rule): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn xóa không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() =>
                    this.ruleApiServce.delete([item.id]).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.search(this.requestFilter);
                        }),
                        catchError((ex) => {
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Thêm mới',
                component: MultidimentionalRuleConfigEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }
}
