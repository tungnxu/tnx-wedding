import { Component, OnInit, AfterViewInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { Subject, of, Observable } from 'rxjs';
import { RuleApiService } from '../../../shared/services/api-services/rule-api.service';
import { ToastrService } from 'ngx-toastr';
import { debounceTime, switchMap, tap, catchError, takeUntil, withLatestFrom } from 'rxjs/operators';
import { Rule, LookupItem } from '../multidimensional-pricing-config.model';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';

@Component({
    selector: 'emsp-multidimentional-rule-config-edit',
    templateUrl: './multidimentional-rule-config-edit.component.html',
    styleUrls: ['./multidimentional-rule-config-edit.component.css', '../../../../../node_modules/quill/dist/quill.snow.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultidimentionalRuleConfigEditComponent extends BaseComponent implements OnInit, AfterViewInit {
    @Input() public rule: Rule = {
        id: '',
        name: '',
        code: '',
        script: '',
        type: '',
    };
    @Input() public viewOnly: boolean;

    public ruleForm: FormGroup;
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public backupItem: Rule;
    public currentCode = '';
    public checkScript = false;
    public currentKey = '';
    public currentValue = '';
    public checkedLoading: boolean;
    public currentType: '';
    public moduleKey: string;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public save$ = new Subject<Rule>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly ruleApiServce: RuleApiService,
        private readonly formBuilder: FormBuilder,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.rule.enabled = true;
        this.ruleForm = this.formBuilder.group({
            name: ['', [Validators.required]],
            type: ['', [Validators.required]],
            code: ['', [Validators.required]],
            script: ['', [Validators.required]],
        });
        this.handleSave();
    }

    // public getvalue(event: string, uiConfigurations: UiConfigurationViewModel): void {
    //     this.moduleKey = uiConfigurations.pricingModelTemplates?.find((x) => x?.alias === event)?.key;
    // }

    ngAfterViewInit(): void {
        if (this.rule) {
            this.currentCode = this.rule.code;
            this.moduleKey = this.rule.module?.key;
        }
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([rule, uiConfigurations]) => {
                    const currentModule = new LookupItem();
                    currentModule.key = this.moduleKey;
                    rule.module = currentModule;
                    if (!rule.id) {
                        return this.ruleApiServce.create(rule).pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                            }),
                            catchError((ex) => {
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        );
                    }
                    return this.ruleApiServce.update(rule).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.submited.emit();
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                        }),
                        catchError((ex) => {
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }
}
