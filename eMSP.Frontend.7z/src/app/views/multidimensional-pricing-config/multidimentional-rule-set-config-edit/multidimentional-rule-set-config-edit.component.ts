import { Component, OnInit, AfterViewInit, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { Observable, Subject, of } from 'rxjs';
import { RulesetApiService } from '../../../shared/services/api-services/ruleset-api.service';
import { ToastrService } from 'ngx-toastr';
import { debounceTime, switchMap, tap, catchError, takeUntil, withLatestFrom } from 'rxjs/operators';
import { RuleSet, Rule, LookupItem } from '../multidimensional-pricing-config.model';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { Response } from '../../../shared/models/response.model';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';

@Component({
    selector: 'emsp-multidimentional-rule-set-config-edit',
    templateUrl: './multidimentional-rule-set-config-edit.component.html',
    styleUrls: ['./multidimentional-rule-set-config-edit.component.css', '../../../../../node_modules/quill/dist/quill.snow.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultidimentionalRuleSetConfigEditComponent extends BaseComponent implements OnInit, AfterViewInit {
    @Input() public ruleSet: RuleSet = {};
    @Input() public viewOnly: boolean;

    public ruleSetForm: FormGroup;
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public currentCode = '';
    public checkScript = false;
    public currentKey = '';
    public currentValue = '';
    public moduleKey: string;

    public availableRule$: Observable<Rule[]>;
    public ruleDelete = [];
    public ruleInsert = [];

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public save$ = new Subject<RuleSet>();

    constructor(
        private readonly ruleSetApiService: RulesetApiService,
        private readonly formBuilder: FormBuilder,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.ruleSet.enabled = true;
        this.ruleSetForm = this.formBuilder.group({
            name: ['', [Validators.required]],
            module: ['', [Validators.required]],
            code: ['', [Validators.required]],
            script: ['', [Validators.required]],
        });
        const id = this.ruleSet?.id ? this.ruleSet?.id : '';
        this.moduleKey = this.ruleSet.module?.key;
        this.ruleSet.rules = this.ruleSet.rules ? this.ruleSet.rules : [];
        this.availableRule$ = this.ruleSetApiService.getAvailableRule(id);
        this.availableRule$.subscribe((x) => (this.ruleInsert = x));
        this.handleSave();
    }

    ngAfterViewInit(): void {}

    public onCheckAddRule(event: Rule): void {
        this.ruleInsert.splice(this.ruleInsert.indexOf(event), 1);
        this.ruleSet.rules.push(event);
    }

    public onCheckDeleteRule(event: Rule): void {
        this.ruleSet.rules.splice(this.ruleSet.rules.indexOf(event), 1);
        this.ruleInsert.push(event);
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([rule, uiConfigurations]) => {
                    const currentModule = new LookupItem();
                    currentModule.key = this.moduleKey;
                    rule.module = currentModule;
                    if (!rule.id) {
                        return this.ruleSetApiService.create(rule).pipe(
                            tap((resp) => {
                                this.handleResponse(resp, uiConfigurations);
                            }),
                            catchError((ex) => {
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        );
                    }
                    return this.ruleSetApiService.update(rule).pipe(
                        tap((resp) => {
                            this.handleResponse(resp, uiConfigurations);
                        }),
                        catchError((ex) => {
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private handleResponse(resp: Response<any>, uiConfigurations: UiConfigurationViewModel): void {
        if (resp?.success) {
            this.submited.emit();
            this.toastrService.success(resp.message);
        } else {
            this.toastrService.error(getMessageResp(resp));
        }
    }
}
