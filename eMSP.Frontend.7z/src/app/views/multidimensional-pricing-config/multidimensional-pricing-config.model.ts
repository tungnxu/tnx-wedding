export class PricingResult {
    id?: string;
    customer?: PricingCustomer;
    tariff?: TariffCode;
    results?: PromotionResult[];
}

export class PricingCustomer {
    id: string;
    transactionDate: string;
    customerName: string;
    customerNo: string;
    email: string;
    sapCustomerNo: string;
    group: string;
    odo: string;
}

export class TariffCode {
    id: string;
    tariffId: string;
    locations: string[];
    currency: string;
    price: number;
    name: string;
    applyDate: string;
    request: string;
}

export class TariffRestriction {
    startTime: string;
    endTime: string;
    startDate: string;
    endDate: string;
    minKwh: number;
    maxKwh: number;
    minCurrent: number;
    maxCurrent: number;
    minPower: number;
    maxPower: number;
    minDuration: number;
    maxDuration: number;
    dayOfWeek: string[];
}

export class TariffComponent {
    type: string;
    price: number;
    tariffRestriction: TariffRestriction;
}

export class PromotionResult {
    value: string;
    price: number;
    locations: string[];
}

export class RuleRef {
    id: string;
    code: string;
    name: string;
    module?: LookupItem;
    ruleRefs?: RuleRef[];
    variables?: string;
    script: string;
    value?: string;
}

export class Rule {
    id: string;
    name: string;
    code: string;
    description?: string;
    module?: LookupItem;
    variables?: LookupItem[];
    script: string;
    type: string;
    ruleRefs?: Rule[] = [];
    enabled?: boolean;
}

export class LookupItem {
    key: string;
    value?: string;
}

export class RuleSet {
    id?: string;
    name?: string;
    code?: string;
    description?: string;
    module?: LookupItem;
    rules?: Rule[] = [];
    variables?: LookupItem[];
    script?: string;
    enabled?: boolean;
}
