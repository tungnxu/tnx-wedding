import { IGridData } from './../../../shared/interfaces/grid-data.interface';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { RuleApiService } from '../../../shared/services/api-services/rule-api.service';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { MultidimentionalRuleConfigListComponent } from '../multidimentional-rule-config-list/multidimentional-rule-config-list.component';
import { MultidimentionalRuleSetConfigListComponent } from '../multidimentional-rule-set-config-list/multidimentional-rule-set-config-list.component';
import { MultidimentionalRuleSetConfigEditComponent } from '../multidimentional-rule-set-config-edit/multidimentional-rule-set-config-edit.component';
import { MultidimentionalRuleConfigEditComponent } from '../multidimentional-rule-config-edit/multidimentional-rule-config-edit.component';
import { Rule } from '../multidimensional-pricing-config.model';
import { combineLatest, Observable, of } from 'rxjs';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { catchError, takeUntil, tap } from 'rxjs/operators';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'emsp-multidimensional-pricing-config-list',
    templateUrl: './multidimensional-pricing-config-list.component.html',
    styleUrls: ['./multidimensional-pricing-config-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultidimensionalPricingConfigListComponent extends BaseComponent implements OnInit {
    @ViewChild('ruleSet') ruleSet: MultidimentionalRuleConfigListComponent;
    @ViewChild('rule') rule: MultidimentionalRuleSetConfigListComponent;

    public requestFilter: IMainFiltering;
    public selectedKeys: string[] = [];
    public gridData: IGridData<Rule[]>;
    public currentTab = 'Pricing model';

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly ruleService: RuleApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.ruleService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public checkTab = (event: string): void => {
        this.currentTab = event;
    };

    public add(): void {
        if (this.currentTab === 'Pricing model') {
            this.modalService.openModal(
                {
                    title: 'Thêm mới',
                    component: MultidimentionalRuleSetConfigEditComponent,
                    onSubmit: () => {
                        this.search(this.requestFilter);
                    },
                },
                {
                    ignoreBackdropClick: true,
                }
            );
        } else if (this.currentTab === 'Condition Type') {
            this.modalService.openModal(
                {
                    title: 'Thêm mới',
                    component: MultidimentionalRuleConfigEditComponent,
                    onSubmit: () => {
                        this.search(this.requestFilter);
                    },
                },
                {
                    ignoreBackdropClick: true,
                }
            );
        }
    }
}
