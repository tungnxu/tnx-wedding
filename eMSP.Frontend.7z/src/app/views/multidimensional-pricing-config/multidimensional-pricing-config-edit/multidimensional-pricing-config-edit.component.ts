import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subject } from 'rxjs';
import { BaseComponent } from '../../../base.component';
import { penaltyConfigurationTypeVi } from '../../../shared/constants/penalty-configuration-type-vi.constant';
import { PenaltyConfigurationType } from '../../../shared/enums/penalty-configuration-type.enum';
import { ChargingConfiguration } from '../../charging/charging.model';

@Component({
    selector: 'emsp-multidimensional-pricing-config-edit',
    templateUrl: './multidimensional-pricing-config-edit.component.html',
    styleUrls: ['./multidimensional-pricing-config-edit.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MultidimensionalPricingConfigEditComponent extends BaseComponent implements OnInit {
    @Input() public charging: ChargingConfiguration = {};
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public penaltyConfigurationTypeVi = penaltyConfigurationTypeVi;
    public penaltyConfigurationType = PenaltyConfigurationType;

    public save$ = new Subject<ChargingConfiguration>();

    constructor() {
        super();
    }

    ngOnInit(): void {}
}
