import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
    selector: 'emsp-battery-subscription-rescue-battery',
    templateUrl: './battery-subscription-rescue-battery.component.html',
    styleUrls: ['./battery-subscription-rescue-battery.component.css'],
})
export class BatterySubscriptionRescueBatteryComponent implements OnInit {
    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    constructor() {}

    ngOnInit(): void {}
}
