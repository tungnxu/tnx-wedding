import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionRescueBatteryComponent } from './battery-subscription-rescue-battery.component';

describe('BatterySubscriptionRescueBatteryComponent', () => {
    let component: BatterySubscriptionRescueBatteryComponent;
    let fixture: ComponentFixture<BatterySubscriptionRescueBatteryComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionRescueBatteryComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionRescueBatteryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
