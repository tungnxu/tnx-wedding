import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
    selector: 'emsp-battery-subscription-change-battery',
    templateUrl: './battery-subscription-change-battery.component.html',
    styleUrls: ['./battery-subscription-change-battery.component.css'],
})
export class BatterySubscriptionChangeBatteryComponent implements OnInit {
    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    constructor() {}

    ngOnInit(): void {}
}
