import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionChangeBatteryComponent } from './battery-subscription-change-battery.component';

describe('BatterySubscriptionChangeBatteryComponent', () => {
    let component: BatterySubscriptionChangeBatteryComponent;
    let fixture: ComponentFixture<BatterySubscriptionChangeBatteryComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionChangeBatteryComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionChangeBatteryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
