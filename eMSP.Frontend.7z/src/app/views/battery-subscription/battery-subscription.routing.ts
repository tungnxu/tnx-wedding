import { appPermissions } from './../../shared/constants/app-permissions.constant';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BatterySubscriptionListComponent } from './battery-subscription-list/battery-subscription-list.component';
import { AuthenticationGuard } from '../../core/guards/auth.guard';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: BatterySubscriptionListComponent,
        data: {
            title: 'Quản lý HĐ thuê pin',
            requiredPermission: appPermissions.BatterySubscriptionRead,
        },
        children: [
            {
                path: 'battery-subcriptions',
                component: BatterySubscriptionListComponent,
                data: {
                    title: 'Quản lý hợp đồng thuê pin',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class BatterySubscriptionRoutingModule {}
