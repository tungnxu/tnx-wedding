import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionEditComponent } from './battery-subscription-edit.component';

describe('BatterySubscriptionEditComponent', () => {
    let component: BatterySubscriptionEditComponent;
    let fixture: ComponentFixture<BatterySubscriptionEditComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionEditComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionEditComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
