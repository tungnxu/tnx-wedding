import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionListComponent } from './battery-subscription-list.component';

describe('BatterySubscriptionListComponent', () => {
    let component: BatterySubscriptionListComponent;
    let fixture: ComponentFixture<BatterySubscriptionListComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionListComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
