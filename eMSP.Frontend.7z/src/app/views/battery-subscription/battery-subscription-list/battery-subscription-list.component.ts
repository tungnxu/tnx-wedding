import { appPermissions } from './../../../shared/constants/app-permissions.constant';
import { BatterySubscriptionApiService } from '../../../shared/services/api-services/battery-subscription-api.service';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { BatterySubscription } from '../../../shared/models/battery-subscription.model';
import { ModalService } from '../../../shared/services/modal.service';
import { ToastrService } from 'ngx-toastr';
import { BatterySubscriptionEditComponent } from '../battery-subscription-edit/battery-subscription-edit.component';
import { BatterySubscriptionLiquidateComponent } from '../battery-subscription-liquidate/battery-subscription-liquidate.component';
import { BatterySubscriptionChangeBatteryComponent } from '../battery-subscription-change-battery/battery-subscription-change-battery.component';
import { BatterySubscriptionReceiveBatteryComponent } from '../battery-subscription-receive-battery/battery-subscription-receive-battery.component';
import { BatterySubscriptionRescueBatteryComponent } from '../battery-subscription-rescue-battery/battery-subscription-rescue-battery.component';
import { batterySubscriptionNewStatusVi, batterySubscriptionStatusVi } from '../../../shared/constants/battery-subscription.constant';
import { BatterySubscriptionStatus } from '../../../shared/enums/battery-subscription-status.enum';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { IBatterySubscriptionSearchRequest } from '../../../shared/interfaces/battery-subscription-req.interface';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { DatePipe } from '@angular/common';
import { IInvoiceRegisterSearchRequest } from '../../../shared/interfaces/invoice-register-req.interface';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';

@Component({
    selector: 'emsp-battery-subscription-list',
    templateUrl: './battery-subscription-list.component.html',
    styleUrls: ['./battery-subscription-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [DatePipe],
})
export class BatterySubscriptionListComponent extends BaseComponent implements OnInit {
    public requestFilter: IBatterySubscriptionSearchRequest;
    public gridData: IGridData<BatterySubscription[]>;
    public showExtraButtons = false;
    public batterySubscriptionStatus = BatterySubscriptionStatus;
    public packageChargingSeach: string;

    public batterySubscriptionStatusVi = batterySubscriptionNewStatusVi;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public updatePermission$: Observable<boolean>;
    public createPermission$: Observable<boolean>;

    public invoiceFilter: IInvoiceRegisterSearchRequest;

    public export$ = new Subject<IBatterySubscriptionSearchRequest>();
    constructor(
        private readonly authStateService: AuthStateService,
        private readonly batterySubscriptionApiService: BatterySubscriptionApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly datepipe: DatePipe,
        private readonly exportApiService: ExportApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.BatterySubscriptionUpdate);
        this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.BatterySubscriptionCreate);

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        vehicleId: '',
                        fullName: '',
                        // batterySubscriptionPackageId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportBatterySubscriptionReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.status = status;
    }

    public search(request: IBatterySubscriptionSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.batterySubscriptionApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public changeBattery(): void {
        this.modalService.openModal(
            {
                title: 'Đổi pin tại trạm - xe máy điện',
                inputs: [],
                component: BatterySubscriptionChangeBatteryComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public receiveBattery(): void {
        this.modalService.openModal(
            {
                title: 'Nhân viên vận hành nhận pin tại trạm',
                inputs: [],
                component: BatterySubscriptionReceiveBatteryComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public rescueBattery(): void {
        this.modalService.openModal(
            {
                title: 'Cứu hộ pin',
                inputs: [],
                component: BatterySubscriptionRescueBatteryComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public viewDetail(item: BatterySubscription): void {
        this.modalService.openModal({
            title: 'Chi tiết HĐ thuê pin - ' + item.contractNo,
            inputs: [
                { key: 'batterySubscription', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: BatterySubscriptionEditComponent,
        });
    }

    public active(item: BatterySubscription): void {
        this.modalService.openModal({
            title: 'Kích hoạt HĐ thuê pin - ' + item.contractNo,
            inputs: [
                { key: 'batterySubscription', value: item },
                { key: 'active', value: true },
            ],
            component: BatterySubscriptionEditComponent,
            onSubmit: () => {
                this.search(this.requestFilter);
            },
        });
    }

    public liquidate(item: BatterySubscription): void {
        this.modalService.openModal(
            {
                title: 'Chấm dứt hợp đồng',
                inputs: [{ key: 'batterySubscription', value: item }],
                component: BatterySubscriptionLiquidateComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public reactivate(id: string): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn Hủy tạm dừng gói cước thuê pin không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                withLatestFrom(this.uiConfigurations$),
                switchMap(() =>
                    this.batterySubscriptionApiService.reactivate(id).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                                this.search(this.requestFilter);
                            }
                        }),
                        catchError((ex) => {
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public changeBatteryPackage(item: BatterySubscription): void {
        this.modalService.openModal({
            title: 'Đổi gói cước thuê pin - ' + item.contractNo,
            inputs: [
                { key: 'batterySubscription', value: item },
                { key: 'changeBatteryPackage', value: true },
            ],
            component: BatterySubscriptionEditComponent,
            onSubmit: () => {
                this.search(this.requestFilter);
            },
        });
    }

    public getBatterySubscriptionStatusName(status: number): string {
        return batterySubscriptionNewStatusVi[status];
    }

    public getPaymentTimeOrStatus(createdDate: Date, expiredDate: Date): string {
        if (createdDate > expiredDate) {
            return 'Chưa thanh toán';
        } else {
            return this.datepipe.transform(expiredDate, 'HH:mm - dd/MM/yyyy');
        }
    }

    public showSerialPins(item: BatterySubscription): string {
        let pins = '';
        item.batteries.map((data, index) => (index < item.batteries.length - 1 ? (pins += `${data.serial}, `) : (pins += `${data.serial}`)));
        return pins;
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public getBatterySubscriptionStatusClass(status: number): string {
        switch (status) {
            case BatterySubscriptionStatus.Open:
                return 'onhold_stt';

            case BatterySubscriptionStatus.Active:
                return 'active_stt';

            case BatterySubscriptionStatus.Deactivate:
                return 'canceled_stt';

            case BatterySubscriptionStatus.Terminated:
                return 'terminated_stt';
        }
    }
}
