import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionInfoComponent } from './battery-subscription-info.component';

describe('BatterySubscriptionInfoComponent', () => {
    let component: BatterySubscriptionInfoComponent;
    let fixture: ComponentFixture<BatterySubscriptionInfoComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionInfoComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionInfoComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
