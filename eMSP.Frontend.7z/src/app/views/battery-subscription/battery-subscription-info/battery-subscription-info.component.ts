import { takeUntil } from 'rxjs/operators';
import { UiConfigurationViewModel } from './../../../shared/view-models/ui-configuration.viewModel';
import { Observable } from 'rxjs';
import { ChangeDetectionStrategy, Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import * as moment from 'moment';
import { BaseComponent } from '../../../base.component';
import { BatterySubscription } from '../../../shared/models/battery-subscription.model';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';

@Component({
    selector: 'emsp-battery-subscription-info',
    templateUrl: './battery-subscription-info.component.html',
    styleUrls: ['./battery-subscription-info.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BatterySubscriptionInfoComponent extends BaseComponent implements OnInit, OnChanges {
    @Input() public batterySubscription: BatterySubscription;
    @Input() public expiredDate: Date;

    public newExpiredDate: Date;
    public currentDate = new Date();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(private readonly appConfigurationStateService: AppConfigurationStateService) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
    }

    public getBatterySerials(): string {
        return this.batterySubscription?.batteries?.map((b) => b.serial).join(', ') || '';
    }

    ngOnChanges(changes: SimpleChanges): void {
        // this.getNewExpiredDate();
    }

    // public getNewExpiredDate() {
    //     var currentDate = moment();
    //     var expiredDate = moment(this.batterySubscription.expiredDate);
    //     var endDateOfCurrentMonth = moment({
    //         year: currentDate.year(),
    //         month: currentDate.month() + 1,
    //         day: currentDate.day(),
    //         hour: currentDate.hour(),
    //         minute: currentDate.minute(),
    //         seconds: currentDate.second(),
    //     });
    //     if (expiredDate.isAfter(endDateOfCurrentMonth)) {
    //         var dayDiff = expiredDate.diff(endDateOfCurrentMonth, 'days');
    //         var priceRatio = this.oldBatterySubscriptionPackage?.price / this.batterySubscription.package.price;
    //         expiredDate.add(Math.round(dayDiff * priceRatio), 'days');
    //     }
    //     this.newExpiredDate = expiredDate.toDate();
    // }
}
