import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionVehicleSliderComponent } from './battery-subscription-vehicle-slider.component';

describe('BatterySubscriptionVehicleSliderComponent', () => {
    let component: BatterySubscriptionVehicleSliderComponent;
    let fixture: ComponentFixture<BatterySubscriptionVehicleSliderComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionVehicleSliderComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionVehicleSliderComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
