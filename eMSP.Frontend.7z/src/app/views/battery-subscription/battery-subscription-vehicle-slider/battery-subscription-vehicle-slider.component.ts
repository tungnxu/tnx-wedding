import { ChangeDetectionStrategy, Component, Input, OnInit, Output, EventEmitter, ChangeDetectorRef, OnChanges, SimpleChanges } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { VehiclePurchaseContract } from '../../../shared/models/vehicle-purchase-contract.model';
import * as R from 'ramda';
@Component({
    selector: 'emsp-battery-subscription-vehicle-slider',
    templateUrl: './battery-subscription-vehicle-slider.component.html',
    styleUrls: ['./battery-subscription-vehicle-slider.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BatterySubscriptionVehicleSliderComponent extends BaseComponent implements OnInit, OnChanges {
    @Input() public title: string;
    @Input() public vehicles: VehiclePurchaseContract[] = [];
    @Input() public isDisableLineBottom: boolean;

    @Output() public selected = new EventEmitter<VehiclePurchaseContract>();

    public selectedVehicle: VehiclePurchaseContract;
    public arrFocusModel: VehiclePurchaseContract[] = [];
    public showDropDown: boolean;
    public vehiclesShow: VehiclePurchaseContract[] = [];
    constructor(private cdr: ChangeDetectorRef) {
        super();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (!this.vehicles) {
            return;
        }
        if (this.vehicles.length === 1) {
            this.selectedVehicle = this.vehicles[0];
        } else {
            this.selectedVehicle = null;
        }
        this.selected.emit(this.selectedVehicle);
        this.vehiclesShow = R.uniqBy((vehicle) => vehicle.vehicleModel, this.vehicles);
    }

    ngOnInit(): void {}

    public select(vehicle: VehiclePurchaseContract): void {
        if (this.selectedVehicle !== vehicle) {
            this.selectedVehicle = vehicle;
            this.selected.emit(vehicle);
        }
    }

    public getFocusModel(focusVehicle: string): VehiclePurchaseContract[] {
        return this.vehicles.filter((s: VehiclePurchaseContract) => s.vehicleModel === focusVehicle);
    }

    public mouseHover(vehicleModel: VehiclePurchaseContract): void {
        this.arrFocusModel = this.getFocusModel(vehicleModel.vehicleModel);
        this.cdr.detectChanges();
    }
}
