import { Component, EventEmitter, OnInit, Output, ChangeDetectionStrategy, Input, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, map, share, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { BatteryStatus } from '../../../shared/enums/battery-status.enum';
import { LiquiDateState } from '../../../shared/enums/liquidate-state.enum';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { BatteryProblem } from '../../../shared/models/battery-problem.model';
import { BatterySubscription, BatterySubscriptionDetail } from '../../../shared/models/battery-subscription.model';
import { Showroom } from '../../../shared/models/showroom.model';
import { BatterySubscriptionApiService } from '../../../shared/services/api-services/battery-subscription-api.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { BillApiService } from '../../../shared/services/api-services/bill-api.service';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { Bill } from '../../../shared/models/bill.model';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { IBillsForLiquidationReq } from '../../../shared/interfaces/bills-for-liquidation-req.interface';
import { billTypeVi } from '../../../shared/constants/bill-type-vi.constant';
import { BillBatteryLeasingDataInfo } from '../../../shared/models/bill-battery-leasing-data-info.model';
import { ShowroomSearchComponent } from '../../../shared/components/showroom-search/showroom-search.component';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';

@Component({
    selector: 'emsp-battery-subscription-liquidate',
    templateUrl: './battery-subscription-liquidate.component.html',
    styleUrls: ['./battery-subscription-liquidate.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BatterySubscriptionLiquidateComponent extends BaseComponent implements OnInit {
    @Input() public batterySubscription: BatterySubscription;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    @ViewChild('searchShowroom') searchShowroom: ShowroomSearchComponent;

    public batterySubscriptionDetail$: Observable<BatterySubscriptionDetail>;
    public batteryStatus: BatteryStatus;
    public batteryStatusEnum = BatteryStatus;
    public batteryProblemsSelected: BatteryProblem[] = [];
    public billGrid$: Observable<IGridData<Bill[]>>;
    // public temporaryBill: Bill;
    public totalAmountAllBill: number;
    public liquiDateState = LiquiDateState.CHECK_DEBTS;
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;
    public requestBillFilter: IBillsForLiquidationReq;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public save$ = new Subject<void>();
    public bsDatepickerConfig: Partial<BsDatepickerConfig>;
    // error battery
    public batteryProblems$: Observable<BatteryProblem[]>;
    public batteryErrorOther = false;
    public batteryProblems: BatteryProblem[];
    public batteryProblemOther: BatteryProblem = {
        code: '0',
        id: '0',
        name: '',
        problemFee: 0,
        selected: false,
    };
    public otherErrorForm: FormGroup;
    // liquiForm form
    public liquiForm: FormGroup;
    public showroom: Showroom;
    public odoStatus: number;
    public minDate: Date;
    public maxDate = new Date();
    public endOdoDate = new Date();

    constructor(
        private readonly batterySubscriptionApiService: BatterySubscriptionApiService,
        private readonly billApiService: BillApiService,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly formBuilder: FormBuilder,
        private readonly cdr: ChangeDetectorRef
    ) {
        super();
    }
    // actualKm
    ngOnInit(): void {
        this.minDate = new Date(this.batterySubscription.activeDate);
        this.batteryStatus = BatteryStatus.Good;
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(
            tap((uiConfigurations) => {
                this.bsDatepickerConfig = {
                    dateInputFormat: uiConfigurations.clientDateFormat.toUpperCase(),
                    adaptivePosition: true,
                };
                this.requestBillFilter = {
                    // contractNo: this.batterySubscription.contractNo,
                    batterySubscriptionId: this.batterySubscription.id,
                    pageIndex: uiConfigurations.pageIndex,
                    pageSize: uiConfigurations.pageSizeGrid,
                };
            }),
            takeUntil(this.destroyed$)
        );
        this.batterySubscriptionDetail$ = this.batterySubscriptionApiService.retrieve(this.batterySubscription.id).pipe(
            tap(() => this.uiStateService.toggleShowLoading(true)),
            map((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response.success) {
                    this.liquiForm.controls.odoStatus.setValue(response.data.endOdo);
                    this.cdr.detectChanges();
                    return response.data;
                }
                return null;
            }),
            share(),
            catchError((ex) => {
                this.uiStateService.toggleShowLoading(false);
                this.toastrService.error(getMessageEx(ex));
                return of(null);
            })
        );
        this.otherErrorForm = this.formBuilder.group({
            name: [this.batteryProblemOther?.name ?? '', [Validators.required]],
            problemFee: [this.batteryProblemOther?.problemFee ?? '', [Validators.required]],
        });

        this.liquiForm = this.formBuilder.group({
            odoStatus: [this.odoStatus ?? '', [Validators.required]],
            endOdoDate: [this.endOdoDate ?? '', [Validators.required]],
        });
        this.batteryProblems$ = this.batterySubscriptionApiService.getBatteryProblem().pipe(
            map((resp) => {
                if (resp?.success) {
                    this.batteryProblems = resp.data;
                    this.batteryProblems.forEach((element) => {
                        element.serialNumber = this.getBatterySeriaNumber();
                    });
                    this.batteryProblemOther.serialNumber = this.getBatterySeriaNumber();
                    this.cdr.detectChanges();
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );

        this.handleLiquidate();
    }

    public getBatterySerials(): string {
        return this.batterySubscription?.batteries?.map((b) => b.serial).join(', ') || '';
    }

    public getBatteryErrorsTotalPrice(): number {
        return this.batteryStatus === BatteryStatus.Bad
            ? Math.round(
                  this.batteryProblems.filter((b) => b.selected).reduce((accumulator, batteryProblem) => accumulator + batteryProblem.problemFee, 0) +
                      (this.batteryErrorOther ? this.batteryProblemOther.problemFee : 0)
              )
            : 0;
    }

    public getBatteryTotalFee(): number {
        return Math.round(
            Number(
                this.batteryStatus === BatteryStatus.Bad
                    ? this.batteryProblems
                          .filter((b) => b.selected)
                          .reduce((accumulator, batteryProblem) => accumulator + batteryProblem.problemFee, 0) +
                          (this.batteryErrorOther ? this.batteryProblemOther.problemFee : 0)
                    : 0
            ) + this.totalAmountAllBill
        );
    }

    public getBillTypeName(type: number): string {
        return billTypeVi[type];
    }

    public searchBill(): void {
        this.billGrid$ = this.billApiService
            .getBillsForLiquidationDto({
                ...this.requestBillFilter,
                endOdoDate: this.liquiForm.controls.endOdoDate.value.toJSON(),
                odoStatus: this.liquiForm.controls.odoStatus.value,
            })
            .pipe(
                debounceTime(300),
                filter(() => this.isValidSearchBill()),
                tap(() => {
                    this.uiStateService.toggleShowLoading(true);
                    this.endOdoDate = this.liquiForm.controls.endOdoDate.value;
                    this.odoStatus = this.liquiForm.controls.odoStatus.value;
                }),
                map((response) => {
                    this.uiStateService.toggleShowLoading(false);
                    if (response.success) {
                        this.liquiDateState = LiquiDateState.PAYMENT;
                        this.totalAmountAllBill = response.data?.totalAmount;
                        this.cdr.detectChanges();
                        return {
                            data: response.data?.existingBills?.items,
                            total: response.data?.existingBills?.total,
                        };
                    }
                    return null;
                }),
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            );
        // }
    }

    private handleLiquidate(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                withLatestFrom(this.uiConfigurations$),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                switchMap(() => {
                    return this.batterySubscriptionApiService
                        .liquidate({
                            liquidateBatterySubscriptionDto: {
                                batteryProblems: this.mapBatteryProblemArray(),
                                contractNo: this.batterySubscription.contractNo,
                                billPaidInformation: this.showroom,
                            },
                        })
                        .pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    if (resp?.message) {
                                        this.toastrService.success(resp.message);
                                    } else {
                                        this.toastrService.success(textMessages.success_message);
                                    }
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(errorMessages.error_message);
                                return of(null);
                            })
                        );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public isCheckDebtsStep(): boolean {
        return this.liquiDateState === LiquiDateState.CHECK_DEBTS;
    }

    public isPayMentStep(): boolean {
        return this.liquiDateState === LiquiDateState.PAYMENT;
    }

    public onSearchedShowroom(showroom: Showroom): void {
        this.showroom = showroom;
    }

    public getBatterySeriaNumber(): string {
        if (this.batterySubscription?.batteries && this.batterySubscription?.batteries.length > 0) {
            return this.batterySubscription?.batteries[0].serial;
        }
        return '';
    }
    public addBatteryErrorOther(event): void {
        this.batteryErrorOther = event.target.checked;
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public onBacktoCheckDebtsStep(): void {
        this.liquiDateState = LiquiDateState.CHECK_DEBTS;
    }

    public mapBatteryProblemArray(): BatteryProblem[] {
        if (this.batteryStatus === BatteryStatus.Good) {
            return [];
        }
        const list = this.batteryProblems.filter((b) => b.selected);
        if (this.batteryErrorOther) {
            list.push(this.batteryProblemOther);
        }
        return list;
    }

    private isValid(): boolean {
        return this.isValidOtherError() && this.isValidShowroom();
    }
    private isValidOtherError(): boolean {
        if (this.batteryStatus === this.batteryStatusEnum.Good || !this.batteryErrorOther) {
            return true;
        }
        Object.keys(this.otherErrorForm.controls).forEach((key) => {
            this.otherErrorForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.otherErrorForm.valid;
    }

    private isValidSearchBill(): boolean {
        Object.keys(this.liquiForm.controls).forEach((key) => {
            this.liquiForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.liquiForm.valid;
    }

    private isValidShowroom(): boolean {
        Object.keys(this.searchShowroom.searchShowRoomForm.controls).forEach((key) => {
            this.searchShowroom.searchShowRoomForm.get(key).markAsDirty();
        });
        this.searchShowroom.cdr.detectChanges();
        return this.searchShowroom.searchShowRoomForm.valid;
    }
}
