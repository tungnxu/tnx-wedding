import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionLiquidateComponent } from './battery-subscription-liquidate.component';

describe('BatterySubscriptionLiquidateComponent', () => {
    let component: BatterySubscriptionLiquidateComponent;
    let fixture: ComponentFixture<BatterySubscriptionLiquidateComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionLiquidateComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionLiquidateComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
