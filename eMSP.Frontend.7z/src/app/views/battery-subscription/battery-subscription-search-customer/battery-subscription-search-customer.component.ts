import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { customerSearchTypeVi } from '../../../shared/constants/battery-subscription.constant';
import { CustomerSearchType } from '../../../shared/enums/customer-search-type.enum';
import { IFindCustomerReq } from '../../../shared/interfaces/battery-subscription-req.interface';
import { Customer } from '../../../shared/models/customer.model';

@Component({
    selector: 'emsp-battery-subscription-search-customer',
    templateUrl: './battery-subscription-search-customer.component.html',
    styleUrls: ['./battery-subscription-search-customer.component.css'],
})
export class BatterySubscriptionSearchCustomerComponent implements OnInit {
    @Input() public isShowCustomerError: boolean;
    @Input() public customer: Customer;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() searched: EventEmitter<IFindCustomerReq> = new EventEmitter<IFindCustomerReq>();

    public customerSearchText: string;

    @Output() dropdownSelected: EventEmitter<string> = new EventEmitter<string>();

    public arrDropdown: string[];
    public dropdownTypeSelected: CustomerSearchType;
    public customerSearchTypeVi = customerSearchTypeVi;

    constructor() {}

    ngOnInit(): void {
        this.dropdownTypeSelected = CustomerSearchType.IdNumber;
    }

    public changeDropdownType(typeSelected: number): void {
        this.dropdownTypeSelected = typeSelected;
        this.customerSearchText = '';
    }

    public getTextDropdownSelected(): string {
        return customerSearchTypeVi[this.dropdownTypeSelected];
    }

    public enter(event: KeyboardEvent): void {
        if (event && (event.code === 'Enter' || event.code === 'NumpadEnter')) {
            this.searched.emit({ searchText: this.customerSearchText, type: this.dropdownTypeSelected });
        }
    }

    public search(): void {
        this.searched.emit({ searchText: this.customerSearchText, type: this.dropdownTypeSelected });
    }
}
