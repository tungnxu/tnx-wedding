import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionSearchCustomerComponent } from './battery-subscription-search-customer.component';

describe('BatterySubscriptionSearchCustomerComponent', () => {
    let component: BatterySubscriptionSearchCustomerComponent;
    let fixture: ComponentFixture<BatterySubscriptionSearchCustomerComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionSearchCustomerComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionSearchCustomerComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
