import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatterySubscriptionReceiveBatteryComponent } from './battery-subscription-receive-battery.component';

describe('BatterySubscriptionReceiveBatteryComponent', () => {
    let component: BatterySubscriptionReceiveBatteryComponent;
    let fixture: ComponentFixture<BatterySubscriptionReceiveBatteryComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [BatterySubscriptionReceiveBatteryComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BatterySubscriptionReceiveBatteryComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
