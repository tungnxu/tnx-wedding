import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
    selector: 'emsp-battery-subscription-receive-battery',
    templateUrl: './battery-subscription-receive-battery.component.html',
    styleUrls: ['./battery-subscription-receive-battery.component.css'],
})
export class BatterySubscriptionReceiveBatteryComponent implements OnInit {
    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    constructor() {}

    ngOnInit(): void {}
}
