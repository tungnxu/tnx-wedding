import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BatterySubscriptionListComponent } from './battery-subscription-list/battery-subscription-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { BatterySubscriptionRoutingModule } from './battery-subscription.routing';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { SwiperModule } from 'swiper/angular';
import { BatterySubscriptionSearchCustomerComponent } from './battery-subscription-search-customer/battery-subscription-search-customer.component';
import { BatterySubscriptionVehicleSliderComponent } from './battery-subscription-vehicle-slider/battery-subscription-vehicle-slider.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BatterySubscriptionInfoComponent } from './battery-subscription-info/battery-subscription-info.component';
import { BatterySubscriptionEditComponent } from './battery-subscription-edit/battery-subscription-edit.component';
import { BatterySubscriptionLiquidateComponent } from './battery-subscription-liquidate/battery-subscription-liquidate.component';
import { BatterySubscriptionChangeBatteryComponent } from './battery-subscription-change-battery/battery-subscription-change-battery.component';
import { BatterySubscriptionReceiveBatteryComponent } from './battery-subscription-receive-battery/battery-subscription-receive-battery.component';
import { BatterySubscriptionRescueBatteryComponent } from './battery-subscription-rescue-battery/battery-subscription-rescue-battery.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { NgxMaskModule } from 'ngx-mask';
@NgModule({
    declarations: [
        BatterySubscriptionListComponent,
        BatterySubscriptionSearchCustomerComponent,
        BatterySubscriptionVehicleSliderComponent,
        BatterySubscriptionInfoComponent,
        BatterySubscriptionEditComponent,
        BatterySubscriptionLiquidateComponent,
        BatterySubscriptionChangeBatteryComponent,
        BatterySubscriptionReceiveBatteryComponent,
        BatterySubscriptionRescueBatteryComponent,
    ],
    imports: [
        BatterySubscriptionRoutingModule,
        CommonModule,
        FormsModule,
        SharedModule,
        PopoverModule.forRoot(),
        SwiperModule,
        BsDatepickerModule.forRoot(),
        ReactiveFormsModule,
        BsDropdownModule.forRoot(),
        TypeaheadModule.forRoot(),
        NgxMaskModule.forRoot(),
    ],
})
export class BatterySubscriptionModule {}
