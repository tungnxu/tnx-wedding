import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargingBookingTransactionsDetailComponent } from './charging-booking-transactions-detail.component';

describe('ChargingBookingTransactionsDetailComponent', () => {
    let component: ChargingBookingTransactionsDetailComponent;
    let fixture: ComponentFixture<ChargingBookingTransactionsDetailComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ChargingBookingTransactionsDetailComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChargingBookingTransactionsDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
