import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { chargingBookingFee } from '../../../shared/constants/charging-booking-fee.contants';
import { chargingBookingPaymentStatusVi } from '../../../shared/constants/charging-booking-status-vi.constant';
import { ChargingBookingItem } from '../../../shared/models/charing-booking-item.model';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { ChargingBooking } from '../charging-booking.model';

@Component({
    selector: 'emsp-charging-booking-transactions-detail',
    templateUrl: './charging-booking-transactions-detail.component.html',
    styleUrls: ['./charging-booking-transactions-detail.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingBookingTransactionsDetailComponent extends BaseComponent implements OnInit {
    @Input() public chargingBooking: ChargingBooking;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public chargingBookingItem: ChargingBookingItem;

    constructor(private readonly appConfigurationStateService: AppConfigurationStateService) {
        super();
    }
    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        this.chargingBookingItem = this.chargingBooking.chargingBookingItems?.find((cb) => cb.name === chargingBookingFee.IdleFee);
    }

    // TODO BE cần trả ra dữ liệu chuẩn hơn
    public getPaymentStatus(status: any): string {
        return chargingBookingPaymentStatusVi[status];
    }
}
