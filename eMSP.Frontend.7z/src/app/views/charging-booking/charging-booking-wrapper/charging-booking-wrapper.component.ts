import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'emsp-charging-booking-wrapper',
    templateUrl: './charging-booking-wrapper.component.html',
    styleUrls: ['./charging-booking-wrapper.component.css'],
})
export class ChargingBookingWrapperComponent implements OnInit {
    @Input() public showExportBtn = false;

    constructor() {}

    ngOnInit(): void {}
}
