import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargingBookingWrapperComponent } from './charging-booking-wrapper.component';

describe('ChargingBookingWrapperComponent', () => {
    let component: ChargingBookingWrapperComponent;
    let fixture: ComponentFixture<ChargingBookingWrapperComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ChargingBookingWrapperComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChargingBookingWrapperComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
