import { ChargingBookingItem } from '../../shared/models/charing-booking-item.model';

export class ChargingBooking {
    id: string;
    fullName: string;
    phoneNumber: string;
    plateNumber: string;
    address: string;
    customerId: string;
    vehicleId: string;
    macAddress: string;
    chargingDepotId: string;
    chargingDepotName: string;
    chargingDepotAddress: string;
    chargingDepotState: string;
    chargingDepotCity: string;
    chargingStationId: string;
    chargingStationName: string;
    chargingStationAddress: string;
    chargingEvseId: string;
    chargingEvseName: string;
    bookingTimeFrom?: Date;
    bookingTimeTo?: Date;
    pluggedTime?: Date;
    unPluggedTime?: Date;
    startChargeTime?: Date;
    endChargeTime?: Date;
    startSOC?: number;
    endSOC?: number;
    finalAmount: number;
    totalKWCharged?: number;
    paymentToken: string;
    ticketId: string;
    isPaid?: boolean;
    orderStatus?: number;
    chargingBookingItems?: ChargingBookingItem[];
}
