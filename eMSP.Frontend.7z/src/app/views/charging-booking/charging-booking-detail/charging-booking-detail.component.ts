import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { ChargingBooking } from '../charging-booking.model';

@Component({
    selector: 'emsp-charging-booking-detail',
    templateUrl: './charging-booking-detail.component.html',
    styleUrls: ['./charging-booking-detail.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingBookingDetailComponent extends BaseComponent implements OnInit {
    @Input() public chargingBooking: ChargingBooking;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public pageSizeGrid$: Observable<number>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    constructor(private readonly appConfigurationStateService: AppConfigurationStateService) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
    }
}
