import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargingBookingDetailComponent } from './charging-booking-detail.component';

describe('ChargingBookingDetailComponent', () => {
    let component: ChargingBookingDetailComponent;
    let fixture: ComponentFixture<ChargingBookingDetailComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ChargingBookingDetailComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChargingBookingDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
