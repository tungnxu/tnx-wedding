import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { ChargingBookingListComponent } from './charging-booking-list/charging-booking-list.component';
import { ChargingBookingTransactionsComponent } from './charging-booking-transactions/charging-booking-transactions.component';
import { ChargingBookingWrapperComponent } from './charging-booking-wrapper/charging-booking-wrapper.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: ChargingBookingWrapperComponent,
        data: {
            title: 'Quản lý giao dịch',
            requiredPermission: appPermissions.ChargingBookingRead,
        },
        children: [
            {
                path: 'bookings',
                component: ChargingBookingListComponent,
                data: {
                    title: 'Quản lý Charging Booking',
                },
            },
            {
                path: 'transactions',
                component: ChargingBookingTransactionsComponent,
                data: {
                    title: 'Quản lý giao dịch sạc',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ChargingBookingRoutingModule {}
