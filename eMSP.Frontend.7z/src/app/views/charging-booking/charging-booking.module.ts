import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SharedModule } from '../../shared/shared.module';
import { QuillModule } from 'ngx-quill';
import { ChargingBookingRoutingModule } from './charging-booking.routing';
import { ChargingBookingListComponent } from './charging-booking-list/charging-booking-list.component';
import { ChargingBookingDetailComponent } from './charging-booking-detail/charging-booking-detail.component';
import { ChargingBookingTransactionsComponent } from './charging-booking-transactions/charging-booking-transactions.component';
import { ChargingBookingTransactionsDetailComponent } from './charging-booking-transactions-detail/charging-booking-transactions-detail.component';
import { ChargingBookingWrapperComponent } from './charging-booking-wrapper/charging-booking-wrapper.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { InvoiceListComponent } from '../invoice/invoice-list/invoice-list.component';
import { InvoiceDetailComponent } from '../invoice/invoice-detail/invoice-detail.component';

@NgModule({
    imports: [
        ChargingBookingRoutingModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        TabsModule.forRoot(),
        PaginationModule.forRoot(),
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        CollapseModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        BsDropdownModule.forRoot(),
    ],
    declarations: [
        ChargingBookingListComponent,
        ChargingBookingDetailComponent,
        ChargingBookingTransactionsComponent,
        ChargingBookingTransactionsDetailComponent,
        ChargingBookingWrapperComponent,
    ],
    providers: [],
})
export class ChargingBookingModule {}
