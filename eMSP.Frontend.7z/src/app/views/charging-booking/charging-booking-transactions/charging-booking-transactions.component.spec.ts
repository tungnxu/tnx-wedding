import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChargingBookingTransactionsComponent } from './charging-booking-transactions.component';

describe('ChargingBookingTransactionsComponent', () => {
    let component: ChargingBookingTransactionsComponent;
    let fixture: ComponentFixture<ChargingBookingTransactionsComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ChargingBookingTransactionsComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ChargingBookingTransactionsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
