import { chargingBookingStatusVi, transactionPaymentType } from '../../../shared/constants/charging-booking-status-vi.constant';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, Output } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { ChargingBookingTransactionsDetailComponent } from '../charging-booking-transactions-detail/charging-booking-transactions-detail.component';
import { ChargingBookingStatus } from '../../../shared/enums/charging-booking-status.enum';
import { ChargingBooking } from '../charging-booking.model';
import { ChargingBookingApiService } from '../../../shared/services/api-services/charging-booking-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { catchError, debounceTime, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ToastrService } from 'ngx-toastr';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { IChargingBookingReq } from '../../../shared/interfaces/charging-booking-req.interface';

@Component({
    selector: 'emsp-charging-booking-transactions',
    templateUrl: './charging-booking-transactions.component.html',
    styleUrls: ['./charging-booking-transactions.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingBookingTransactionsComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public gridData: IGridData<ChargingBooking[]>;
    public chargingBookingStatusVi = chargingBookingStatusVi;
    public export$ = new Subject<IChargingBookingReq>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly chargingBookingApiService: ChargingBookingApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly exportApiService: ExportApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        vehicleId: '',
                        customerId: '',
                        key: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportChargingBookingTransaction(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.chargingBookingApiService
            .transactionsSearch(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public viewDetail(item: ChargingBooking): void {
        this.modalService.openModal({
            title: 'Xem chi tiết',
            inputs: [{ key: 'chargingBooking', value: item }],
            component: ChargingBookingTransactionsDetailComponent,
        });
    }

    public getChargingStatusName(status: number): string {
        return chargingBookingStatusVi[status];
    }

    public getChargingStatusClass(status: number): string {
        switch (status) {
            case ChargingBookingStatus.Init:
                return 'not_charge_yet';

            case ChargingBookingStatus.Charging:
                return 'charging';

            case ChargingBookingStatus.ChargeCompleted:
                return 'charge_completed';

            case ChargingBookingStatus.Cancelled:
                return 'charge_cancel';

            case ChargingBookingStatus.Completed:
                return 'charge_completed';

            case ChargingBookingStatus.Onhold:
                return 'charge_onhold';

            case ChargingBookingStatus.Noshow:
                return 'charge_noshow';
        }
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.status = status;
    }

    public getTransactionPaymentType(name: string): string {
        return transactionPaymentType[name];
    }
}
