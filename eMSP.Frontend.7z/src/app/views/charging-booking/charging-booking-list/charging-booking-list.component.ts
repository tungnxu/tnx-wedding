import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { catchError, filter, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { chargingBookingStatusVi } from '../../../shared/constants/charging-booking-status-vi.constant';
import { ChargingBookingStatus } from '../../../shared/enums/charging-booking-status.enum';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { ChargingBookingDetailComponent } from '../charging-booking-detail/charging-booking-detail.component';
import { ChargingBooking } from '../charging-booking.model';
import { ChargingBookingApiService } from '../../../shared/services/api-services/charging-booking-api.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { combineLatest, Observable, of } from 'rxjs';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { IChargingBookingReq } from '../../../shared/interfaces/charging-booking-req.interface';

@Component({
    selector: 'emsp-charging-booking-list',
    templateUrl: './charging-booking-list.component.html',
    styleUrls: ['./charging-booking-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingBookingListComponent extends BaseComponent implements OnInit {
    public requestFilter: IChargingBookingReq;
    public gridData: IGridData<ChargingBooking[]>;
    public deletePermission$: Observable<boolean>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public chargingBookingStatusVi = chargingBookingStatusVi;

    constructor(
        public readonly authStateService: AuthStateService,
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly chargingBookingApiService: ChargingBookingApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.deletePermission$ = this.authStateService.hasPermissions$(appPermissions.ChargingBookingDelete);

        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        toDate: '',
                        vehicleId: '',
                        idNumber: '',
                        status: '',
                        key: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IChargingBookingReq): void {
        this.uiStateService.toggleShowLoading(true);
        this.chargingBookingApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public viewDetail(item: ChargingBooking): void {
        this.modalService.openModal({
            title: 'Xem chi tiết',
            inputs: [{ key: 'chargingBooking', value: item }],
            component: ChargingBookingDetailComponent,
        });
    }

    public cancel(item: ChargingBooking): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn hủy không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() => this.chargingBookingApiService.cancel(item.id)),
                withLatestFrom(this.uiConfigurations$),
                tap(([response, uiConfigurations]) => {
                    if (!response.success) {
                        this.toastrService.error(getMessageResp(response));
                    } else {
                        this.search(this.requestFilter);
                        this.toastrService.success(response.message);
                    }
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public getChargingStatusName(status: number): void {
        return chargingBookingStatusVi[status];
    }

    public checkStatusChargingInit(status: number): boolean {
        return ChargingBookingStatus.Init === status;
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.status = status;
    }

    public getChargingStatusClass(status: number): string {
        switch (status) {
            case ChargingBookingStatus.Init:
                return 'not_charge_yet';

            case ChargingBookingStatus.Charging:
                return 'charging';

            case ChargingBookingStatus.ChargeCompleted:
                return 'charge_completed';

            case ChargingBookingStatus.Cancelled:
                return 'charge_cancel';

            case ChargingBookingStatus.Completed:
                return 'charge_completed';

            case ChargingBookingStatus.Onhold:
                return 'charge_onhold';

            case ChargingBookingStatus.Noshow:
                return 'charge_noshow';
        }
    }
}
