import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterOpenTargetSOCListComponent } from './escooter-open-target-soc-list/escooter-open-target-soc-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.EscooterOpenTargetSOCManualRead,
        },
        children: [
            {
                path: 'escooter-open-target-soc',
                component: EscooterOpenTargetSOCListComponent,
                data: {
                    title: 'Mở target SOC',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterOpenTargetSocRoutingModule {}
