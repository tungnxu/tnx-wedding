import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EscooterOpenTargetSocRoutingModule } from './escooter-open-target-soc.routing';
import { EscooterOpenTargetSOCListComponent } from './escooter-open-target-soc-list/escooter-open-target-soc-list.component';
import { EscooterOpenTargetSOCAddComponent } from './escooter-open-target-add/escooter-open-target-soc-add.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from '../../../shared/shared.module';

@NgModule({
    declarations: [EscooterOpenTargetSOCListComponent, EscooterOpenTargetSOCAddComponent],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        SharedModule,
        BsDropdownModule.forRoot(),
        NgxMaskModule.forRoot(),
        EscooterOpenTargetSocRoutingModule,
    ],
})
export class EscooterOpenTargetSocModule {}
