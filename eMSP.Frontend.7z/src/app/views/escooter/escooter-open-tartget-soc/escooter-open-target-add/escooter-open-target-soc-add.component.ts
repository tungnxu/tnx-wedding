import { Component, OnInit, Output, ChangeDetectorRef, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Subject, of } from 'rxjs';
import { catchError, debounceTime, filter, map, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../../shared/constants/battery-subscription-package.constant';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { EWhiteListType } from '../../../../shared/enums/white-list-type.enum';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { ValidationHelper } from '../../../../shared/helpers/validation.helper';
import { ICreateWhiteListRQ } from '../../../../shared/interfaces/white-list-configuration-req.interface';
import { BatterySubscription, WhiteListBatterySubscription } from '../../../../shared/models/battery-subscription.model';
import { EscooterOperatorApiService } from '../../../../shared/services/api-services/ecooter-operator-api.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
@Component({
    selector: 'emsp-escooter-whitelist-soc-add',
    templateUrl: './escooter-open-target-soc-add.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterOpenTargetSOCAddComponent extends BaseComponent implements OnInit {
    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public vehicleID: string;
    public filter$ = new Subject<void>();
    public whiteListBattery: WhiteListBatterySubscription;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;
    public editFromGroup: FormGroup;
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;
    public save$ = new Subject<BatterySubscription>();

    constructor(
        private readonly formBuilder: FormBuilder,
        private readonly uiStateService: UiStateService,
        private readonly escooterOperatorApiService: EscooterOperatorApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef
    ) {
        super();
    }

    ngOnInit(): void {
        this.editFromGroup = this.formBuilder.group({
            ticketID: [null, Validators.required],
        });

        this.handleSave();
    }

    public filterByVin(): void {
        this.uiStateService.toggleShowLoading(true);
        this.escooterOperatorApiService
            .getSubscription(this.vehicleID)
            .pipe(
                catchError((ex) => {
                    this.whiteListBattery = null;
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    this.cdr.detectChanges();
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.whiteListBattery = response.data;
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public enter(event: KeyboardEvent): void {
        if (event && (event.code === 'Enter' || event.code === 'NumpadEnter')) {
            this.filterByVin();
        }
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public checkEnableSubmid(): boolean {
        return this.whiteListBattery != null && this.editFromGroup.controls.price?.value.toString() !== '';
    }

    private isValid(): boolean {
        Object.keys(this.editFromGroup.controls).forEach((key) => {
            this.editFromGroup.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editFromGroup.valid;
    }

    public activeOpenSOC(): boolean {
        return this.whiteListBattery && this.editFromGroup.controls.ticketID?.value;
    }

    public handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map(() => this.mapCreateWhiteListObj()),
                tap((whiteListObject) => {
                    this.uiStateService.toggleShowLoading(true);
                    return this.escooterOperatorApiService
                        .whiteListSocCreate(whiteListObject)
                        .pipe(
                            tap((response) => {
                                if (response.success) {
                                    this.submited.emit();
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        )
                        .subscribe();
                })
            )
            .subscribe();
    }

    private mapCreateWhiteListObj(): ICreateWhiteListRQ {
        return {
            vehicleId: this.whiteListBattery?.subscriptionInfo.vehicleId,
            contractNo: this.whiteListBattery?.subscriptionInfo.contractNo,
            customerId: this.whiteListBattery?.subscriptionInfo.customerId,
            ticketId: this.editFromGroup.controls.ticketID.value,
            type: EWhiteListType.ESCOOTER_SOC,
        } as ICreateWhiteListRQ;
    }
}
