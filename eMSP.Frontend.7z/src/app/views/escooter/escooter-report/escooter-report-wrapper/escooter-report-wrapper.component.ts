import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'emsp-escooter-report-wrapper',
    templateUrl: './escooter-report-wrapper.component.html',
})
export class EscooterReportWrapperComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
