import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { EscooterReportRoutingModule } from './escooter-report.routing';
import { SharedModule } from '../../../shared/shared.module';
import { EscooterBillListComponent } from './escooter-bill-list/escooter-bill-list.component';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { QuillModule } from 'ngx-quill';
import { EscooterReportSapTransactionDetailComponent } from './escooter-report-sap-transaction-detail/escooter-report-sap-transaction-detail.component';

@NgModule({
    imports: [EscooterReportRoutingModule, CommonModule, FormsModule, HttpClientModule, SharedModule, BsDropdownModule.forRoot()],
    declarations: [EscooterBillListComponent, EscooterReportSapTransactionDetailComponent],
    providers: [],
})
export class EscooterReportModule {}
