import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterBillListComponent } from './escooter-bill-list/escooter-bill-list.component';
import { EscooterReportSapTransactionDetailComponent } from './escooter-report-sap-transaction-detail/escooter-report-sap-transaction-detail.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        data: {
            title: 'Báo cáo vận hành escooter',
            requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
        },
        children: [
            {
                path: 'bills',
                component: EscooterBillListComponent,
                data: {
                    title: 'Danh sách bill',
                    requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
                },
            },
            {
                path: 'sap-transaction',
                component: EscooterReportSapTransactionDetailComponent,
                data: {
                    title: 'Chi tiết giao dịch SAP',
                    requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterReportRoutingModule {}
