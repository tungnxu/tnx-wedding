import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { takeUntil, tap, catchError, debounceTime, withLatestFrom, switchMap } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { billStatusVi, billPaymentStatusVi } from '../../../../shared/constants/bill-status-vi.constant';
import { billTypeVi } from '../../../../shared/constants/bill-type-vi.constant';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../../shared/constants/text-messages.constant';
import { BillStatus } from '../../../../shared/enums/bill-status.emun';
import { BillType } from '../../../../shared/enums/bill-type.enum';
import { MIMEType } from '../../../../shared/enums/mime-type.enum';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { IBillListSearchRequest } from '../../../../shared/interfaces/bill-list-req.interface';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { BillBatteryLeasingDataInfo } from '../../../../shared/models/bill-battery-leasing-data-info.model';
import { BillChargingDataInfo } from '../../../../shared/models/bill-charging-data-info.model';
import { BillList } from '../../../../shared/models/bill.model';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { EscooterExportApiService } from '../../../../shared/services/api-services/escooter-export-api.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-escooter-bill-list',
    templateUrl: './escooter-bill-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterBillListComponent extends BaseComponent implements OnInit {
    public requestFilter: IBillListSearchRequest;
    public gridData: IGridData<BillList[]>;
    public export$ = new Subject<IBillListSearchRequest>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public selectedKeys: string[] = [];
    public billStatusVi = billStatusVi;
    public billTypeVi = billTypeVi;
    public billPaymentStatusVi = billPaymentStatusVi;

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly eScooterApiService: EScooterApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly escooterExportApiService: EscooterExportApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        customerId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req]) =>
                    this.escooterExportApiService.exportBills(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.cdr.detectChanges();
    }

    public search(request: IBillListSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.eScooterApiService
            .getBillList(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public getBillStatusName(name: string): string {
        return billStatusVi[name];
    }

    public getBillPaymentStatus(name: string): string {
        return billPaymentStatusVi[name];
    }

    public getBillPaymentStatusClass(status: boolean): string {
        switch (status) {
            case false:
                return 'canceled_stt';

            case true:
                return 'active_stt';
        }
    }

    public getBillStatusClass(status: number): string {
        switch (status) {
            case BillStatus.ONHOLD:
                return 'not_charge_yet';

            case BillStatus.INACTIVE:
                return 'charge_cancel';

            case BillStatus.ACTIVE:
                return 'charge_completed';
        }
    }

    public getBillTypeName(type: string): string {
        return billTypeVi[type];
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.billStatus = status;
    }

    public onSelectType(type: string): void {
        this.requestFilter.types = type;
    }

    public onSelectPaymentStatus(status: string): void {
        this.requestFilter.paid = status;
    }

    public getODO(billList: BillList): string {
        if (billList.type === BillType.ESCOOTER_BATTERY_LEASING) {
            const data = billList.data as BillBatteryLeasingDataInfo;
            if (data) {
                return data?.actualKm.toString();
            }
        }
        return '';
    }
}
