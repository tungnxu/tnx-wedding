import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, map, switchMap, tap, takeUntil, share } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';
import { batterySubscriptionPackageTypeVi } from '../../../../shared/constants/battery-subscription-package.constant';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../../shared/interfaces/main-filtering.interface';
import { BatterySubscriptionPackage } from '../../../../shared/models/battery-subscription-package.model';
import { BatterySubscription } from '../../../../shared/models/battery-subscription.model';
import {
    EScooterBatterySubscription,
    EScooterBatterySubscriptionBills,
    EScooterBatterySubscriptionDetail,
} from '../../../../shared/models/escooter-battery-subscription.model';
import { BatterySubscriptionApiService } from '../../../../shared/services/api-services/battery-subscription-api.service';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';
@Component({
    selector: 'emsp-escooter-battery-subscription-edit',
    templateUrl: './escooter-battery-subscription-edit.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterBatterySubscriptionEditComponent extends BaseComponent implements OnInit {
    @Input() public batterySubscription: EScooterBatterySubscription;
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public gridData: IGridData<EScooterBatterySubscriptionBills[]>;
    public requestFilter: IMainFiltering;
    public batterySubscriptionPackageSelect: string;

    public batterySubscriptionDetail$: Observable<EScooterBatterySubscriptionDetail>;
    public batterySubscriptionPackages$: Observable<BatterySubscriptionPackage[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public save$ = new Subject<BatterySubscription>();
    public active$ = new Subject<BatterySubscription>();
    public changeBatteryPackage$ = new Subject<BatterySubscription>();

    constructor(
        private readonly eScooterApiService: EScooterApiService,
        private readonly authStateService: AuthStateService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.batterySubscriptionDetail$ = this.eScooterApiService.retrieve(this.batterySubscription.id).pipe(
            tap(() => this.uiStateService.toggleShowLoading(true)),
            map((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response.success) {
                    if (response.data.debt) {
                        this.gridData = {
                            data: response.data.debt.bills,
                            total: response.data.debt.bills.length,
                        };
                    }
                    this.cdr.detectChanges();
                    return response.data;
                }
                return null;
            }),
            share(),
            catchError((ex) => {
                this.uiStateService.toggleShowLoading(false);
                this.toastrService.error(getMessageEx(ex));
                return of(null);
            })
        );

        this.batterySubscriptionPackages$ = this.eScooterApiService.searchPackage({ Id: this.batterySubscription.id }).pipe(
            map((response) => {
                if (response.success) {
                    if (response.data) {
                        return response.data;
                    }
                }
                return null;
            }),
            share(),
            catchError((ex) => {
                this.toastrService.error(getMessageEx(ex));
                return of(null);
            })
        );

        // this.handleActive();
        this.handleChangeBatteryPackage();
    }

    public showSerialPins(): string {
        let pins = '';
        this.batterySubscription.batteries.map((data, index) =>
            index < this.batterySubscription.batteries.length - 1 ? (pins += `${data.serial}, `) : (pins += `${data.serial}`)
        );
        return pins;
    }

    // public handleActive(): void {
    //     this.active$
    //         .pipe(
    //             debounceTime(300),
    //             tap(() => this.uiStateService.toggleShowLoading(true)),
    //             switchMap(() =>
    //                 this.batterySubscriptionApiService.active(this.batterySubscription.id).pipe(
    //                     tap((resp) => {
    //                         if (resp?.success) {
    //                             this.toastrService.success(resp.message);
    //                             this.submited.emit();
    //                         }
    //                         this.uiStateService.toggleShowLoading(false);
    //                     }),
    //                     catchError((ex) => {
    //                         this.uiStateService.toggleShowLoading(false);
    //                         this.toastrService.error(getMessageEx(ex));
    //                         return of(null);
    //                     })
    //                 )
    //             ),
    //             takeUntil(this.destroyed$)
    //         )
    //         .subscribe();
    // }

    public handleChangeBatteryPackage(): void {
        this.changeBatteryPackage$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                switchMap(() =>
                    this.eScooterApiService
                        .changePackage({
                            subsciptionId: this.batterySubscription.id,
                            packageId: this.batterySubscriptionPackageSelect,
                        })
                        .pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public getTargetSOC(status: boolean): string {
        if (status) {
            return 'Đang chặn';
        } else {
            return 'Không chặn';
        }
    }

    public selectPackage(id: string): void {
        this.batterySubscriptionPackageSelect = id;
    }

    public checkShowPackage(curPackage: boolean, newPackage: any): boolean {
        return newPackage ? curPackage : !curPackage;
    }
}
