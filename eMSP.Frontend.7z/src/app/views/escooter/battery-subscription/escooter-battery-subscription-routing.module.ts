import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterBatterySubscriptionListComponent } from './escooter-battery-subscription-list/escooter-battery-subscription-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: EscooterBatterySubscriptionListComponent,
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
        },
        children: [
            {
                path: 'escooter-battery-subscription',
                component: EscooterBatterySubscriptionListComponent,
                data: {
                    title: 'Quản lý hợp đồng thuê pin',
                    requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterBatterySubscriptionRoutingModule {}
