import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';
import { batterySubscriptionPackageTypeVi } from '../../../../shared/constants/battery-subscription-package.constant';
import { batterySubscriptionNewStatusVi } from '../../../../shared/constants/battery-subscription.constant';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../../shared/constants/text-messages.constant';
import { BatterySubscriptionStatus } from '../../../../shared/enums/battery-subscription-status.enum';
import { MIMEType } from '../../../../shared/enums/mime-type.enum';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { IBatterySubscriptionSearchRequest } from '../../../../shared/interfaces/battery-subscription-req.interface';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { EScooterBatterySubscription } from '../../../../shared/models/escooter-battery-subscription.model';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { EscooterExportApiService } from '../../../../shared/services/api-services/escooter-export-api.service';
import { ExportApiService } from '../../../../shared/services/api-services/export-api.service';
import { ModalService } from '../../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';
import { EscooterBatterySubscriptionEditComponent } from '../escooter-battery-subscription-edit/escooter-battery-subscription-edit.component';

@Component({
    selector: 'emsp-escooter-battery-subscription-list',
    templateUrl: './escooter-battery-subscription-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterBatterySubscriptionListComponent extends BaseComponent implements OnInit {
    public requestFilter: IBatterySubscriptionSearchRequest;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public gridData: IGridData<EScooterBatterySubscription[]>;
    public viewDetailPermission$: Observable<boolean>;
    public batterySubscriptionStatusVi = batterySubscriptionNewStatusVi;

    public export$ = new Subject<IBatterySubscriptionSearchRequest>();
    public updatePermission$: Observable<boolean>;
    public batterySubscriptionStatus = BatterySubscriptionStatus;

    constructor(
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly eScooterApiService: EScooterApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly authStateService: AuthStateService,
        private readonly exportApiService: EscooterExportApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.EscooterBatterySubscriptionUpdate);

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportEscooterBatterySubscriptionReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public search(request: IBatterySubscriptionSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        this.eScooterApiService
            .searchEScooterBatterySubscription(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public getBatterySubscriptionStatusName(status: number): string {
        return batterySubscriptionNewStatusVi[status];
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.status = status;
    }

    public viewDetail(item: EScooterBatterySubscription): void {
        this.modalService.openModal({
            title: 'Chi tiết HĐ thuê pin - ' + item.contractNo,
            inputs: [
                { key: 'batterySubscription', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: EscooterBatterySubscriptionEditComponent,
        });
    }

    public changeBatteryPackage(item: EScooterBatterySubscription): void {
        this.modalService.openModal({
            title: 'Đổi gói cước thuê pin - ' + item.contractNo,
            inputs: [{ key: 'batterySubscription', value: item }],
            component: EscooterBatterySubscriptionEditComponent,
            onSubmit: () => {
                this.search(this.requestFilter);
            },
        });
    }
    public getBatterySubscriptionStatusClass(status: number): string {
        switch (status) {
            case BatterySubscriptionStatus.Open:
                return 'onhold_stt';

            case BatterySubscriptionStatus.Active:
                return 'active_stt';

            case BatterySubscriptionStatus.Deactivate:
                return 'canceled_stt';

            case BatterySubscriptionStatus.Terminated:
                return 'terminated_stt';
        }
    }
}
