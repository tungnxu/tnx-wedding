import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxMaskModule } from 'ngx-mask';
import { QuillModule } from 'ngx-quill';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { SharedModule } from '../../../shared/shared.module';
import { EscooterBatterySubscriptionEditComponent } from './escooter-battery-subscription-edit/escooter-battery-subscription-edit.component';
import { EscooterBatterySubscriptionListComponent } from './escooter-battery-subscription-list/escooter-battery-subscription-list.component';
import { EscooterBatterySubscriptionRoutingModule } from './escooter-battery-subscription-routing.module';
@NgModule({
    declarations: [EscooterBatterySubscriptionListComponent, EscooterBatterySubscriptionEditComponent],
    imports: [
        EscooterBatterySubscriptionRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        BsDatepickerModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        NgxMaskModule.forRoot(),
        BsDropdownModule.forRoot(),
        PopoverModule.forRoot(),
    ],
})
export class EscooterBatterySubscriptionModule {}
