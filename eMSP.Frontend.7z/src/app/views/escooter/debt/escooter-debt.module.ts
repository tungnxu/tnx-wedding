import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxMaskModule } from 'ngx-mask';
import { QuillModule } from 'ngx-quill';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { SharedModule } from '../../../shared/shared.module';
import { EscooterDebtRoutingModule } from './escooter-debt-routing.module';
import { EscooterDebtListComponent } from './escooter-debt-list/escooter-debt-list.component';
import { EscooterDebtDetailComponent } from './escooter-debt-detail/escooter-debt-detail.component';

@NgModule({
    declarations: [EscooterDebtListComponent, EscooterDebtDetailComponent],
    imports: [
        EscooterDebtRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        BsDatepickerModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        NgxMaskModule.forRoot(),
        BsDropdownModule.forRoot(),
        PopoverModule.forRoot(),
    ],
})
export class EscooterDebtModule {}
