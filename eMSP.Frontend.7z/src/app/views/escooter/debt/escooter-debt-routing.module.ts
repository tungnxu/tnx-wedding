import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterDebtListComponent } from './escooter-debt-list/escooter-debt-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: EscooterDebtListComponent,
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
        },
        children: [
            {
                path: 'escooter-debt',
                component: EscooterDebtListComponent,
                data: {
                    title: 'Quản lý công nợ K/H',
                    requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterDebtRoutingModule {}
