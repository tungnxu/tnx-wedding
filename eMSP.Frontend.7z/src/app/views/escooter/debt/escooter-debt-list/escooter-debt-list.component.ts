import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { BaseComponent } from '../../../../base.component';
import { IMainFiltering } from '../../../../shared/interfaces/main-filtering.interface';
import { IInvoiceRegisterSearchRequest } from '../../../../shared/interfaces/invoice-register-req.interface';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { IBillReportByCustomerResponse } from '../../../../shared/interfaces/bill-report-by-customer-resp.interface';
import { Observable, of, Subject } from 'rxjs';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';
import { ModalService } from '../../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { takeUntil, tap, catchError, debounceTime, withLatestFrom, switchMap } from 'rxjs/operators';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { Bill } from '../../../../shared/models/bill.model';
import { chargingBookingStatusVi } from '../../../../shared/constants/charging-booking-status-vi.constant';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { EscooterDebtDetailComponent } from '../escooter-debt-detail/escooter-debt-detail.component';
import { EscooterExportApiService } from '../../../../shared/services/api-services/escooter-export-api.service';
import { MIMEType } from '../../../../shared/enums/mime-type.enum';
import { textMessages } from '../../../../shared/constants/text-messages.constant';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';

@Component({
    selector: 'emsp-escooter-debt-list',
    templateUrl: './escooter-debt-list.component.html',
    styleUrls: ['./escooter-debt-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterDebtListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public invoiceFilter: IInvoiceRegisterSearchRequest;
    public gridData: IGridData<IBillReportByCustomerResponse[]>;

    public customerIdSuggestions$: Observable<any[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public updatePermission$: Observable<boolean>;

    public export$ = new Subject<IBillReportByCustomerResponse>();
    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly authStateService: AuthStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly escooterApiService: EScooterApiService,
        private readonly exportApiService: EscooterExportApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.BillUpdate);

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        customerId: '',
                        vehicleId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportEscooterDebtListReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.escooterApiService
            .searchCustomerBills(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public viewDetail(item: Bill): void {
        this.modalService.openModal(
            {
                title: `Chi tiết công nợ khách hàng - ${item.fullName} - ${item.customerId}`,
                inputs: [
                    { key: 'bill', value: item },
                    { key: 'requestFilter', value: { ...this.requestFilter } },
                    { key: 'invoiceFilter', value: { ...this.invoiceFilter } },
                ],
                component: EscooterDebtDetailComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public getChargingStatusName(status: number): string {
        return chargingBookingStatusVi[status];
    }
}
