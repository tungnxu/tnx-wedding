import { Observable, of, Subject } from 'rxjs';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { BaseComponent } from '../../../../base.component';
import { Bill } from '../../../../shared/models/bill.model';
import { BillApiService } from '../../../../shared/services/api-services/bill-api.service';
import { IMainFiltering } from '../../../../shared/interfaces/main-filtering.interface';
import { catchError, debounceTime, filter, map, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { billTypeVi } from '../../../../shared/constants/bill-type-vi.constant';
import { ToastrService } from 'ngx-toastr';
import { IPayBillReq } from '../../../../shared/interfaces/bill-req.interface';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';
import { Showroom } from '../../../../shared/models/showroom.model';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { BillInvoiceRequestModel } from '../../../../shared/models/invoice-info.model';
import { RequestInvoiceComponent } from '../../../../shared/components/request-invoice/request-invoice/request-invoice.component';
import { ShowroomSearchComponent } from '../../../../shared/components/showroom-search/showroom-search.component';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { ValidationHelper } from '../../../../shared/helpers/validation.helper';
import { InvoiceRegister } from '../../../../shared/models/invoice-register.model';
import { IInvoiceRegisterSearchRequest } from '../../../../shared/interfaces/invoice-register-req.interface';
import { getMessageEx, getMessageResp } from '../../../../shared/helpers/object.helper';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';

@Component({
    selector: 'emsp-escooter-debt-detail',
    templateUrl: './escooter-debt-detail.component.html',
    styleUrls: ['./escooter-debt-detail.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterDebtDetailComponent extends BaseComponent implements OnInit {
    @Input() public bill: Bill;
    @Input() public requestFilterInput: IMainFiltering;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    @ViewChild('invoiceForm') invoiceForm: RequestInvoiceComponent;
    @ViewChild('searchShowroom') searchShowroom: ShowroomSearchComponent;

    public selectedBills: Bill[] = [];
    public requestFilter: IMainFiltering;

    public billGrid$: Observable<IGridData<Bill[]>>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public pay$ = new Subject<Bill[]>();
    public showroom: Showroom;
    public isChecked = false;
    public invoiceInfo: BillInvoiceRequestModel = new BillInvoiceRequestModel();
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;

    public updatePermission$: Observable<boolean>;
    public customerInvoice$: Observable<InvoiceRegister>;
    public invoiceFilter: IInvoiceRegisterSearchRequest;
    public invoiceCustomerInfo: InvoiceRegister;

    private idBillselect: string[];
    constructor(
        private readonly authStateService: AuthStateService,
        private readonly billApiService: BillApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly escooterApiService: EScooterApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.BillUpdate);
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.invoiceFilter.customerId = this.bill.customerId;
        this.invoiceFilter.isDefault = true;
        this.customerInvoice$ = this.billApiService.searchCustomerInvoice(this.invoiceFilter).pipe(
            map((response) => {
                if (response.success) {
                    this.invoiceCustomerInfo = response.data;
                    return this.invoiceCustomerInfo;
                }
                return null;
            })
        );
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        ...this.requestFilterInput,
                        customerId: this.bill.customerId,
                        vehicleId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.searchBill();
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.handlePay();
    }

    public searchBill(): void {
        this.billGrid$ = this.escooterApiService.getDebtBillsByCustomerId(this.requestFilter).pipe(
            tap(() => this.uiStateService.toggleShowLoading(true)),
            map((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response.success) {
                    return {
                        data: response.data.items,
                        total: response.data.total,
                    };
                }
                return null;
            }),
            catchError((ex) => {
                this.uiStateService.toggleShowLoading(false);
                this.toastrService.error(getMessageEx(ex));
                return of(null);
            })
        );
    }

    public getBillTypeName(type: number): string {
        return billTypeVi[type];
    }

    public onSelectedItemsChange(selectedBills: Bill[]): void {
        this.selectedBills = selectedBills;
        this.idBillselect = [];
        for (const item of selectedBills) {
            this.idBillselect.push(item.id);
            if (item.debtBills) {
                for (const itemDebtBills of item.debtBills) {
                    this.idBillselect.push(itemDebtBills.id);
                }
            }
        }
        this.cdr.detectChanges();
    }

    public getSelectedBillAmount(): number {
        return this.selectedBills.reduce((accumulator, bill) => accumulator + bill.totalBillAmount, 0);
    }

    public onSearchedShowroom(showroom: Showroom): void {
        this.showroom = showroom;
    }

    private handlePay(): void {
        this.pay$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                withLatestFrom(this.uiConfigurations$),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                switchMap(() =>
                    this.escooterApiService.pay(this.mapDataPayBillReq()).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                                this.submited.emit();
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private mapDataPayBillReq(): IPayBillReq {
        if (this.isChecked === false) {
            this.invoiceInfo = null;
        }
        return {
            store: this.showroom,
            billIds: this.idBillselect,
            invoiceInfo: this.invoiceInfo,
        };
    }

    private isValid(): boolean {
        if (this.selectedBills.length === 0 || !this.isValidShowroom()) {
            return false;
        }
        return true;
    }

    private isValidShowroom(): boolean {
        Object.keys(this.searchShowroom.searchShowRoomForm.controls).forEach((key) => {
            this.searchShowroom.searchShowRoomForm.get(key).markAsDirty();
        });
        this.searchShowroom.cdr.detectChanges();
        return this.searchShowroom.searchShowRoomForm.valid;
    }
}
