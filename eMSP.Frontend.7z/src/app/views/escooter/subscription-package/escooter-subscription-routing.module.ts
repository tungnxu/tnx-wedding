import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterSubscriptionPackageListComponent } from './escooter-subscription-package-list/escooter-subscription-package-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: EscooterSubscriptionPackageListComponent,
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.BatterySubscriptionPackageRead,
        },
        children: [
            {
                path: 'emsp-escooter-subscription-package',
                component: EscooterSubscriptionPackageListComponent,
                data: {
                    title: 'Đăng ký gói cước',
                    requiredPermission: appPermissions.BatterySubscriptionPackageRead,
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterSubscriptionPackageRoutingModule {}
