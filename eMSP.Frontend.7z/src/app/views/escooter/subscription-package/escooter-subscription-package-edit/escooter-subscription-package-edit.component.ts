import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, map, switchMap, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../../shared/constants/battery-subscription-package.constant';
import { BatterySubscriptionPackageType } from '../../../../shared/enums/battery-subscriptions-package.enum';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { ValidationHelper } from '../../../../shared/helpers/validation.helper';
import { ICretateUpdateEScooterSubscriptionPackage } from '../../../../shared/interfaces/escooter-subscription-package-req.interfaces';
import { EScooterSubscriptionPackage } from '../../../../shared/models/escooter-subscription-package.model';
import { Vehicle } from '../../../../shared/models/vehicle.model';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';

@Component({
    selector: 'emsp-subscribe-package-edit',
    templateUrl: './escooter-subscription-package-edit.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterSubscriptionPackageEditComponent extends BaseComponent implements OnInit {
    @Input() public eScooterSubscriptionPackage: EScooterSubscriptionPackage;
    @Input() public vehicles: Vehicle[] = [];
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public create$ = new Subject<EScooterSubscriptionPackage>();
    public edit$ = new Subject<EScooterSubscriptionPackage>();
    public validationHelper = ValidationHelper;
    public editFromGroup: FormGroup;
    public minDate: Date;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;

    constructor(
        private readonly formBuilder: FormBuilder,
        private readonly eScooterApiService: EScooterApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.editFromGroup = this.formBuilder.group({
            limitKm: [
                {
                    value: this.eScooterSubscriptionPackage?.limitKm,
                    disabled: this.viewOnly || this.checkDisableLimitKm(this.eScooterSubscriptionPackage?.packageType),
                },
                [Validators.required],
            ],
            minCost: [this.eScooterSubscriptionPackage?.minCost, Validators.required],
            price: [{ value: this.eScooterSubscriptionPackage?.price, disabled: this.viewOnly }, [Validators.required]],
            packageType: [this.eScooterSubscriptionPackage?.packageType, Validators.required],
            vehicleModel: [this.eScooterSubscriptionPackage?.vehicleModel, Validators.required],
        });
        this.minDate = new Date();
        this.onEdit();
        this.onCreate();
    }

    public onCreate(): void {
        this.create$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map(() => this.mapRqCreateSubscribePackgesDTO()),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                switchMap((data) => {
                    return this.eScooterApiService.createEScooterSubscribeBatteryPackages(data).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    );
                }),
                tap(() => this.submited.emit()),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public onEdit(): void {
        this.edit$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map(() => this.mapRqUpdateSubscribePackgesDTO()),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                switchMap((data) => {
                    return this.eScooterApiService.updateEScooterSubscribeBatteryPackages(data, this.eScooterSubscriptionPackage?.id).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    );
                }),
                tap(() => this.submited.emit()),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }
    public checkDisableLimitKm(type: number): boolean {
        return type === BatterySubscriptionPackageType.FIXED; // loại gói cước cố định
    }

    public getPackageTypeSelected(): string {
        return batterySubscriptionPackageTypeVi[this.eScooterSubscriptionPackage?.packageType];
    }

    public onSelectVehicleType(type: Vehicle): void {
        this.eScooterSubscriptionPackage.vehicleModel = type.vehicleModelId;
        this.editFromGroup.controls.vehicleModel.setErrors(null);
    }

    private mapRqCreateSubscribePackgesDTO(): ICretateUpdateEScooterSubscriptionPackage {
        return {
            packageType: this.eScooterSubscriptionPackage.packageType,
            vehicleModel: this.eScooterSubscriptionPackage.vehicleModel,
            price: parseFloat(this.editFromGroup.controls.price.value.toString()),
            minCost: parseFloat(this.editFromGroup.controls.minCost.value.toString()),
            limitKm: parseFloat(this.editFromGroup.controls.limitKm.value.toString()),
        } as ICretateUpdateEScooterSubscriptionPackage;
    }

    private mapRqUpdateSubscribePackgesDTO(): ICretateUpdateEScooterSubscriptionPackage {
        return {
            price: parseFloat(this.editFromGroup.controls.price.value.toString()),
            minCost: parseFloat(this.editFromGroup.controls.minCost.value.toString()),
            limitKm: parseFloat(this.editFromGroup.controls.limitKm.value.toString()),
        } as ICretateUpdateEScooterSubscriptionPackage;
    }

    public changeDropdownPakageType(typeSelected: string): void {
        this.eScooterSubscriptionPackage.packageType = Number(typeSelected);
        this.cdr.detectChanges();
        this.editFromGroup.controls.packageType.setErrors(null);

        if (this.checkDisableLimitKm(Number(typeSelected))) {
            this.editFromGroup.controls.limitKm.disable();
            this.editFromGroup.controls.limitKm.setValue(0);
        } else {
            this.editFromGroup.controls.limitKm.enable();
        }
    }

    private isValid(): boolean {
        Object.keys(this.editFromGroup.controls).forEach((key) => {
            this.editFromGroup.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editFromGroup.valid;
    }
}
