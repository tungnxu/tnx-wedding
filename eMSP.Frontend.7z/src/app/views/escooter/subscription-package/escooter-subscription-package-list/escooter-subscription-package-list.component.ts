import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, map, share, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';
import { batterySubscriptionPackageTypeVi } from '../../../../shared/constants/battery-subscription-package.constant';
import { VehicleType } from '../../../../shared/enums/vehicle-type.enum';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../../shared/interfaces/main-filtering.interface';
import { EScooterSubscriptionPackage } from '../../../../shared/models/escooter-subscription-package.model';
import { Vehicle } from '../../../../shared/models/vehicle.model';
import { BatterySubscriptionPackageApiService } from '../../../../shared/services/api-services/battery-subscription-package-api.service';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { ModalService } from '../../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';
import { EscooterSubscriptionPackageEditComponent } from '../escooter-subscription-package-edit/escooter-subscription-package-edit.component';

@Component({
    selector: 'emsp-escooter-subscription-package',
    templateUrl: './escooter-subscription-package-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterSubscriptionPackageListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public gridData: IGridData<EScooterSubscriptionPackage[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public createPermission$: Observable<boolean>;
    public updatePermission$: Observable<boolean>;
    public add$ = new Subject<void>();
    public vehicles$: Observable<Vehicle[]>;
    public viewDetail$ = new Subject<EScooterSubscriptionPackage>();
    public edit$ = new Subject<EScooterSubscriptionPackage>();
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;

    constructor(
        private readonly eScooterApiService: EScooterApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly batterySubscriptionPackageApiService: BatterySubscriptionPackageApiService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly authStateService: AuthStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.EscooterBatteryPackageCreate);
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.EscooterBatteryPackageUpdate);
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.vehicles$ = this.batterySubscriptionPackageApiService.getVehiclesByType(VehicleType.EScooter).pipe(
            map((resp) => {
                if (resp?.success) {
                    return resp.data;
                }
                return [];
            }),
            catchError((ex) => {
                return of(null);
            }),
            share()
        );

        this.handleAdd();
        this.handleViewDetail();
        this.handleEdit();
    }

    private handleAdd(): void {
        this.add$
            .pipe(
                withLatestFrom(this.vehicles$, this.uiConfigurations$),
                tap(([, vehicles, uiConfigurations]) => {
                    this.modalService.openModal(
                        {
                            title: 'Thêm mới',
                            inputs: [
                                { key: 'eScooterSubscriptionPackage', value: {} },
                                { key: 'vehicles', value: vehicles },
                            ],
                            component: EscooterSubscriptionPackageEditComponent,
                            onSubmit: () => {
                                this.search(this.requestFilter);
                            },
                        },
                        {
                            ignoreBackdropClick: true,
                        }
                    );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public handleEdit(): void {
        this.edit$
            .pipe(
                withLatestFrom(this.vehicles$, this.uiConfigurations$),
                tap(([item, vehicles, uiConfigurations]) => {
                    this.modalService.openModal(
                        {
                            title: 'Chỉnh sửa',
                            inputs: [
                                { key: 'eScooterSubscriptionPackage', value: item },
                                { key: 'vehicles', value: vehicles },
                            ],
                            component: EscooterSubscriptionPackageEditComponent,
                            onSubmit: () => {
                                this.search(this.requestFilter);
                            },
                        },
                        {
                            ignoreBackdropClick: true,
                        }
                    );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public handleViewDetail(): void {
        this.viewDetail$
            .pipe(
                withLatestFrom(this.vehicles$),
                tap(([item, vehicles]) => {
                    this.modalService.openModal({
                        title: 'Chi tiết',
                        inputs: [
                            { key: 'eScooterSubscriptionPackage', value: item },
                            { key: 'vehicles', value: vehicles },
                            { key: 'viewOnly', value: true },
                        ],
                        component: EscooterSubscriptionPackageEditComponent,
                    });
                })
            )
            .subscribe();
    }

    public formatPackageTypeString(type: number): String {
        return batterySubscriptionPackageTypeVi[type];
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.eScooterApiService
            .searchEScooterBatteryPackages(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
                this.cdr.detectChanges();
            });
    }
}
