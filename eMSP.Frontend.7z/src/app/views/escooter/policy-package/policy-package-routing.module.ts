import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { PolicyPackageListComponent } from './policy-package-list/policy-package-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: PolicyPackageListComponent,
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.PackagePolicyRead,
        },
        children: [
            {
                path: 'policy-package',
                component: PolicyPackageListComponent,
                data: {
                    title: 'Policy Package',
                    requiredPermission: appPermissions.PackagePolicyRead,
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PolicyPackageRoutingModule {}
