import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, switchMap, map, takeUntil, tap, filter } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { getMessageEx, getMessageResp } from '../../../../shared/helpers/object.helper';
import { ICreateUpdateEScooterPolicyPackages } from '../../../../shared/interfaces/escooter-policy-packages-req.interfaces';
import { PolicyPackage, EScooterPolicyPackage, PolicyPackageDescription } from '../../../../shared/models/escooter-policy-package';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { ValidationHelper } from '../../../../shared/helpers/validation.helper';
import { ModalService } from '../../../../shared/services/modal.service';
import { PolicyPackageDescriptionsComponent } from '../policy-package-descriptions/policy-package-descriptions.component';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { eScooterTypeDataEn } from '../../../../shared/constants/policy-packages-en.constant';
import { vehicleTypeVi } from '../../../../shared/constants/vehicleTypeVi.contants';
import { Language } from '../../../../shared/enums/language-type.enum';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';

@Component({
    selector: 'emsp-policy-package-edit',
    templateUrl: './policy-package-edit.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PolicyPackageEditComponent extends BaseComponent implements OnInit {
    @Input() public viewOnly: boolean;
    @Input() public eScooterPolicyPackage: EScooterPolicyPackage;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public save$ = new Subject<EScooterPolicyPackage>();
    public editFromGroup: FormGroup;
    public language = Object.values(Language);
    public eScooterTypeData = eScooterTypeDataEn;
    public packages: PolicyPackage[];
    public content: string;
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public policyPackageDescGridData: IGridData<PolicyPackageDescription[]>;
    public vehicleType = vehicleTypeVi;
    public updatePermission$: Observable<boolean>;
    public policyPackageDescriptions: PolicyPackageDescription[] = [];

    constructor(
        private readonly eScooterApiService: EScooterApiService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly formBuilder: FormBuilder,
        private readonly modalService: ModalService,
        private readonly authStateService: AuthStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.PackagePolicyUpdate);

        this.editFromGroup = this.formBuilder.group({
            packageType: [this.eScooterPolicyPackage?.packageId, Validators.required],
            langType: [this.eScooterPolicyPackage?.language, Validators.required],
            content: [this.eScooterPolicyPackage?.content, Validators.required],
            title: [this.eScooterPolicyPackage?.title, Validators.required],
        });

        if (this.eScooterPolicyPackage?.descriptions) {
            this.initPolicyPackageDescriptions();
        } else {
            this.eScooterPolicyPackage.descriptions = [];
        }

        this.getPackages();
        this.onSave();
    }

    private initPolicyPackageDescriptions(): void {
        this.policyPackageDescriptions = this.eScooterPolicyPackage?.descriptions.map((item, index) => ({
            index,
            description: item,
        }));
        this.getDataPolicyPackageDescription();
    }

    private getDataPolicyPackageDescription(): void {
        this.policyPackageDescGridData = {
            data: this.policyPackageDescriptions,
            total: this.policyPackageDescriptions.length,
        };
        this.cdr.detectChanges();
    }

    private getPackages(): void {
        this.uiStateService.toggleShowLoading(true);
        this.eScooterApiService
            .getPackagesPolicy()
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.packages = response.data;
                    if (this.eScooterPolicyPackage.id) {
                        const packageNameObj = this.packages.find((item) => item.id === this.eScooterPolicyPackage.packageId);
                        this.eScooterPolicyPackage.packageName = packageNameObj.packageName;
                    }
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }

                this.cdr.detectChanges();
            });
    }

    public onChangePackage(value: PolicyPackage): void {
        this.editFromGroup.controls.packageType.setErrors(null);
        this.eScooterPolicyPackage.packageId = value.id;
        this.eScooterPolicyPackage.packageName = value.packageName;
    }

    public onChangeVehicleType(value: number): void {
        this.eScooterPolicyPackage.vehicleType = value;
    }

    public onChangeLang(value: string): void {
        this.eScooterPolicyPackage.language = value;
        this.editFromGroup.controls.langType.setErrors(null);
    }

    public getPackageTypeSelected(): string {
        return this.eScooterTypeData[this.eScooterPolicyPackage?.type];
    }

    public onChangeTypeData(value: number): void {
        this.eScooterPolicyPackage.type = value;
        this.editFromGroup.controls.contentType.setErrors(null);
        this.cdr.detectChanges();
    }

    public onSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                map(() => this.mapRqCreatePolicyPackgesDTO()),
                switchMap((data) => {
                    if (!this.eScooterPolicyPackage.id) {
                        return this.eScooterApiService.createPolicyPackage(data).pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        );
                    } else {
                        return this.eScooterApiService.updatePolicyPackage(data).pipe(
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            }),
                            tap((resp) => {
                                this.uiStateService.toggleShowLoading(false);
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                            })
                        );
                    }
                }),
                filter((resp) => !!resp),
                tap(() => this.submited.emit()),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public addColumn(): void {
        this.modalService.openModal(
            {
                title: 'Thêm mô tả',
                inputs: [{ key: 'column', value: {} }],
                component: PolicyPackageDescriptionsComponent,
                onSubmit: (resp: string) => {
                    const data: PolicyPackageDescription = {
                        index: this.policyPackageDescriptions?.length > 0 ? this.policyPackageDescriptions?.length : 0,
                        description: resp,
                    };
                    this.policyPackageDescriptions.push(data);
                    this.getDataPolicyPackageDescription();
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public editDescription(data: PolicyPackageDescription): void {
        this.modalService.openModal(
            {
                title: 'Chỉnh sửa',
                inputs: [{ key: 'policyPackageDescription', value: data }],
                component: PolicyPackageDescriptionsComponent,
                onSubmit: (resp: string) => {
                    this.policyPackageDescriptions[data.index].description = resp;
                    this.getDataPolicyPackageDescription();
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public removeDescription(data: PolicyPackageDescription): void {
        this.policyPackageDescriptions = this.policyPackageDescriptions?.filter((item) => item.index !== data.index);
        this.getDataPolicyPackageDescription();
    }

    private mapRqCreatePolicyPackgesDTO(): ICreateUpdateEScooterPolicyPackages {
        this.formatPolicyPackageDescriptions();
        return {
            id: this.eScooterPolicyPackage.id,
            packageId: this.eScooterPolicyPackage.packageId,
            title: this.editFromGroup.controls.title.value,
            content: this.editFromGroup.controls.content.value,
            language: this.eScooterPolicyPackage.language,
            descriptions: this.eScooterPolicyPackage.descriptions,
            vehicleType: this.eScooterPolicyPackage.vehicleType,
        } as ICreateUpdateEScooterPolicyPackages;
    }

    private formatPolicyPackageDescriptions(): void {
        this.eScooterPolicyPackage.descriptions = [];
        this.eScooterPolicyPackage.descriptions = this.policyPackageDescriptions?.map((data: PolicyPackageDescription) => data.description);
    }

    private isValid(): boolean {
        Object.keys(this.editFromGroup.controls).forEach((key) => {
            this.editFromGroup.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editFromGroup.valid;
    }
}
