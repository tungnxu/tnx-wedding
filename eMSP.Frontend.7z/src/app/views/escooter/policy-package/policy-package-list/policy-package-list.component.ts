import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, of, Subject } from 'rxjs';
import { catchError, filter, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { appPermissions } from '../../../../shared/constants/app-permissions.constant';
import { eScooterTypeDataEn } from '../../../../shared/constants/policy-packages-en.constant';
import { getMessageEx, getMessageResp } from '../../../../shared/helpers/object.helper';
import { IConfirmOptions } from '../../../../shared/interfaces/confirm-options.interface';
import { IGridData } from '../../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../../shared/interfaces/main-filtering.interface';
import { EScooterPolicyPackage } from '../../../../shared/models/escooter-policy-package';
import { EScooterApiService } from '../../../../shared/services/api-services/escooter-api.service';
import { ModalService } from '../../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../../core/services/auth-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';
import { PolicyPackageEditComponent } from '../policy-package-edit/policy-package-edit.component';

@Component({
    selector: 'emsp-policy-package-list',
    templateUrl: './policy-package-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PolicyPackageListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public gridData: IGridData<EScooterPolicyPackage[]>;
    public add$ = new Subject<void>();
    public eScooterTypeDataEn = eScooterTypeDataEn;
    public createPermission$: Observable<boolean>;
    public updatePermission$: Observable<boolean>;
    public viewDetailPermission$: Observable<boolean>;
    public deletePermission$: Observable<boolean>;

    constructor(
        private readonly eScooterApiService: EScooterApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly authStateService: AuthStateService
    ) {
        super();
    }
    ngOnInit(): void {
        this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.PackagePolicyCreate);
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.PackagePolicyUpdate);
        this.viewDetailPermission$ = this.authStateService.hasPermissions$(appPermissions.PackagePolicyRead);
        this.deletePermission$ = this.authStateService.hasPermissions$(appPermissions.PackagePolicyDelete);

        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();

        this.handleAdd();
    }

    private handleAdd(): void {
        this.add$
            .pipe(
                withLatestFrom(this.uiConfigurations$),
                tap(([uiConfigurations]) => {
                    this.modalService.openModal(
                        {
                            title: 'Thêm mới',
                            inputs: [
                                { key: 'eScooterPolicyPackage', value: {} },
                                { key: 'vehicles', value: null },
                            ],
                            component: PolicyPackageEditComponent,
                            onSubmit: () => {
                                this.search(this.requestFilter);
                            },
                        },
                        {
                            ignoreBackdropClick: true,
                        }
                    );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.eScooterApiService
            .searchEscooterPolicyPackages(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
                this.cdr.detectChanges();
            });
    }

    public viewDetail(item: EScooterPolicyPackage): void {
        this.modalService.openModal({
            title: 'Xem chi tiết',
            inputs: [
                { key: 'eScooterPolicyPackage', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: PolicyPackageEditComponent,
        });
    }

    public delete(item: EScooterPolicyPackage): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: `Bạn có chắc chắn muốn xóa <b>${item.title}</b> không?`,
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(() =>
                    this.eScooterApiService.deletePolicyPackage([item.id]).pipe(
                        tap((resp) => {
                            if (resp.success) {
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.search(this.requestFilter);
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public edit(item: EScooterPolicyPackage): void {
        this.modalService.openModal(
            {
                title: 'Chỉnh sửa',
                inputs: [{ key: 'eScooterPolicyPackage', value: item }],
                component: PolicyPackageEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }
}
