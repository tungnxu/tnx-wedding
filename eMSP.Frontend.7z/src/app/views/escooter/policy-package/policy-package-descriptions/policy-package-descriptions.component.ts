import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { debounceTime, filter, map, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { ValidationHelper } from '../../../../shared/helpers/validation.helper';
import { PolicyPackageDescription } from '../../../../shared/models/escooter-policy-package';

@Component({
    selector: 'emsp-policy-package-edit-column',
    templateUrl: './policy-package-descriptions.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PolicyPackageDescriptionsComponent extends BaseComponent implements OnInit {
    @Input() public policyPackageDescription: PolicyPackageDescription;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<string> = new EventEmitter<string>();

    public save$ = new Subject<void>();
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public editColumnForm: FormGroup;

    constructor(private readonly formBuilder: FormBuilder, private readonly cdr: ChangeDetectorRef) {
        super();
    }

    ngOnInit(): void {
        this.editColumnForm = this.formBuilder.group({
            description: [
                this.policyPackageDescription?.description ?? '',
                [Validators.required, Validators.maxLength(500), Validators.minLength(2)],
            ],
        });
        this.handleSave();
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                tap(() => this.submited.emit(this.editColumnForm.controls.description.value)),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private isValid(): boolean {
        Object.keys(this.editColumnForm.controls).forEach((key) => {
            this.editColumnForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editColumnForm.valid;
    }
}
