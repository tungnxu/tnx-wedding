import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxMaskModule } from 'ngx-mask';
import { QuillModule } from 'ngx-quill';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { SharedModule } from '../../../shared/shared.module';
import { EscooterInvoiceEditComponent } from './escooter-invoice-edit/escooter-invoice-edit.component';
import { EscooterInvoiceListComponent } from './escooter-invoice-list/escooter-invoice-list.component';
import { EscooterInvoiceRoutingModule } from './escooter-invoice-routing.module';

@NgModule({
    declarations: [EscooterInvoiceListComponent, EscooterInvoiceEditComponent],
    imports: [
        EscooterInvoiceRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        BsDatepickerModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        NgxMaskModule.forRoot(),
        BsDropdownModule.forRoot(),
        PopoverModule.forRoot(),
    ],
})
export class EscooterInvoiceModule {}
