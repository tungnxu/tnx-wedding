import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterInvoiceListComponent } from './escooter-invoice-list/escooter-invoice-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: EscooterInvoiceListComponent,
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.EscooterInvoiceRead,
        },
        children: [
            {
                path: 'escooter-invoices',
                component: EscooterInvoiceListComponent,
                data: {
                    title: 'Quản lý thông tin hóa đơn xe máy điện',
                    requiredPermission: appPermissions.EscooterInvoiceRead,
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterInvoiceRoutingModule {}
