import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EscooterInvoiceListComponent } from './escooter-invoice-list.component';

describe('EscooterInvoiceListComponent', () => {
    let component: EscooterInvoiceListComponent;
    let fixture: ComponentFixture<EscooterInvoiceListComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [EscooterInvoiceListComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EscooterInvoiceListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
