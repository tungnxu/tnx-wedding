import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EscooterInvoiceEditComponent } from './escooter-invoice-edit.component';

describe('EscooterInvoiceEditComponent', () => {
    let component: EscooterInvoiceEditComponent;
    let fixture: ComponentFixture<EscooterInvoiceEditComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [EscooterInvoiceEditComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(EscooterInvoiceEditComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
