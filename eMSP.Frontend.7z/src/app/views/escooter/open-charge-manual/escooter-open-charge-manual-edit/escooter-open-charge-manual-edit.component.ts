import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Subject, of, Observable } from 'rxjs';
import { catchError, debounceTime, filter, map, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../../shared/constants/battery-subscription-package.constant';
import { errorMessages } from '../../../../shared/constants/error-messages.constant';
import { EWhiteListType } from '../../../../shared/enums/white-list-type.enum';
import { getMessageEx } from '../../../../shared/helpers/object.helper';
import { ValidationHelper } from '../../../../shared/helpers/validation.helper';
import { ICreateWhiteListRQ } from '../../../../shared/interfaces/white-list-configuration-req.interface';
import { BatterySubscription } from '../../../../shared/models/battery-subscription.model';
import { EscooterBill } from '../../../../shared/models/bill.model';
import { EscooterOperatorApiService } from '../../../../shared/services/api-services/ecooter-operator-api.service';
import { AppConfigurationStateService } from '../../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../../shared/view-models/ui-configuration.viewModel';

@Component({
    selector: 'emsp-escooter-open-charge-manual-edit',
    templateUrl: './escooter-open-charge-manual-edit.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EscooterOpenChargeManualEditComponent extends BaseComponent implements OnInit {
    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public customerID: string;
    public filter$ = new Subject<void>();
    public escooterBill: EscooterBill;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;
    public editFromGroup: FormGroup;
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;
    public save$ = new Subject<BatterySubscription>();
    public uiConfigurations$: Observable<UiConfigurationViewModel>;

    constructor(
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly formBuilder: FormBuilder,
        private readonly uiStateService: UiStateService,
        private readonly escooterOperatorApiService: EscooterOperatorApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.editFromGroup = this.formBuilder.group({
            ticketID: [null, Validators.required],
        });

        this.handleSave();
    }

    public filterByVin(): void {
        this.uiStateService.toggleShowLoading(true);
        this.escooterOperatorApiService
            .getEscooterBill(this.customerID)
            .pipe(
                catchError((ex) => {
                    this.escooterBill = null;
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    this.cdr.detectChanges();
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.escooterBill = response.data;
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public enter(event: KeyboardEvent): void {
        if (event && (event.code === 'Enter' || event.code === 'NumpadEnter')) {
            this.filterByVin();
        }
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    private isValid(): boolean {
        Object.keys(this.editFromGroup.controls).forEach((key) => {
            this.editFromGroup.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editFromGroup.valid;
    }

    public handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map(() => this.mapCreateWhiteListObj()),
                tap((whiteListObject) => {
                    this.uiStateService.toggleShowLoading(true);
                    return this.escooterOperatorApiService
                        .whiteListChargingCreate(whiteListObject)
                        .pipe(
                            tap((response) => {
                                if (response.success) {
                                    this.submited.emit();
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        )
                        .subscribe();
                })
            )
            .subscribe();
    }

    public activeOpenCharge(): boolean {
        return this.escooterBill && this.editFromGroup.controls.ticketID?.value;
    }

    private mapCreateWhiteListObj(): ICreateWhiteListRQ {
        return {
            customerId: this.escooterBill?.customerId,
            ticketId: this.editFromGroup.controls.ticketID.value,
            type: EWhiteListType.ESCOOTER_CHARGING,
        } as ICreateWhiteListRQ;
    }
}
