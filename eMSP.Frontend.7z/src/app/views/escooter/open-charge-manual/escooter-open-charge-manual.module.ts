import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EscooterOpenChargeManualRoutingModule } from './escooter-open-charge-manual-routing.module';
import { EscooterOpenChargeManualListComponent } from './escooter-open-charge-manual-list/escooter-open-charge-manual-list.component';
import { EscooterOpenChargeManualEditComponent } from './escooter-open-charge-manual-edit/escooter-open-charge-manual-edit.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from '../../../shared/shared.module';
import { EscooterOpenTargetSocRoutingModule } from '../escooter-open-tartget-soc/escooter-open-target-soc.routing';

@NgModule({
    declarations: [EscooterOpenChargeManualListComponent, EscooterOpenChargeManualEditComponent],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        SharedModule,
        BsDropdownModule.forRoot(),
        NgxMaskModule.forRoot(),
        EscooterOpenTargetSocRoutingModule,
        EscooterOpenChargeManualRoutingModule,
    ],
})
export class EscooterOpenChargeManualModule {}
