import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../../core/guards/auth.guard';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { EscooterOpenChargeManualListComponent } from './escooter-open-charge-manual-list/escooter-open-charge-manual-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        data: {
            title: 'Quản lý xe máy điện',
            requiredPermission: appPermissions.EscooterOpenTargetSOCManualRead,
        },
        children: [
            {
                path: 'escooter-open-charging',
                component: EscooterOpenChargeManualListComponent,
                data: {
                    title: 'Mở chặn sạc',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EscooterOpenChargeManualRoutingModule {}
