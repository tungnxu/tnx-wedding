import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { catchError, filter, switchMap, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { penaltyConfigurationTypeVi } from '../../../shared/constants/penalty-configuration-type-vi.constant';
import { PenaltyConfigurationType } from '../../../shared/enums/penalty-configuration-type.enum';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { ChargingItem } from '../../../shared/shared.model';
import { PenaltyEditComponent } from '../penalty-edit/penalty-edit.component';
import { PenaltyConfiguration } from '../penalty.model';
import { PenaltyApiService } from '../../../shared/services/api-services/penalty-api.service';
import { combineLatest, Observable, of } from 'rxjs';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { UiStateService } from '../../../core/services/ui-state.service';
import { IPenaltyListFiltering } from '../../../shared/interfaces/penalty-list-filter.interface';
import { getMessageEx } from '../../../shared/helpers/object.helper';

@Component({
    selector: 'emsp-penalty-list',
    templateUrl: 'penalty-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PenaltyListComponent extends BaseComponent implements OnInit {
    public requestFilter: IPenaltyListFiltering;
    public selectedKeys: string[] = [];
    public gridData: IGridData<PenaltyConfiguration[]>;
    public penaltyConfigurationType = PenaltyConfigurationType;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public createPermission$: Observable<boolean>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly penaltyApiService: PenaltyApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly authStateService: AuthStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.PenaltyConfigurationCreate);
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.PenaltyConfigurationCreate);

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                        enabled: true,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public onSelectedKeysChange(selectedKeys: string[]): void {
        this.selectedKeys = selectedKeys;
        this.cdr.detectChanges();
    }

    public getValue(items: ChargingItem[], key: string): void {
        if (!items || items.length === 0) {
            return;
        }
        return items[0][key];
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.penaltyApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    // public edit(item: PenaltyConfiguration): void {
    //     this.modalService.openModal({
    //         title: 'Chỉnh sửa',
    //         inputs: [
    //             { key: 'item', value: item },
    //             { key: 'type', value: item.type },
    //             { key: 'systemConfiguration', value: this.systemConfiguration },
    //         ],
    //         component: PenaltyEditComponent,
    //         onSubmit: () => {
    //             this.toastrService.success(this.systemConfiguration.labelConfiguration.successMessage);
    //             this.search(this.requestFilter);
    //         }
    //     }, {
    //         ignoreBackdropClick: true
    //     });
    // }

    // public delete(item: PenaltyConfiguration): void {
    //     this.modalService.confirm({
    //         title: 'Thông báo',
    //         message: 'Bạn có chắc chắn muốn xóa không?'
    //         } as IConfirmOptions
    //     ).pipe(
    //         filter(confirmed => !!confirmed),
    //         switchMap(() => this.penaltyService.delete([item.id])),
    //         tap(() => {
    //             this.toastrService.success(this.systemConfiguration.labelConfiguration.successMessage);
    //             this.search(this.requestFilter);
    //         }),
    //         takeUntil(this.destroyed$)
    //     )
    //     .subscribe();
    // }

    public add() {
        this.modalService.openModal(
            {
                title: 'Thêm mới',
                component: PenaltyEditComponent,
                onSubmit: () => {
                    // this.toastrService.success(uiConfigurations.labelConfiguration.successMessage);
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    // public deleteMultiple() {
    //     this.modalService.confirm({
    //         title: 'Thông báo',
    //         message: `Bạn có chắc chắn muốn xóa <b>${this.selectedKeys.length}</b> bản ghi đã chọn không?`
    //         } as IConfirmOptions
    //     ).pipe(
    //         filter(confirmed => !!confirmed),
    //         switchMap(() => this.penaltyService.delete(this.selectedKeys)),
    //         tap(() => {
    //             this.toastrService.success(this.systemConfiguration.labelConfiguration.successMessage);
    //             this.search(this.requestFilter);
    //         }),
    //         takeUntil(this.destroyed$)
    //     )
    //     .subscribe();
    // }

    public viewDetail(item: PenaltyConfiguration): void {
        this.modalService.openModal({
            title: 'Chi tiết',
            inputs: [
                { key: 'penaltyConfiguration', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: PenaltyEditComponent,
        });
    }

    public getPenaltyConfigurationTypeVi(type: string): string {
        return penaltyConfigurationTypeVi[type];
    }
}
