import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, map, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { PenaltyConfigurationType } from '../../../shared/enums/penalty-configuration-type.enum';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { ChargingItem } from '../../../shared/shared.model';
import { PenaltyConfiguration } from '../penalty.model';
import { PenaltyApiService } from '../../../shared/services/api-services/penalty-api.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { CustomValidators } from 'ngx-custom-validators';
import * as moment from 'moment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { penaltyConfigurationTypeVi } from '../../../shared/constants/penalty-configuration-type-vi.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { IChargingStationInfor, ICreatePenaltyConfigurationReq } from '../../../shared/interfaces/penalty-req.interface';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { ToastrService } from 'ngx-toastr';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { ChargingStationApiService } from '../../../shared/services/api-services/charging-station-api.service';

@Component({
    selector: 'emsp-penalty-edit',
    templateUrl: 'penalty-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PenaltyEditComponent extends BaseComponent implements OnInit {
    @Input() public penaltyConfiguration: PenaltyConfiguration = {};
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public bsDatepickerConfig: Partial<BsDatepickerConfig>;

    public editForm: FormGroup;
    public chargingItemGridData: IGridData<ChargingItem[]>;
    public chargingItemRequestFilter: IMainFiltering;
    public selectedChargingItems: ChargingItem[] = [];
    public penaltyConfigurationTypeVi = penaltyConfigurationTypeVi;
    public penaltyConfigurationType = PenaltyConfigurationType;
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public minDate: Date;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public save$ = new Subject<PenaltyConfiguration>();

    constructor(
        private readonly penaltyApiService: PenaltyApiService,
        private readonly chargingStationApiService: ChargingStationApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly formBuilder: FormBuilder,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.bsDatepickerConfig = {
                        dateInputFormat: uiConfigurations.clientDateFormat.toUpperCase(),
                        adaptivePosition: true,
                    };
                })
            )
            .subscribe();
        const currentDate = new Date();
        if (!this.penaltyConfiguration.id) {
            this.minDate = moment(new Date()).add(1, 'day').toDate();
        }
        this.chargingItemRequestFilter = {
            pageIndex: 0,
            pageSize: 5,
        };
        this.editForm = this.formBuilder.group({
            appliedPrice: [{ value: this.penaltyConfiguration.appliedPrice ?? '', disabled: this.viewOnly }, [Validators.required]],
            appliedDate: [
                {
                    value: this.penaltyConfiguration.appliedDate ? moment(this.penaltyConfiguration.appliedDate).toDate() : '',
                    disabled: this.viewOnly,
                },
                [Validators.required, Validators.maxLength(20), CustomValidators.date, CustomValidators.minDate(currentDate)],
            ],
            type: [this.penaltyConfiguration.type, Validators.required],
            statusEnabled: [this.penaltyConfiguration.enabled, Validators.required],
            selectedChargingItems: [null, Validators.required],
        });

        this.searchChargingItem(this.chargingItemRequestFilter);
        this.handleSave();
    }

    public searchChargingItem(request: IMainFiltering): void {
        if (this.penaltyConfiguration.id) {
            this.chargingItemGridData = {
                data: [
                    {
                        itemId: this.penaltyConfiguration.chargingStationId,
                        name: this.penaltyConfiguration.chargingStationName,
                        address: this.penaltyConfiguration.chargingStationAddress,
                    },
                ],
                total: 1,
            };
            this.cdr.detectChanges();
        } else {
            this.chargingStationApiService.search(request).subscribe((response) => {
                if (response.success) {
                    this.chargingItemGridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
            });
        }
    }

    public onSelectedItemsChange(chargingItems: ChargingItem[]): void {
        this.selectedChargingItems = chargingItems;
        if (this.selectedChargingItems.length > 0) {
            this.editForm.controls.selectedChargingItems.setErrors(null);
        } else {
            this.editForm.controls.selectedChargingItems.setErrors({ required: true });
        }
        this.cdr.detectChanges();
    }

    public onSelectType(type: string): void {
        this.penaltyConfiguration.type = parseInt(type, 10);
        this.editForm.controls.type.setErrors(null);
        this.cdr.detectChanges();
    }

    public onSelectStatus(status: boolean): void {
        this.penaltyConfiguration.enabled = status;
        this.editForm.controls.statusEnabled.setErrors(null);
        this.cdr.detectChanges();
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map((penaltyConfiguration) => this.mapPenaltyConfiguration(penaltyConfiguration)),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([penaltyConfiguration, uiConfigurations]) => {
                    return this.penaltyApiService.create(penaltyConfiguration).pipe(
                        tap((resp) => {
                            this.uiStateService.toggleShowLoading(false);
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                                this.submited.emit();
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    );
                }),
                tap(() => this.submited.emit())
            )
            .subscribe();
    }

    private mapPenaltyConfiguration(penaltyConfiguration: PenaltyConfiguration): ICreatePenaltyConfigurationReq {
        return {
            penaltyConfigurationDto: {
                chargingStations: this.mapChargings(),
                appliedDate: moment(this.editForm.controls.appliedDate.value).toDate(),
                appliedPrice: parseFloat(this.editForm.controls.appliedPrice.value),
                type: penaltyConfiguration.type,
                enabled: penaltyConfiguration.enabled,
            },
        } as ICreatePenaltyConfigurationReq;
    }

    private mapChargings(): IChargingStationInfor[] {
        const chargingPenalties = Array<IChargingStationInfor>();
        this.selectedChargingItems?.forEach((e) => {
            chargingPenalties.push({
                chargingStationId: e.itemId,
                chargingStationAddress: e.address,
                chargingStationName: e.name,
            } as IChargingStationInfor);
        });
        return chargingPenalties;
    }

    private isValid(): boolean {
        Object.keys(this.editForm.controls).forEach((key) => {
            this.editForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editForm.valid;
    }
}
