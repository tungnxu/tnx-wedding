import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SharedModule } from '../../shared/shared.module';
import { QuillModule } from 'ngx-quill';
import { PenaltyRoutingModule } from './penalty.routing';
import { PenaltyListComponent } from './penalty-list/penalty-list.component';
import { PenaltyEditComponent } from './penalty-edit/penalty-edit.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { NgxMaskModule } from 'ngx-mask';

@NgModule({
    imports: [
        PenaltyRoutingModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
        TabsModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        BsDropdownModule.forRoot(),
        NgxMaskModule.forRoot(),
    ],
    declarations: [PenaltyListComponent, PenaltyEditComponent],
    providers: [],
})
export class PenaltyModule {}
