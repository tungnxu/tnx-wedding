import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { PenaltyListComponent } from './penalty-list/penalty-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: PenaltyListComponent,
        data: {
            title: 'Cấu hình giá sạc pin',
            requiredPermission: appPermissions.PenaltyConfigurationRead,
        },
        children: [
            {
                path: 'penalties',
                component: PenaltyListComponent,
                data: {
                    title: 'Cấu hình phí phạt',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PenaltyRoutingModule {}
