import { ChargingItem } from './../../shared/shared.model';

export class PenaltyConfiguration {
    id?: string;
    appliedDate?: Date;
    type?: number;
    appliedPrice?: number;
    enabled?: boolean = true;
    description?: string;
    createdDate?: string;
    chargingStationId?: string;
    chargingStationName?: string;
    chargingStationAddress?: string;
    chargings?: ChargingItem[];
}
