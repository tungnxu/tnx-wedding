import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import {
    reportBookingProblemReasonTypeVi,
    reportBookingProblemReviewStatusVi,
} from '../../../shared/constants/report-booking-problem-review-status-vi.constant';
import { ReportBookingProblemReviewStatus } from '../../../shared/enums/report-booking-problem-review-status.enum';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { ChargingBookingApiService } from '../../../shared/services/api-services/charging-booking-api.service';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { ReportBookingProblemDetailComponent } from '../report-booking-problem-detail/report-booking-problem-detail.component';
import { ReportBookingProblem } from '../report-booking-problem.model';

@Component({
    selector: 'emsp-report-booking-list',
    templateUrl: './report-booking-problem-list.component.html',
    styleUrls: ['./report-booking-problem-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportBookingProblemListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public selectedKeys: string[] = [];
    public gridData: IGridData<ReportBookingProblem[]>;
    public reportBookingProblemReviewStatusVi = reportBookingProblemReviewStatusVi;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly chargingBookingApiService: ChargingBookingApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        key: '',
                        customerId: '',
                        status: '',
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.chargingBookingApiService
            .getReportBookingProblems(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public viewDetail(item: ReportBookingProblem): void {
        this.modalService.openModal({
            title: 'Chi tiết report booking ' + item.id,
            inputs: [
                { key: 'reportBookingProblem', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: ReportBookingProblemDetailComponent,
            onSubmit: (resp) => {
                this.search(this.requestFilter);
            },
        });
    }

    public edit(item: ReportBookingProblem): void {
        this.modalService.openModal({
            title: 'Chi tiết report booking ' + item.id,
            inputs: [{ key: 'reportBookingProblem', value: item }],
            component: ReportBookingProblemDetailComponent,
            onSubmit: (resp) => {
                this.search(this.requestFilter);
            },
        });
    }

    public getReportBookingProblemReviewStatusName(status: number): string {
        return reportBookingProblemReviewStatusVi[status];
    }

    public checkShowEditOrViewButton(status: number): boolean {
        if (status === ReportBookingProblemReviewStatus.DEFAULT) {
            return true;
        } else {
            return false;
        }
    }

    public getReportBookingProblemReviewStatusClass(status: number): string {
        switch (status) {
            case ReportBookingProblemReviewStatus.DEFAULT:
                return 'not_charge_yet';

            case ReportBookingProblemReviewStatus.REJECTED:
                return 'charge_cancel';

            case ReportBookingProblemReviewStatus.APPROVED:
                return 'charge_completed';
        }
    }

    public onSelectStatus(status: string): void {
        this.requestFilter.status = status;
    }

    public getReportBookingProblemReasonType(type: string): string {
        return reportBookingProblemReasonTypeVi[type];
    }
}
