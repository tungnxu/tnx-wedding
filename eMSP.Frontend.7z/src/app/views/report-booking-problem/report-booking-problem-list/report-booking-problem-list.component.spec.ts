import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportBookingProblemListComponent } from './report-booking-problem-list.component';

describe('ReportBookingProblemListComponent', () => {
    let component: ReportBookingProblemListComponent;
    let fixture: ComponentFixture<ReportBookingProblemListComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ReportBookingProblemListComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ReportBookingProblemListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
