import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { ReportBookingProblemListComponent } from './report-booking-problem-list/report-booking-problem-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: ReportBookingProblemListComponent,
        data: {
            title: 'Quản lý khiếu nại',
            requiredPermission: appPermissions.ChargingBookingRead,
        },
        children: [
            {
                path: 'report-booking-problems',
                component: ReportBookingProblemListComponent,
                data: {
                    title: 'Báo cáo vi phạm vị trí sạc bị chiếm',
                },
            },
            // {
            //     path: 'batteries',
            //     component: ReportBatteryComponent,
            //     data: {
            //         title: 'Approve/Reject report booking'
            //     },
            // }
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ReportBookingProblemRoutingModule {}
