import { ReviewReportBookingProblemReq } from './../../../shared/interfaces/review-report-booking-problem-req.interface';
import { debounceTime, map, takeUntil, switchMap, catchError, tap, withLatestFrom } from 'rxjs/operators';
import { Observable, forkJoin, Subject, of } from 'rxjs';
import { ReportBookingProblem } from './../report-booking-problem.model';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { Gallery } from 'angular-gallery';
import { FileApiService } from '../../../shared/services/api-services/file-api.service';
import { ChargingBookingApiService } from '../../../shared/services/api-services/charging-booking-api.service';
import { reportBookingProblemReasonTypeVi } from '../../../shared/constants/report-booking-problem-review-status-vi.constant';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { ToastrService } from 'ngx-toastr';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';

@Component({
    selector: 'emsp-report-booking-problem-detail',
    templateUrl: './report-booking-problem-detail.component.html',
    styleUrls: ['./report-booking-problem-detail.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ReportBookingProblemDetailComponent extends BaseComponent implements OnInit {
    @Input() public reportBookingProblem: ReportBookingProblem;
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<ReportBookingProblem> = new EventEmitter<ReportBookingProblem>();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public images$: Observable<string[]>;
    public review$ = new Subject<boolean>();

    constructor(
        private readonly gallery: Gallery,
        private readonly fileApiService: FileApiService,
        private readonly chargingBookingApiService: ChargingBookingApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly toastrService: ToastrService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.images$ = forkJoin(
            (this.reportBookingProblem.images || []).map((imageName) => this.fileApiService.getImage(this.reportBookingProblem.vehicleId, imageName))
        );
        this.handleReview();
    }

    public showGallery(index: number, images: string[]): void {
        const galleryPropety = {
            images: images.map((i) => ({ path: i })),
            index,
        };
        this.gallery.load(galleryPropety);
    }

    public filterThumbnails(images: string[]): string[] {
        return images.filter((img, index) => index < 4);
    }

    private handleReview(): void {
        this.review$
            .pipe(
                debounceTime(300),
                map(
                    (approve) =>
                        ({
                            id: this.reportBookingProblem.id,
                            approve,
                            comment: this.reportBookingProblem.comment || '',
                        } as ReviewReportBookingProblemReq)
                ),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.chargingBookingApiService.reviewReportBookingProblem(req).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                                this.submited.emit();
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public getReportBookingProblemReasonType(type: string): string {
        return reportBookingProblemReasonTypeVi[type];
    }
}
