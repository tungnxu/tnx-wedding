import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportBookingProblemDetailComponent } from './report-booking-problem-detail.component';

describe('ReportBookingProblemDetailComponent', () => {
    let component: ReportBookingProblemDetailComponent;
    let fixture: ComponentFixture<ReportBookingProblemDetailComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ReportBookingProblemDetailComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ReportBookingProblemDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
