import { ReportBookingProblemReviewStatus } from '../../shared/enums/report-booking-problem-review-status.enum';
import { ReportBookingProblemStatus } from '../../shared/enums/report-booking-problem-status.enum';

export class ReportBookingProblem {
    public id: string;
    public locationId: string;
    public locationName: string;
    public locationAddress: string;
    public fullName: string;
    public phoneNumber: string;
    public email: string;
    public plateNumber: string;
    public address: string;
    public customerId: string;
    public vehicleId: string;
    public bookingId: string;
    public reasonType: string;
    public content: string;
    public images: string[];
    public status: ReportBookingProblemStatus;
    public reviewStatus: ReportBookingProblemReviewStatus;
    public comment: string;
    public createdDate: Date;
}
