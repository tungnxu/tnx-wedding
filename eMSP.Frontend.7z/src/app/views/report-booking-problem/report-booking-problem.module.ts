import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportBookingProblemListComponent } from './report-booking-problem-list/report-booking-problem-list.component';
import { ReportBookingProblemRoutingModule } from './report-booking-problem.routing';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from '../../shared/shared.module';
import { ReportBookingProblemDetailComponent } from './report-booking-problem-detail/report-booking-problem-detail.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

@NgModule({
    declarations: [ReportBookingProblemListComponent, ReportBookingProblemDetailComponent],
    imports: [CommonModule, ReportBookingProblemRoutingModule, FormsModule, HttpClientModule, SharedModule, BsDropdownModule.forRoot()],
})
export class ReportBookingProblemModule {}
