import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { Bill } from '../../../shared/models/bill.model';
import { chargingBookingStatusVi } from '../../../shared/constants/charging-booking-status-vi.constant';
import { DebtDetailComponent } from '../debt-detail/debt-detail.component';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { ModalService } from '../../../shared/services/modal.service';
import { IBillReportByCustomerResponse } from '../../../shared/interfaces/bill-report-by-customer-resp.interface';
import { BillApiService } from '../../../shared/services/api-services/bill-api.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { catchError, debounceTime, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { IInvoiceRegisterSearchRequest } from '../../../shared/interfaces/invoice-register-req.interface';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ToastrService } from 'ngx-toastr';
import { ExportApiService } from '../../../shared/services/api-services/export-api.service';
import { MIMEType } from '../../../shared/enums/mime-type.enum';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { errorMessages } from '../../../shared/constants/error-messages.constant';

@Component({
    selector: 'emsp-bill-list',
    templateUrl: './debt-list.component.html',
    styleUrls: ['./debt-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DebtListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public invoiceFilter: IInvoiceRegisterSearchRequest;
    public gridData: IGridData<IBillReportByCustomerResponse[]>;

    public customerIdSuggestions$: Observable<any[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public updatePermission$: Observable<boolean>;

    public export$ = new Subject<IBillReportByCustomerResponse>();
    constructor(
        private readonly billApiService: BillApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly authStateService: AuthStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly exportApiService: ExportApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.BillUpdate);

        // combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.requestFilter = {
                        customerId: '',
                        vehicleId: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();

        this.export$
            .pipe(
                debounceTime(300),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([req, uiConfigurations]) =>
                    this.exportApiService.exportDebtsReport(req).pipe(
                        tap((resp) => {
                            if (resp) {
                                const blob = new Blob([resp], { type: MIMEType.Excel });
                                const url = window.URL.createObjectURL(blob);
                                window.location.href = url;
                                this.toastrService.success(textMessages.success_message);
                            } else {
                                this.toastrService.error('errorMessages.error_mes_export_null');
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.billApiService
            .getCustomerBills(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    public viewDetail(item: Bill): void {
        this.modalService.openModal(
            {
                title: `Chi tiết công nợ khách hàng - ${item.fullName} - ${item.customerId}`,
                inputs: [
                    { key: 'bill', value: item },
                    { key: 'requestFilter', value: { ...this.requestFilter } },
                    { key: 'invoiceFilter', value: { ...this.invoiceFilter } },
                ],
                component: DebtDetailComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public getChargingStatusName(status: number): string {
        return chargingBookingStatusVi[status];
    }
}
