import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DebtListComponent } from './debt-list/debt-list.component';
import { BillRoutingModule } from './bill.routing';
import { SharedModule } from '../../shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { DebtDetailComponent } from './debt-detail/debt-detail.component';
import { FormsModule } from '@angular/forms';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { BillListComponent } from './bill-list/bill-list.component';
import { BillWrapperComponent } from './bill-wrapper/bill-wrapper.component';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

@NgModule({
    imports: [CommonModule, FormsModule, BillRoutingModule, SharedModule, HttpClientModule, TypeaheadModule.forRoot(), BsDropdownModule.forRoot()],
    declarations: [DebtListComponent, DebtDetailComponent, BillListComponent, BillWrapperComponent],
    providers: [],
})
export class BillModule {}
