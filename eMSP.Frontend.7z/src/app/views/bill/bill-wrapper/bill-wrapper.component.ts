import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'emsp-bill-wrapper',
    templateUrl: './bill-wrapper.component.html',
    styleUrls: ['./bill-wrapper.component.css'],
})
export class BillWrapperComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
