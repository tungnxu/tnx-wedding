import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { PartnerListComponent } from './partner-list/partner-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: PartnerListComponent,
        data: {
            title: 'Partner',
            // requiredPermission: appPermissions.PartnerRead,
        },
        children: [
            {
                path: 'configuration',
                component: PartnerListComponent,
                data: {
                    title: 'Quản lý đối tác',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class PartnerRoutingModule {}
