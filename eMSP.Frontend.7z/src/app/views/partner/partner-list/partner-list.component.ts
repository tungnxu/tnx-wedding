import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { DatePipe } from '@angular/common';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { Partner } from '../../../shared/models/partner.model';
import { ModalService } from '../../../shared/services/modal.service';
import { PartnerEditComponent } from '../partner-edit/partner-edit.component';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { combineLatest, Observable } from 'rxjs';
import { takeUntil, tap } from 'rxjs/operators';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';

@Component({
    selector: 'emsp-partner-list',
    templateUrl: './partner-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [DatePipe],
})
export class PartnerListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public gridData: IGridData<Partner[]>;

    public selectedKeys: string[] = [];
    // public createPermission$: Observable<boolean>;
    // public updatePermission$: Observable<boolean>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public mockData: Partner[] = [
        {
            partnerCode: 'MTD0123455',
            partnerName: '3T',
            headContact: 'HD/2021/3T-01',
            email: 'string',
            phoneNumber: 'string',
            chargingItem: null,
            paymentStartDate: '2021-10-21T08:29:15.056Z',
            contractEndDate: '2021-10-21T08:29:15.056Z',
            fixPricePaymentCycle: 0,
            fixPricePaymentType: 1,
            priceRentalCar: 0,
            priceRentalMoto: 0,
            sharingPaymentCycle: 0,
            sharingPaymentType: 1,
            electricityPaymentCycle: 0,
            electricityPaymentType: 1,
            sharingRatio: 0,
            electricityPrice: 0,
            isLocked: 0,
            lockedDate: '2021-10-21T08:29:15.056Z',
        },
        {
            partnerCode: 'MTD0123455',
            partnerName: '3T',
            headContact: 'HD/2021/3T-01',
            email: 'string',
            phoneNumber: 'string',
            chargingItem: null,
            paymentStartDate: '2021-10-21T08:29:15.056Z',
            contractEndDate: '2021-10-21T08:29:15.056Z',
            fixPricePaymentCycle: 0,
            fixPricePaymentType: 1,
            priceRentalCar: 0,
            priceRentalMoto: 0,
            sharingPaymentCycle: 0,
            sharingPaymentType: 1,
            electricityPaymentCycle: 0,
            electricityPaymentType: 1,
            sharingRatio: 0,
            electricityPrice: 0,
            isLocked: 1,
            lockedDate: '2021-10-21T08:29:15.056Z',
        },
    ];

    constructor(
        // public readonly authStateService: AuthStateService,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly cdr: ChangeDetectorRef
    ) {
        super();
    }

    ngOnInit(): void {
        // this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.PartnerCreate);
        // this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.PartnerCreate);
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                })
            )
            .subscribe();
        this.gridData = {
            data: this.mockData,
            total: 2,
        };
        this.cdr.detectChanges();
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Tạo mới đối tác',
                component: PartnerEditComponent,
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public lock(item: Partner): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn tạm dừng không?',
            } as IConfirmOptions)
            .subscribe();
    }

    public unlock(item: Partner): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn tiếp tục không?',
            } as IConfirmOptions)
            .subscribe();
    }

    public viewDetail(item: Partner): void {
        this.modalService.openModal({
            title: 'Chi tiết đối tác',
            inputs: [
                { key: 'batterySubscription', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: PartnerEditComponent,
        });
    }
}
