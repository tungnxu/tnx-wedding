import { Component, OnInit, ChangeDetectionStrategy, Input, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { ChargingItem } from '../../../shared/shared.model';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { BillingCycleType } from '../../../shared/models/partner.model';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment';
import { partnerPaymentTypeVi } from '../../../shared/constants/partner.constant';
import { PartnerPaymentType } from '../../../shared/enums/partner-configuration-type.enum';
import { ToastrService } from 'ngx-toastr';
import { catchError, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ChargingStationApiService } from '../../../shared/services/api-services/charging-station-api.service';

@Component({
    selector: 'emsp-partner-edit',
    templateUrl: './partner-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PartnerEditComponent extends BaseComponent implements OnInit {
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public chargingItemRequestFilter: IMainFiltering;
    // public gridDataColumn: IGridData<ChargingStation[]>;
    public columnRequestFilter: IMainFiltering;
    public chargingItemGridData: IGridData<ChargingItem[]>;
    public selectedChargingItems: ChargingItem[] = [];
    public bsDatepickerConfig: Partial<BsDatepickerConfig>;
    public minDate: Date;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public selectFixedCharge: string;
    public selectSharingFee: string;
    public selectComprehensiveFee: string;
    public selectComprehensiveFeeType: string;
    public selectFixedChargeType: string;
    public selectSharingFeeType: string;

    public paymentCycleType = PartnerPaymentType;
    public paymentCycleTypeKeys = [];

    public billingCycleType: BillingCycleType[] = [
        {
            billingCycleKey: 1,
            billingCycleValue: 'Trả thẳng',
        },
        {
            billingCycleKey: 2,
            billingCycleValue: 'Đặt cọc',
        },
        {
            billingCycleKey: 3,
            billingCycleValue: 'Trả góp',
        },
    ];

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly chargingStationApiService: ChargingStationApiService,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService
    ) {
        super();
        this.paymentCycleTypeKeys = Object.keys(this.paymentCycleType).filter((f) => !isNaN(Number(f)));
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.bsDatepickerConfig = {
                        dateInputFormat: uiConfigurations.clientDateFormat.toUpperCase(),
                        adaptivePosition: true,
                    };
                })
            )
            .subscribe();
        this.minDate = moment(new Date()).add(1, 'day').toDate();
        this.chargingItemRequestFilter = {
            pageIndex: 0,
            pageSize: 5,
        };
        this.searchChargingItem(this.chargingItemRequestFilter);
    }

    public searchChargingItem(request: IMainFiltering): void {
        this.chargingStationApiService
            .search(request)
            .pipe(
                withLatestFrom(this.uiConfigurations$),
                tap(([response]) => {
                    if (response?.success) {
                        this.chargingItemGridData = {
                            data: response.data.items,
                            total: response.data.total,
                        };
                        this.cdr.detectChanges();
                    }
                }),
                catchError((ex) => {
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe();
    }

    public onSelectedItemsChange(chargingItems: ChargingItem[]): void {
        this.selectedChargingItems = chargingItems;
    }

    public onSelectFixedCharge(item: string): void {
        this.selectFixedCharge = item + ' tháng';
    }

    public onSelectSharingFee(item: string): void {
        this.selectSharingFee = item + ' tháng';
    }

    public onSelectComprehensiveFee(item: string): void {
        this.selectComprehensiveFee = item + ' tháng';
    }

    public onSelectComprehensiveFeeType(item: string): void {
        this.selectComprehensiveFeeType = item;
    }

    public onSelectFixedChargeType(item: string): void {
        this.selectFixedChargeType = item;
    }

    public onSelectSharingFeeType(item: string): void {
        this.selectSharingFeeType = item;
    }

    public getTypeOfPaymentName(item: number): string {
        return partnerPaymentTypeVi[item];
    }
}
