import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SharedModule } from '../../shared/shared.module';
import { QuillModule } from 'ngx-quill';
import { PartnerListComponent } from './partner-list/partner-list.component';
import { PartnerEditComponent } from './partner-edit/partner-edit.component';
import { PartnerApiService } from '../../shared/services/api-services/partner-api.service';
import { PartnerRoutingModule } from './partner.routing';

import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

@NgModule({
    imports: [
        PartnerRoutingModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        TabsModule.forRoot(),
        PaginationModule.forRoot(),
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        CollapseModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        BsDropdownModule.forRoot(),
    ],
    declarations: [PartnerListComponent, PartnerEditComponent],
})
export class PartnerModule {}
