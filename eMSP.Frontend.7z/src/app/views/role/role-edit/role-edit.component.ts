import { RoleApiService } from './../../../shared/services/api-services/role-api.service';
import { UserPermissionApiService } from './../../../shared/services/api-services/user-permission-api.service';
import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, OnInit, ChangeDetectorRef } from '@angular/core';
import { Subject, Observable, of } from 'rxjs';
import { debounceTime, takeUntil, tap, withLatestFrom, switchMap, catchError, map, filter } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { Role } from '../../../shared/models/role.model';
import { IAppPermissionsViewModel, IPermissionViewModel } from '../../../shared/view-models/app-permissions.viewModel';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UiStateService } from '../../../core/services/ui-state.service';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { Response } from '../../../shared/models/response.model';

@Component({
    selector: 'emsp-role-edit',
    templateUrl: './role-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RoleEditComponent extends BaseComponent implements OnInit {
    @Input() public role: Role;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<Role> = new EventEmitter<Role>();

    public editForm: FormGroup;

    public appPermissions$: Observable<Response<IAppPermissionsViewModel[]>>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public save$ = new Subject<IAppPermissionsViewModel[]>();
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;

    constructor(
        private readonly userPermissionApiService: UserPermissionApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly formBuilder: FormBuilder,
        private readonly cdr: ChangeDetectorRef,
        private readonly roleApiService: RoleApiService,
        private readonly toastrService: ToastrService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.appPermissions$ = this.userPermissionApiService.getAllPermissions().pipe(map((list) => this.mapSelectedItem(list)));

        this.editForm = this.formBuilder.group({
            name: [this.role?.name ?? '', [Validators.required]],
        });

        this.handleSave();
    }

    private mapSelectedItem(appPermissions: IAppPermissionsViewModel[]): any {
        if (!this.role || this.role.permissions?.length <= 0) {
            return appPermissions;
        }

        return appPermissions.map((groupPermission) => {
            const list = {
                ...groupPermission,
                permissions: groupPermission.permissions.map((item) => {
                    return { ...item, checked: this.role.permissions.some((p) => p === item.key) };
                }),
            };
            list.masterSelected = list.permissions.every((item) => item.checked);
            return list;
        });
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([appPermissions, uiConfigurations]) => {
                    const selectedPermissions = appPermissions.flatMap((appPermission) =>
                        appPermission.permissions.filter((x) => x.checked).map((x) => x.key)
                    );
                    if (!this.role?.id) {
                        return this.roleApiService.create({ name: this.editForm.controls.name.value, permissions: selectedPermissions }).pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        );
                    }

                    return this.roleApiService
                        .update({ id: this.role.id, name: this.editForm.controls.name.value, permissions: selectedPermissions })
                        .pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                    this.uiStateService.toggleShowLoading(false);
                                }
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public checkOrUncheckAll(checkAll: boolean, list: IPermissionViewModel[]): void {
        list = list.map((permission) => {
            permission.checked = checkAll;
            return permission;
        });
    }

    public updateCheckAll(list: IAppPermissionsViewModel): void {
        list.masterSelected = list.permissions.every((item) => item.checked);
    }

    private isValid(): boolean {
        Object.keys(this.editForm.controls).forEach((key) => {
            this.editForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editForm.valid;
    }
}
