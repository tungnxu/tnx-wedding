import { UiStateService } from '../../../core/services/ui-state.service';
import { RoleApiService } from './../../../shared/services/api-services/role-api.service';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, filter, map, switchMap, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { Role } from '../../../shared/models/role.model';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { RoleEditComponent } from '../role-edit/role-edit.component';
import { IAppPermissionsViewModel } from '../../../shared/view-models/app-permissions.viewModel';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { getDetailRole } from '../../../shared/helpers/permission.helper';
import { Response } from '../../../shared/models/response.model';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ToastrService } from 'ngx-toastr';
import { textMessages } from '../../../shared/constants/text-messages.constant';

@Component({
    selector: 'emsp-role-list',
    templateUrl: './role-list.component.html',
    styleUrls: ['./role-list.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RoleListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public gridData: IGridData<Role[]>;

    public selectedKeys: string[] = [];

    public appPermissions$: Observable<IAppPermissionsViewModel[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public getDetailRole = getDetailRole;

    constructor(
        private readonly userPermissionApiService: UserPermissionApiService,
        private readonly modalService: ModalService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly roleApiService: RoleApiService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.appPermissions$ = this.userPermissionApiService.getAllPermissions();
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.roleApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                this.uiStateService.toggleShowLoading(false);
                if (response.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                }
            });
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Thêm vai trò',
                inputs: [],
                component: RoleEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public edit(role: Role): void {
        this.modalService.openModal(
            {
                title: 'Sửa vai trò',
                inputs: [{ key: 'role', value: role }],
                component: RoleEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(role: Role): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn xóa vai trò <b>' + role.name + '</b> không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() => this.roleApiService.delete(role.id)),
                tap(() => {
                    this.toastrService.success(textMessages.success_message);
                    this.search(this.requestFilter);
                }),
                catchError((ex) => {
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }
}
