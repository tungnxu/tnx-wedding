import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { RoleRoutingModule } from './role.routing';
import { CommonModule } from '@angular/common';
import { RoleListComponent } from './role-list/role-list.component';
import { RoleEditComponent } from './role-edit/role-edit.component';
import { AccordionModule } from 'ngx-bootstrap/accordion';

@NgModule({
    imports: [RoleRoutingModule, CommonModule, FormsModule, ReactiveFormsModule, HttpClientModule, SharedModule, AccordionModule.forRoot()],
    declarations: [RoleListComponent, RoleEditComponent],
})
export class RoleModule {}
