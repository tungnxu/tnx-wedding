import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { RoleListComponent } from './role-list/role-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: RoleListComponent,
        data: {
            title: 'Hệ thống',
            requiredPermission: appPermissions.AdminOnly,
        },
        children: [
            {
                path: 'roles',
                component: RoleListComponent,
                data: {
                    title: 'Vai trò',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class RoleRoutingModule {}
