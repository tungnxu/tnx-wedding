import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable, combineLatest, of } from 'rxjs';
import { takeUntil, tap, catchError, filter, map, switchMap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { batterySubscriptionNewStatusVi } from '../../../shared/constants/battery-subscription.constant';
import { BatterySubscriptionStatus } from '../../../shared/enums/battery-subscription-status.enum';
import { EWhiteListType } from '../../../shared/enums/white-list-type.enum';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { IChangeWhiteListStatusRQ } from '../../../shared/interfaces/white-list-configuration-req.interface';
import { WhiteList } from '../../../shared/models/whitelist-configuration.model';
import { OperatorApiService } from '../../../shared/services/api-services/operator-battery.service';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { OpenChargeManualEditComponent } from '../open-charge-manual-edit/open-charge-manual-edit.component';

@Component({
    selector: 'emsp-open-charge-manual-list',
    templateUrl: './open-charge-manual-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OpenChargeManualListComponent extends BaseComponent implements OnInit {
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public requestFilter: IMainFiltering;
    public pageSizeGrid$: Observable<number>;
    public gridData: IGridData<WhiteList[]>;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;
    public batterySubscriptionStatusVi = batterySubscriptionNewStatusVi;

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly operatorApiService: OperatorApiService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                        type: EWhiteListType.CHARGING,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.operatorApiService
            .whiteListSearch(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Mở chặn sạc',
                inputs: [],
                component: OpenChargeManualEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(item: WhiteList): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: `Bạn có chắc chắn muốn đổi trạng thái SOC không?`,
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                map(() => this.mapIChangeWhiteListStatusRQ(item)),
                switchMap((request) =>
                    this.operatorApiService.whiteListChangeStatus(request).pipe(
                        tap((resp) => {
                            if (resp.success) {
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.search(this.requestFilter);
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public mapIChangeWhiteListStatusRQ(item: WhiteList): IChangeWhiteListStatusRQ {
        return {
            id: item.id,
            isActive: !item.isActive,
        } as IChangeWhiteListStatusRQ;
    }

    public getStatusClass(isActive: boolean): string {
        if (isActive) {
            return 'active_stt';
        }
        return 'canceled_stt';
    }

    public getStatusName(isActive: boolean): string {
        return batterySubscriptionNewStatusVi[isActive ? BatterySubscriptionStatus.Active : BatterySubscriptionStatus.Deactivate];
    }
}
