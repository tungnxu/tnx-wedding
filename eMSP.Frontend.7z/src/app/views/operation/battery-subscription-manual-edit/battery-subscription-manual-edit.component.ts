import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { BatterySubscription } from '../../../shared/models/battery-subscription.model';
import { OperatorApiService } from '../../../shared/services/api-services/operator-battery.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { BatterySubscriptionApiService } from '../../../shared/services/api-services/battery-subscription-api.service';
import { BatterySubscriptionPackage } from '../../../shared/models/battery-subscription-package.model';
import { IUpdatePackageTypeRQ } from '../../../shared/interfaces/operator-change-battery-subscription-rq.interface';

@Component({
    selector: 'emsp-battery-subscription-manual-edit',
    templateUrl: './battery-subscription-manual-edit.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BatterySubscriptionManualEditComponent extends BaseComponent implements OnInit {
    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public vehicleID: string;
    public filter$ = new Subject<void>();
    public batterySubscription: BatterySubscription;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;
    public editFromGroup: FormGroup;
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;
    public save$ = new Subject<BatterySubscription>();
    public batterySubscriptionPackageSelect: BatterySubscriptionPackage;
    public batterySusbcriptionPakages: BatterySubscriptionPackage[];

    constructor(
        private readonly formBuilder: FormBuilder,
        private readonly uiStateService: UiStateService,
        private readonly operatorApiService: OperatorApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly batterySubscriptionApiService: BatterySubscriptionApiService
    ) {
        super();
    }

    ngOnInit(): void {
        this.editFromGroup = this.formBuilder.group({
            ticketID: [null, Validators.required],
            packageType: [this.batterySubscriptionPackageSelect, Validators.required],
        });

        this.handleSave();
    }

    public filterByVin(): void {
        this.uiStateService.toggleShowLoading(true);
        this.operatorApiService
            .getSubscription(this.vehicleID)
            .pipe(
                catchError((ex) => {
                    this.batterySubscription = null;
                    this.batterySusbcriptionPakages = null;
                    this.batterySubscriptionPackageSelect = null;
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    this.cdr.detectChanges();
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.batterySubscription = response.data?.subscriptionInfo;
                    this.getPackageType(this.batterySubscription?.id);
                }
            });
    }

    private getPackageType(id: string): void {
        this.batterySubscriptionApiService
            .searchPackage({ id })
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.batterySusbcriptionPakages = response.data;
                    this.removeExitsBatterySusbcriptionPakages(this.batterySusbcriptionPakages);
                    this.cdr.detectChanges();
                }
                this.uiStateService.toggleShowLoading(false);
            });
    }

    //chỉ hiển thị gói cước khác với khói cước xe đang dùng
    private removeExitsBatterySusbcriptionPakages(dataList: BatterySubscriptionPackage[]): void {
        this.batterySusbcriptionPakages = dataList.filter((data) => data.packageType !== this.batterySubscription.packageType);
    }

    public enter(event: KeyboardEvent): void {
        if (event && (event.code === 'Enter' || event.code === 'NumpadEnter')) {
            this.filterByVin();
        }
    }

    public getPackageTypeName(type: number): string {
        return batterySubscriptionPackageTypeVi[type];
    }

    public changeDropdownPakageType(batterySubscriptionPackage: BatterySubscriptionPackage): void {
        this.batterySubscriptionPackageSelect = batterySubscriptionPackage;
        this.cdr.detectChanges();
        this.editFromGroup.controls.packageType.setErrors(null);
    }

    public refreshPackageType(): void {
        this.batterySubscriptionPackageSelect = null;
    }

    private isValid(): boolean {
        Object.keys(this.editFromGroup.controls).forEach((key) => {
            this.editFromGroup.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editFromGroup.valid;
    }

    public handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map(() => this.mapUpdatePackageTypeObj()),
                tap((batterySubscription) => {
                    this.uiStateService.toggleShowLoading(true);
                    return this.operatorApiService
                        .updatePackageType(batterySubscription)
                        .pipe(
                            tap((response) => {
                                if (response.success) {
                                    this.submited.emit();
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        )
                        .subscribe();
                })
            )
            .subscribe();
    }

    private mapUpdatePackageTypeObj(): IUpdatePackageTypeRQ {
        return {
            subscriptionId: this.batterySubscription?.id,
            ticketId: this.editFromGroup.controls.ticketID?.value.toString(),
        } as IUpdatePackageTypeRQ;
    }
}
