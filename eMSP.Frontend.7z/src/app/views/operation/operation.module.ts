import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { SharedModule } from '../../shared/shared.module';
import { OperationRoutingModule } from './operation.routing';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { OperationWrapperComponent } from './operation-wrapper/operation-wrapper.component';
import { BatterySubscriptionManualEditComponent } from './battery-subscription-manual-edit/battery-subscription-manual-edit.component';
import { ChangeBatterySubscriptionManualComponent } from './battery-subscription-manual-change/battery-subscription-manual-change.component';
import { OpenTargetSOCEditComponent } from './open-target-soc-edit/open-target-soc-edit.component';
import { OpenTargetSOCListComponent } from './open-target-soc-list/open-target-soc-list.component';
import { OpenChargeManualEditComponent } from './open-charge-manual-edit/open-charge-manual-edit.component';
import { OpenChargeManualListComponent } from './open-charge-manual-list/open-charge-manual-list.component';

@NgModule({
    imports: [
        OperationRoutingModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        SharedModule,
        BsDropdownModule.forRoot(),
        ReactiveFormsModule,
    ],
    declarations: [
        OperationWrapperComponent,
        ChangeBatterySubscriptionManualComponent,
        BatterySubscriptionManualEditComponent,
        OpenTargetSOCEditComponent,
        OpenTargetSOCListComponent,
        OpenChargeManualListComponent,
        OpenChargeManualEditComponent,
    ],
    providers: [],
})
export class OperationModule {}
