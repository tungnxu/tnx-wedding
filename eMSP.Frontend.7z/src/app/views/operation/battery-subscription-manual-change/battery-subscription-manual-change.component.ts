import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { batterySubscriptionPackageTypeVi } from '../../../shared/constants/battery-subscription-package.constant';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { OperatorBatteryPackage } from '../../../shared/models/operator.model';
import { OperatorApiService } from '../../../shared/services/api-services/operator-battery.service';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { BatterySubscriptionManualEditComponent } from '../battery-subscription-manual-edit/battery-subscription-manual-edit.component';
@Component({
    selector: 'emsp-change-battery-subscription-manual',
    templateUrl: './battery-subscription-manual-change.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChangeBatterySubscriptionManualComponent extends BaseComponent implements OnInit {
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public requestFilter: IMainFiltering;
    public pageSizeGrid$: Observable<number>;
    public gridData: IGridData<OperatorBatteryPackage[]>;
    public batterySubscriptionPackageTypeVi = batterySubscriptionPackageTypeVi;

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly operatorApiService: OperatorApiService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.operatorApiService
            .searchChangePackage(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    console.log(this.gridData);
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Đổi gói cước',
                inputs: [],
                component: BatterySubscriptionManualEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }
}
