import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { ChangeBatterySubscriptionManualComponent } from './battery-subscription-manual-change/battery-subscription-manual-change.component';
import { OpenChargeManualListComponent } from './open-charge-manual-list/open-charge-manual-list.component';
import { OpenTargetSOCListComponent } from './open-target-soc-list/open-target-soc-list.component';
import { OperationWrapperComponent } from './operation-wrapper/operation-wrapper.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: OperationWrapperComponent,
        data: {
            title: 'Quản lý giao dịch',
            requiredPermission: appPermissions.ChargingBookingRead,
        },
        children: [
            {
                path: 'change-battery-subscription-manual',
                component: ChangeBatterySubscriptionManualComponent,
                data: {
                    title: 'Đổi gói cước thuê pin trong kỳ cước hiện tại',
                },
            },
            {
                path: 'open-charge-manual-list',
                component: OpenChargeManualListComponent,
                data: {
                    title: 'Mở chặn sạc',
                },
            },
            {
                path: 'open-target-soc-list',
                component: OpenTargetSOCListComponent,
                data: {
                    title: 'Mở target SOC',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class OperationRoutingModule {}
