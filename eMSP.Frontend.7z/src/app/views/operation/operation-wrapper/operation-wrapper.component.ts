import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'emsp-operation-wrapper',
    templateUrl: './operation-wrapper.component.html',
})
export class OperationWrapperComponent implements OnInit {
    constructor() {}

    ngOnInit(): void {}
}
