import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from 'ngx-custom-validators';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, filter, map, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { JobApiService } from '../../../shared/services/api-services/job-api.service';
import { Job } from '../job.model';
import * as moment from 'moment';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { ToastrService } from 'ngx-toastr';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { jobTypeEn } from '../../../shared/constants/job-type.constant';
import { ICreateOrUpdateJobReq } from '../../../shared/interfaces/job-req.interface';

@Component({
    selector: 'emsp-job-edit',
    templateUrl: 'job-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [DatePipe],
})
export class JobEditComponent extends BaseComponent implements OnInit {
    @Input() public job: Job = {};

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public editForm: FormGroup;
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public showWarning = false;
    public minDate: Date;
    public bsDatepickerConfig: Partial<BsDatepickerConfig>;
    public save$ = new Subject<Job>();
    public jobType = jobTypeEn;
    public fromDateTime: Date = new Date();

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly jobApiService: JobApiService,
        private readonly formBuilder: FormBuilder,
        private readonly datepipe: DatePipe,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.bsDatepickerConfig = {
                        dateInputFormat: uiConfigurations.clientDateFormat.toUpperCase(),
                        adaptivePosition: true,
                    };
                })
            )
            .subscribe();

        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        const currentDate = new Date();
        if (!this.job.id) {
            this.minDate = moment(new Date()).add(1, 'day').toDate();
        } else {
            this.minDate = moment(this.job.startDate).toDate();
        }
        this.editForm = this.formBuilder.group({
            name: [this.job.name, [Validators.required, Validators.maxLength(255), Validators.minLength(2)]],
            key: [this.job.key, [Validators.required, Validators.maxLength(255), Validators.minLength(2)]],
            appliedDate: [
                this.job.startDate ? moment(this.job.startDate).toDate() : '',
                [
                    Validators.required,
                    Validators.maxLength(10),
                    CustomValidators.date,
                    CustomValidators.minDate(this.job.id ? moment(this.job.startDate).add(-1, 'day').toDate() : currentDate),
                ],
            ],
            typeJob: [this.job.type, Validators.required],
        });

        if (this.job.id) {
            const datetime = new Date();
            this.fromDateTime = new Date(datetime.getFullYear(), datetime.getMonth(), datetime.getDate(), this.job.hour, this.job.min, 0, 0);
        }
        this.handleSave();
    }

    public checkJobDetail(): void {
        this.showWarning = false;
        if (!this.job.key) {
            this.showWarning = false;
            return;
        } else {
            this.jobApiService.retrieveJobDetail(this.job.key).subscribe((response) => {
                if (!response.success || !response.data) {
                    this.showWarning = true;
                }
            });
        }
    }

    public handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                map((job) => this.mapJobObject(job)),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([job, uiConfigurations]) => {
                    if (!job.jobDto.id) {
                        return this.jobApiService.create(job).pipe(
                            tap((resp) => {
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                }
                                this.uiStateService.toggleShowLoading(false);
                            }),
                            catchError((ex) => {
                                this.uiStateService.toggleShowLoading(false);
                                this.toastrService.error(getMessageEx(ex));
                                return of(null);
                            })
                        );
                    }
                    return this.jobApiService.update(job).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError(() => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(errorMessages.error_message);
                            return of(null);
                        })
                    );
                }),
                filter((resp) => !!resp),
                tap(() => this.submited.emit()),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private mapJobObject(job: Job): ICreateOrUpdateJobReq {
        return {
            jobDto: {
                id: job.id,
                name: this.editForm.controls.name.value,
                key: this.editForm.controls.key.value,
                type: Number(this.editForm.controls.typeJob.value),
                frequency: job.frequency,
                description: job.description,
                enabled: job.enabled,
                startDate: moment(this.editForm.controls.appliedDate.value).toDate(),
                hour: this.fromDateTime.getHours() ? this.fromDateTime.getHours() : 0,
                min: this.fromDateTime.getMinutes() ? this.fromDateTime.getMinutes() : 0,
            },
        } as ICreateOrUpdateJobReq;
    }
    private isValid(): boolean {
        Object.keys(this.editForm.controls).forEach((key) => {
            this.editForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editForm.valid;
    }
}
