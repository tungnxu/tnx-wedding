import { IMainFiltering } from './../../../shared/interfaces/main-filtering.interface';
import { ToastrService } from 'ngx-toastr';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { catchError, filter, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { Job } from '../job.model';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { JobEditComponent } from '../job-edit/job-edit.component';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { JobApiService } from '../../../shared/services/api-services/job-api.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { combineLatest, Observable, of } from 'rxjs';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { jobTypeEn } from '../../../shared/constants/job-type.constant';

@Component({
    templateUrl: 'job-list.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class JobListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public selectedKeys: string[] = [];
    public gridData: IGridData<Job[]>;
    public jobType = jobTypeEn;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        public readonly userPermissionApiService: UserPermissionApiService,
        private readonly jobApiService: JobApiService,
        private readonly toastrService: ToastrService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.jobApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public showTimeFormat(hour: number, minute: number): string {
        const hourDisplay = hour < 10 ? `0${hour}` : hour;
        const minuteDisplay = minute < 10 ? `0${minute}` : minute;
        return `${hourDisplay}:${minuteDisplay}`;
    }

    public showTypeFormat(type: number): string {
        return this.jobType[type];
    }

    public edit(item: Job): void {
        this.modalService.openModal(
            {
                title: 'Chỉnh sửa',
                inputs: [{ key: 'job', value: item }],
                component: JobEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public add() {
        this.modalService.openModal(
            {
                title: 'Thêm mới',
                component: JobEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(item: Job): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: `Bạn có chắc chắn muốn xóa <b>${item.name}</b> không?`,
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() => this.jobApiService.delete([item.id])),
                tap((resp) => {
                    this.toastrService.success(resp.message);
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public execute(item: Job): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: `Bạn có chắc chắn muốn kích hoạt <b>${item.name}</b> không?`,
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() => this.jobApiService.execute(item.key)),
                tap((resp) => {
                    if (resp.success) {
                        this.toastrService.success(resp.message);
                    } else {
                        this.toastrService.error(getMessageResp(resp));
                    }
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public deleteMultiple() {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: `Bạn có chắc chắn muốn xóa <b>${this.selectedKeys.length}</b> bản ghi đã chọn không?`,
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() => this.jobApiService.delete(this.selectedKeys)),
                tap((resp) => {
                    if (resp.success) {
                        this.toastrService.success(resp.message);
                    } else {
                        this.toastrService.error(getMessageResp(resp));
                    }
                    this.search(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public onSelectedKeysChange(selectedKeys: string[]) {
        this.selectedKeys = selectedKeys;
        this.cdr.detectChanges();
    }
}
