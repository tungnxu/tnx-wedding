import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SharedModule } from '../../shared/shared.module';
import { QuillModule } from 'ngx-quill';
import { JobRoutingModule } from './job.routing';
import { JobListComponent } from './job-list/job-list.component';
import { JobEditComponent } from './job-edit/job-edit.component';

@NgModule({
    imports: [
        JobRoutingModule,
        CommonModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
        TabsModule.forRoot(),
        PaginationModule.forRoot(),
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        CollapseModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
    ],
    declarations: [JobListComponent, JobEditComponent],
    providers: [],
})
export class JobModule {}
