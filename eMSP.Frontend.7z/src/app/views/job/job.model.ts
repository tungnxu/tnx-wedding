export class Job {
    id?: string;
    name?: string;
    key?: string;
    type?: string;
    startDate?: Date;
    fromTime?: string;
    toTime?: string;
    description?: string;
    enabled?: boolean = true;
    selected?: boolean;
    frequency?: number;
    createdDate?: string;
    lastModifiedDate?: Date;
    hour?: number;
    min?: number;
}
