import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { JobListComponent } from './job-list/job-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: JobListComponent,
        data: {
            title: 'Tham số hệ thống',
            requiredPermission: appPermissions.AdminOnly,
        },
        children: [
            {
                path: 'jobs',
                component: JobListComponent,
                data: {
                    title: 'Cấu hình đặt lịch',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class JobRoutingModule {}
