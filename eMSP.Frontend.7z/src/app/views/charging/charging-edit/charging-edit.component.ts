import { UiConfigurationViewModel } from './../../../shared/view-models/ui-configuration.viewModel';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Subject, Observable, of } from 'rxjs';
import { filter, map, switchMap, takeUntil, debounceTime, tap, catchError, withLatestFrom } from 'rxjs/operators';
import { ChargingConfigurationType } from '../../../shared/enums/charging-configuration-type.enum';
import { ChargingConfiguration } from '../charging.model';
import { ChargingApiService } from '../../../shared/services/api-services/charging-api.service';
import { BaseComponent } from '../../../base.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import * as moment from 'moment';
import { CustomValidators } from 'ngx-custom-validators';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { ToastrService } from 'ngx-toastr';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { ChargingVehicleType } from '../../../shared/enums/charging.enum';
import { chargingVehicleTypeVi } from '../../../shared/constants/charging.constant';
import { ICreateChargingConfigurationReq } from '../../../shared/interfaces/charging-req.interface';
@Component({
    selector: 'emsp-charging-edit',
    templateUrl: 'charging-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingEditComponent extends BaseComponent implements OnInit {
    @Input() public chargingConfiguration: ChargingConfiguration = {};
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public editForm: FormGroup;
    public chargingConfigurationType = ChargingConfigurationType;
    public errorMessages = errorMessages;
    public validationHelper = ValidationHelper;
    public minDate: Date;
    public bsDatepickerConfig: Partial<BsDatepickerConfig>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public save$ = new Subject<ChargingConfiguration>();
    public chargingVehicleTypeVi = chargingVehicleTypeVi;
    public dropdownTypeSelected: ChargingVehicleType;

    constructor(
        private readonly chargingApiService: ChargingApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly formBuilder: FormBuilder,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly toastrService: ToastrService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        this.uiConfigurations$
            .pipe(
                tap((uiConfigurations) => {
                    this.bsDatepickerConfig = {
                        dateInputFormat: uiConfigurations.clientDateFormat.toUpperCase(),
                        adaptivePosition: true,
                    };
                })
            )
            .subscribe();

        const currentDate = new Date();
        if (!this.chargingConfiguration.id) {
            this.minDate = moment(new Date()).add(1, 'day').toDate();
        }
        this.editForm = this.formBuilder.group({
            appliedPrice: [
                {
                    value: this.chargingConfiguration.appliedPrice ?? '',
                    disabled: this.viewOnly,
                },
                [Validators.required],
            ],
            appliedDate: [
                {
                    value: this.chargingConfiguration.appliedDate ? moment(this.chargingConfiguration.appliedDate).toDate() : '',
                    disabled: this.viewOnly,
                },
                [Validators.required, Validators.maxLength(20), CustomValidators.date, CustomValidators.minDate(currentDate)],
            ],
        });
        this.handleSave();

        this.dropdownTypeSelected = ChargingVehicleType.Car;
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                map((chargingConfiguration) => this.mapChargingConfiguration(chargingConfiguration)),
                switchMap((chargingConfiguration) =>
                    this.chargingApiService.create(chargingConfiguration).pipe(
                        tap((resp) => {
                            if (resp?.success) {
                                this.toastrService.success(resp.message);
                                this.submited.emit();
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private mapChargingConfiguration(chargingConfiguration: ChargingConfiguration): ICreateChargingConfigurationReq {
        return {
            chargingConfigurationDto: {
                appliedPrice: parseFloat(this.editForm.controls.appliedPrice.value),
                description: chargingConfiguration.description,
                appliedDate: moment(this.editForm.controls.appliedDate.value).toDate(),
                enabled: chargingConfiguration.enabled,
                vehicleType: this.dropdownTypeSelected,
                sync: true,
                type: '',
            },
        } as ICreateChargingConfigurationReq;
    }
    private isValid(): boolean {
        Object.keys(this.editForm.controls).forEach((key) => {
            this.editForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editForm.valid;
    }

    public changeDropdownType(typeSelected: number): void {
        this.dropdownTypeSelected = typeSelected;
    }

    public getTextDropdownSelected(): string {
        return chargingVehicleTypeVi[this.dropdownTypeSelected];
    }
}
