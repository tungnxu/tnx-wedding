import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { SharedModule } from '../../shared/shared.module';
import { QuillModule } from 'ngx-quill';
import { ChargingRoutingModule } from './charging.routing';
import { ChargingListComponent } from './charging-list/charging-list.component';
import { ChargingEditComponent } from './charging-edit/charging-edit.component';
import { NgxMaskModule } from 'ngx-mask';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

@NgModule({
    imports: [
        ChargingRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        TabsModule.forRoot(),
        BsDatepickerModule.forRoot(),
        SharedModule,
        QuillModule.forRoot(),
        NgxMaskModule.forRoot(),
        BsDropdownModule.forRoot(),
    ],
    declarations: [ChargingListComponent, ChargingEditComponent],
})
export class ChargingModule {}
