import { ChargingItem } from '../../shared/shared.model';

export class TimeRef {
    from?: number;
    to?: number;
    constructor(init?: Partial<TimeRef>) {
        Object.assign(this, init);
    }
}

export class ChargingConfiguration {
    id?: string;
    appliedDate?: Date;
    type?: string;
    appliedPrice?: number;
    chargings?: ChargingItem[] = [];
    enabled?: boolean = true;
    description?: string;
    selected?: boolean;
    sync?: boolean;
    createdDate?: string;
    times?: TimeRef[] = [];
    capacity?: number;
    chargingId?: string;
    chargingName?: string;
    chargingAddress?: string;
    constructor(init?: Partial<ChargingConfiguration>) {
        Object.assign(this, init);
    }
}

export class ChargingValidationRequest {
    appliedDate?: Date;
    appliedPrice?: string;
    type?: string;
    capacity?: any;
    constructor(init?: Partial<ChargingValidationRequest>) {
        Object.assign(this, init);
    }
}
