import { IConfirmOptions } from './../../../shared/interfaces/confirm-options.interface';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { takeUntil, switchMap, filter, tap, catchError, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { ChargingConfigurationType } from '../../../shared/enums/charging-configuration-type.enum';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { ModalService } from '../../../shared/services/modal.service';
import { ChargingEditComponent } from '../charging-edit/charging-edit.component';
import { ChargingConfiguration } from '../charging.model';
import { ChargingApiService } from '../../../shared/services/api-services/charging-api.service';
import { combineLatest, Observable, of } from 'rxjs';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { appPermissions } from '../../../shared/constants/app-permissions.constant';
import { AuthStateService } from '../../../core/services/auth-state.service';
import { UiStateService } from '../../../core/services/ui-state.service';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { chargingVehicleTypeVi } from '../../../shared/constants/charging.constant';

@Component({
    selector: 'emsp-charging-list',
    templateUrl: 'charging-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public selectedKeys: string[] = [];
    public gridData: IGridData<ChargingConfiguration[]>;
    public chargingCofigurationTypes = ChargingConfigurationType;
    public createPermission$: Observable<boolean>;
    public updatePermission$: Observable<boolean>;
    public deletePermission$: Observable<boolean>;
    public chargingVehicleTypeVi = chargingVehicleTypeVi;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly authStateService: AuthStateService,
        private readonly chargingApiService: ChargingApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly toastrService: ToastrService,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.createPermission$ = this.authStateService.hasPermissions$(appPermissions.ChargingConfigurationCreate);
        this.updatePermission$ = this.authStateService.hasPermissions$(appPermissions.ChargingConfigurationUpdate);
        this.deletePermission$ = this.authStateService.hasPermissions$(appPermissions.ChargingConfigurationDelete);

        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };

                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        tap(() => this.uiStateService.toggleShowLoading(true)),
            this.chargingApiService
                .search(request)
                .pipe(
                    catchError((ex) => {
                        this.uiStateService.toggleShowLoading(false);
                        this.toastrService.error(getMessageEx(ex));
                        return of(null);
                    })
                )
                .subscribe((response) => {
                    if (response?.success) {
                        this.gridData = {
                            data: response.data.items,
                            total: response.data.total,
                        };
                        this.cdr.detectChanges();
                        this.uiStateService.toggleShowLoading(false);
                    } else {
                        this.uiStateService.toggleShowLoading(false);
                    }
                });
    }

    public edit(item: ChargingConfiguration): void {
        this.modalService.openModal(
            {
                title: 'Chỉnh sửa',
                inputs: [
                    { key: 'chargingConfiguration', value: item },
                    { key: 'viewOnly', value: true },
                ],
                component: ChargingEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(item: ChargingConfiguration): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: 'Bạn có chắc chắn muốn xóa không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([, uiConfigurations]) =>
                    this.chargingApiService.delete([item.id]).pipe(
                        tap((resp) => {
                            if (resp.success) {
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.search(this.requestFilter);
                            this.uiStateService.toggleShowLoading(false);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public viewDetail(item: ChargingConfiguration): void {
        this.modalService.openModal({
            title: 'Chi tiết',
            inputs: [
                { key: 'chargingConfiguration', value: item },
                { key: 'viewOnly', value: true },
            ],
            component: ChargingEditComponent,
        });
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Tạo mới giá mặc định',
                inputs: [{ key: 'viewOnly', value: false }],
                component: ChargingEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public deleteMultiple(): void {
        this.modalService
            .confirm({
                title: 'Thông báo',
                message: `Bạn có chắc chắn muốn xóa <b>${this.selectedKeys.length}</b> bản ghi đã chọn không?`,
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([, uiConfigurations]) =>
                    this.chargingApiService.delete(this.selectedKeys).pipe(
                        tap((resp) => {
                            this.uiStateService.toggleShowLoading(false);
                            if (resp.success) {
                                this.toastrService.success(resp.message);
                            } else {
                                this.toastrService.error(getMessageResp(resp));
                            }
                            this.search(this.requestFilter);
                        }),
                        catchError((ex) => {
                            this.uiStateService.toggleShowLoading(false);
                            this.toastrService.error(getMessageEx(ex));
                            return of(null);
                        })
                    )
                ),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public onSelectedKeysChange(selectedKeys: string[]): void {
        this.selectedKeys = selectedKeys;
        this.cdr.detectChanges();
    }

    public getTextDropdownSelected(type: number): string {
        return chargingVehicleTypeVi[type];
    }
}
