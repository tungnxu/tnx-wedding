import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { ChargingListComponent } from './charging-list/charging-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: ChargingListComponent,
        data: {
            title: 'Quản trị vận hành',
            requiredPermission: appPermissions.ChargingConfigurationRead,
        },
        children: [
            {
                path: 'charging/default',
                component: ChargingListComponent,
                data: {
                    title: 'Cấu hình giá mặc định',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ChargingRoutingModule {}
