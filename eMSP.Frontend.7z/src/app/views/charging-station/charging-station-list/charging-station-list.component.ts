import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, takeUntil, tap } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { ChargingStationApiService } from '../../../shared/services/api-services/charging-station-api.service';
import * as R from 'ramda';
import { IChargingStationSearchRequest } from '../../../shared/interfaces/charging-station-req.interface';
import { UiStateService } from '../../../core/services/ui-state.service';
import { ChargingStation } from '../../../shared/models/charging-station.model';
import { getMessageEx } from '../../../shared/helpers/object.helper';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'emsp-charging-station-list',
    templateUrl: './charging-station-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChargingStationListComponent extends BaseComponent implements OnInit {
    public requestFilter: IChargingStationSearchRequest;
    public gridData: IGridData<ChargingStation[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    constructor(
        private readonly cdr: ChangeDetectorRef,
        private readonly chargingStationApiService: ChargingStationApiService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        key: '',
                        city: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    private formatRqFilter(request: IChargingStationSearchRequest): IMainFiltering {
        const cloneRequestFilter = { ...request, itemId: request.key };
        delete cloneRequestFilter.key;
        return cloneRequestFilter;
    }

    public search(request: IChargingStationSearchRequest): void {
        this.uiStateService.toggleShowLoading(true);
        const rqFilter = this.formatRqFilter(request);
        // this.appConfigurationStateService.updatePageSizeGrid(rqFilter.pageSize);
        this.chargingStationApiService
            .search(rqFilter)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                } else {
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }
}
