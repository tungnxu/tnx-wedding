import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { ChargingStationListComponent } from './charging-station-list/charging-station-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: ChargingStationListComponent,
        data: {
            title: 'Cấu hình giá sạc pin',
            requiredPermission: appPermissions.AdminOnly,
        },
        children: [
            {
                path: 'list-charging-station',
                component: ChargingStationListComponent,
                data: {
                    title: 'Danh sách trạm sạc',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ChargingStationRoutingModule {}
