import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ChargingStationRoutingModule } from './charging-station.routing';
import { ChargingStationListComponent } from './charging-station-list/charging-station-list.component';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule } from '@angular/forms';

@NgModule({
    imports: [ChargingStationRoutingModule, CommonModule, FormsModule, HttpClientModule, SharedModule],
    declarations: [ChargingStationListComponent],
    providers: [],
})
export class ChargingStationModule {}
