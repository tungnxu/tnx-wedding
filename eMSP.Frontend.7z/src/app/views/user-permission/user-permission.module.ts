import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { SharedModule } from '../../shared/shared.module';
import { UserPermisisonRoutingModule } from './user-permission..routing';
import { CommonModule } from '@angular/common';
import { UserPermissionListComponent } from './user-permission-list/user-permission-list.component';
import { UserPermissionEditComponent } from './user-permission-edit/user-permission-edit.component';

@NgModule({
    imports: [
        UserPermisisonRoutingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        PaginationModule.forRoot(),
        SharedModule,
    ],
    declarations: [UserPermissionListComponent, UserPermissionEditComponent],
})
export class UserPermisisonModule {}
