import { UserPermissionEditComponent } from './../user-permission-edit/user-permission-edit.component';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { catchError, filter, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { UserPermission } from '../../../shared/models/user-permission.model';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { ModalService } from '../../../shared/services/modal.service';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { UiStateService } from '../../../core/services/ui-state.service';
import { IConfirmOptions } from '../../../shared/interfaces/confirm-options.interface';
import { ToastrService } from 'ngx-toastr';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { textMessages } from '../../../shared/constants/text-messages.constant';
import { getMessageEx } from '../../../shared/helpers/object.helper';

@Component({
    selector: 'emsp-user-permission-list',
    templateUrl: 'user-permission-list.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserPermissionListComponent extends BaseComponent implements OnInit {
    public requestFilter: IMainFiltering;
    public selectedKeys: string[] = [];
    public gridData: IGridData<UserPermission[]>;

    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;

    public viewDetail$ = new Subject<UserPermission>();
    public addDetail$ = new Subject<UserPermission>();
    public editDetail$ = new Subject<UserPermission>();
    public deleteDetail$ = new Subject<UserPermission>();

    constructor(
        private readonly userPermissionApiService: UserPermissionApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly modalService: ModalService,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly uiStateService: UiStateService,
        private readonly toastrService: ToastrService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
    }

    public search(request: IMainFiltering): void {
        this.uiStateService.toggleShowLoading(true);
        this.userPermissionApiService
            .search(request)
            .pipe(
                catchError((ex) => {
                    this.uiStateService.toggleShowLoading(false);
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                })
            )
            .subscribe((response) => {
                if (response?.success) {
                    this.gridData = {
                        data: response.data.items,
                        total: response.data.total,
                    };
                    this.cdr.detectChanges();
                    this.uiStateService.toggleShowLoading(false);
                }
            });
    }

    public add(): void {
        this.modalService.openModal(
            {
                title: 'Phân quyền',
                inputs: [],
                component: UserPermissionEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public view(item: UserPermission): void {
        this.modalService.openModal(
            {
                title: 'Phân quyền',
                inputs: [
                    { key: 'userPermission', value: item },
                    { key: 'viewOnly', value: true },
                ],
                component: UserPermissionEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public edit(item: UserPermission): void {
        this.modalService.openModal(
            {
                title: 'Phân quyền',
                inputs: [{ key: 'userPermission', value: item }],
                component: UserPermissionEditComponent,
                onSubmit: () => {
                    this.search(this.requestFilter);
                },
            },
            {
                ignoreBackdropClick: true,
            }
        );
    }

    public delete(item: UserPermission): void {
        this.modalService
            .confirm({
                title: 'Xóa phân quyền',
                message: 'Bạn có chắc chắn muốn xóa không?',
            } as IConfirmOptions)
            .pipe(
                filter((confirmed) => !!confirmed),
                switchMap(() => this.userPermissionApiService.delete(item.id)),
                withLatestFrom(this.uiConfigurations$),
                tap(([, uiConfigurations]) => {
                    this.toastrService.success(textMessages.success_message);
                    this.search(this.requestFilter);
                }),
                catchError((ex) => {
                    this.toastrService.error(getMessageEx(ex));
                    return of(null);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public onSelectedKeysChange(selectedKeys: string[]): void {
        this.selectedKeys = selectedKeys;
        this.cdr.detectChanges();
    }
}
