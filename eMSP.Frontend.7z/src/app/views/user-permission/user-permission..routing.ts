import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from '../../core/guards/auth.guard';
import { appPermissions } from '../../shared/constants/app-permissions.constant';
import { UserPermissionListComponent } from './user-permission-list/user-permission-list.component';

const routes: Routes = [
    {
        path: '',
        canActivate: [AuthenticationGuard],
        component: UserPermissionListComponent,
        data: {
            title: 'Hệ thống',
            requiredPermission: appPermissions.AdminOnly,
        },
        children: [
            {
                path: 'user-permissions',
                component: UserPermissionListComponent,
                data: {
                    title: 'Phân quyền',
                },
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class UserPermisisonRoutingModule {}
