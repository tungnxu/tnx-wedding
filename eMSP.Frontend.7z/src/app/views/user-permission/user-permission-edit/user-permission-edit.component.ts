import {
    AfterViewInit,
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    ElementRef,
    EventEmitter,
    Input,
    OnInit,
    Output,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import { combineLatest, Observable, of, Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { BaseComponent } from '../../../base.component';
import { IMainFiltering } from '../../../shared/interfaces/main-filtering.interface';
import { IGridData } from '../../../shared/interfaces/grid-data.interface';
import { UserPermission } from '../../../shared/models/user-permission.model';
import { UserPermissionApiService } from '../../../shared/services/api-services/user-permission-api.service';
import { catchError, debounceTime, filter, map, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { UiConfigurationViewModel } from '../../../shared/view-models/ui-configuration.viewModel';
import { RoleApiService } from '../../../shared/services/api-services/role-api.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UiStateService } from '../../../core/services/ui-state.service';
import { RoleViewModel } from '../../../shared/view-models/role.viewModel';
import { IAppPermissionsViewModel } from '../../../shared/view-models/app-permissions.viewModel';
import { getDetailRole } from '../../../shared/helpers/permission.helper';
import { ValidationHelper } from '../../../shared/helpers/validation.helper';
import { errorMessages } from '../../../shared/constants/error-messages.constant';
import { Role } from '../../../shared/models/role.model';
import { getMessageEx, getMessageResp } from '../../../shared/helpers/object.helper';
import { Response } from '../../../shared/models/response.model';

@Component({
    selector: 'emsp-user-permission-edit',
    templateUrl: 'user-permission-edit.component.html',
    styleUrls: [],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UserPermissionEditComponent extends BaseComponent implements OnInit {
    @Input() public userPermission: UserPermission;
    @Input() public viewOnly: boolean;

    @Output() closed: EventEmitter<void> = new EventEmitter<void>();
    @Output() submited: EventEmitter<void> = new EventEmitter<void>();

    public requestFilter: IMainFiltering;
    public gridData: IGridData<RoleViewModel[]>;
    public selectedRoles: string[] = [];
    public editForm: FormGroup;
    public validationHelper = ValidationHelper;
    public errorMessages = errorMessages;
    public getDetailRole = getDetailRole;

    public save$ = new Subject<UserPermission>();
    public uiConfigurations$: Observable<UiConfigurationViewModel>;
    public pageSizeGrid$: Observable<number>;
    public appPermissions$: Observable<IAppPermissionsViewModel[]>;

    constructor(
        private readonly userPermissionApiService: UserPermissionApiService,
        private readonly cdr: ChangeDetectorRef,
        private readonly appConfigurationStateService: AppConfigurationStateService,
        private readonly roleApiService: RoleApiService,
        private readonly formBuilder: FormBuilder,
        private readonly toastrService: ToastrService,
        private readonly uiStateService: UiStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.pageSizeGrid$ = this.appConfigurationStateService.pageSizeGrid$.pipe(takeUntil(this.destroyed$));
        this.appPermissions$ = this.userPermissionApiService.getAllPermissions();

        this.editForm = this.formBuilder.group({
            name: [
                {
                    value: this.userPermission?.userName ?? '',
                    disabled: this.viewOnly,
                },
                [Validators.required],
            ],
        });

        combineLatest([this.uiConfigurations$, this.pageSizeGrid$])
            .pipe(
                tap(([uiConfigurations, pageSize]) => {
                    this.requestFilter = {
                        fromDate: '',
                        pageIndex: uiConfigurations.pageIndex,
                        pageSize: pageSize ?? uiConfigurations.pageSizeGrid,
                    };
                    this.search(this.requestFilter);
                })
            )
            .subscribe();
        this.handleSave();
    }

    public search(request: IMainFiltering): void {
        this.roleApiService.search(request).subscribe((response) => {
            if (response.success) {
                this.gridData = {
                    data: this.mapPermissionSelected(response.data.items),
                    total: response.data.total,
                };
                this.cdr.detectChanges();
            }
        });
    }

    public mapPermissionSelected(roles: Role[]): RoleViewModel[] {
        if (!this.userPermission) {
            return roles;
        }

        const roleViewModelList = roles.map((role) => {
            return {
                id: role.id,
                name: role.name,
                permissions: role.permissions,
                selected: this.userPermission?.roleNames?.some((nameSelected) => role.name === nameSelected),
            } as RoleViewModel;
        });

        if (this.viewOnly) {
            return roleViewModelList.filter((item) => item.selected);
        }

        return roleViewModelList;
    }

    public onSelectedRolesChange(selectedRoles: string[]): void {
        this.selectedRoles = selectedRoles;
        this.cdr.detectChanges();
    }

    private handleSave(): void {
        this.save$
            .pipe(
                debounceTime(300),
                filter(() => this.isValid()),
                tap(() => this.uiStateService.toggleShowLoading(true)),
                withLatestFrom(this.uiConfigurations$),
                switchMap(([userPermission, uiConfigurations]) => {
                    if (!userPermission?.id) {
                        return this.userPermissionApiService
                            .create({
                                roleIds: this.selectedRoles,
                                userName: this.editForm.controls.name.value,
                            })
                            .pipe(
                                tap((resp) => {
                                    this.uiStateService.toggleShowLoading(false);
                                    if (resp?.success) {
                                        this.toastrService.success(resp.message);
                                        this.submited.emit();
                                    } else {
                                        this.toastrService.error(getMessageResp(resp));
                                    }
                                }),
                                catchError((ex) => {
                                    this.uiStateService.toggleShowLoading(false);
                                    this.toastrService.error(getMessageEx(ex));
                                    return of(null);
                                })
                            );
                    }
                    return this.userPermissionApiService
                        .update({
                            id: userPermission.id,
                            roleIds: this.selectedRoles,
                            userName: this.editForm.controls.name.value,
                        })
                        .pipe(
                            tap((resp) => {
                                this.uiStateService.toggleShowLoading(false);
                                if (resp?.success) {
                                    this.toastrService.success(resp.message);
                                    this.submited.emit();
                                } else {
                                    this.toastrService.error(getMessageResp(resp));
                                }
                            }),
                            catchError((ex) => {
                                this.toastrService.error(errorMessages.error_message);
                                this.uiStateService.toggleShowLoading(false);
                                return of(null);
                            })
                        );
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    private isValid(): boolean {
        Object.keys(this.editForm.controls).forEach((key) => {
            this.editForm.get(key).markAsDirty();
        });
        this.cdr.detectChanges();
        return this.editForm.valid;
    }
}
