import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { appPermissions } from './shared/constants/app-permissions.constant';
import { AuthenticationGuard } from './core/guards/auth.guard';
import { EmspLayoutComponent } from './core/layouts/emsp-layout/emsp-layout/emsp-layout.component';
import { P401Component } from './core/layouts/error/401.component';
import { P403Component } from './core/layouts/error/403.component';
import { P404Component } from './core/layouts/error/404.component';
import { P500Component } from './core/layouts/error/500.component';

export const routes: Routes = [
    {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
    },
    {
        path: '404',
        component: P404Component,
        data: {
            title: 'Page 404',
        },
    },
    {
        path: '500',
        component: P500Component,
        data: {
            title: 'Page 500',
        },
    },
    {
        path: '403',
        component: P403Component,
        data: {
            title: 'Page 500',
        },
    },
    {
        path: '401',
        component: P401Component,
        data: {
            title: 'Page 401',
        },
    },
    {
        path: '',
        component: EmspLayoutComponent,
        data: {
            title: 'Home',
        },
        children: [
            {
                path: 'dashboard',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/dashboard/dashboard.module').then((m) => m.DashboardModule),
            },
            {
                path: 'system',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/user-permission/user-permission.module').then((m) => m.UserPermisisonModule),
            },
            {
                path: 'system',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/role/role.module').then((m) => m.RoleModule),
            },
            {
                path: 'system',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/job/job.module').then((m) => m.JobModule),
            },
            {
                path: 'configuration',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/charging/charging.module').then((m) => m.ChargingModule),
            },
            {
                path: 'configuration',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/penalty/penalty.module').then((m) => m.PenaltyModule),
            },
            {
                path: 'configuration',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/charging-station/charging-station.module').then((m) => m.ChargingStationModule),
            },
            {
                path: 'configuration',
                canLoad: [AuthenticationGuard],
                loadChildren: () =>
                    import('./views/multidimensional-pricing-config/multidimensional-pricing-config.module').then(
                        (m) => m.MultidimensionalPricingConfigModule
                    ),
            },
            {
                path: 'configuration',
                canLoad: [AuthenticationGuard],
                loadChildren: () =>
                    import('./views/battery-subscription-package/battery-subscription-package.module').then(
                        (m) => m.BatterySubscriptionPackageModule
                    ),
            },
            {
                path: 'charging-booking',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/charging-booking/charging-booking.module').then((m) => m.ChargingBookingModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/bill/bill.module').then((m) => m.BillModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/invoice/invoice.module').then((m) => m.InvoiceModule),
            },
            {
                path: 'report',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/report/report.module').then((m) => m.ReportModule),
            },
            {
                path: 'escooter-report',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/escooter/escooter-report/escooter-report.module').then((m) => m.EscooterReportModule),
            },
            {
                path: 'partner',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/partner/partner.module').then((m) => m.PartnerModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/battery-subscription/battery-subscription.module').then((m) => m.BatterySubscriptionModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () =>
                    import('./views/escooter/battery-subscription/escooter-battery-subscription.module').then(
                        (m) => m.EscooterBatterySubscriptionModule
                    ),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/escooter/policy-package/policy-package.module').then((m) => m.PolicyPackageModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () =>
                    import('./views/escooter/subscription-package/escooter-subscription.module').then((m) => m.EscooterSubscriptionPackageModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/escooter/debt/escooter-debt.module').then((m) => m.EscooterDebtModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/escooter/invoice/escooter-invoice.module').then((m) => m.EscooterInvoiceModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () =>
                    import('./views/escooter/escooter-open-tartget-soc/escooter-open-target-soc.module').then((m) => m.EscooterOpenTargetSocModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () =>
                    import('./views/escooter/open-charge-manual/escooter-open-charge-manual.module').then((m) => m.EscooterOpenChargeManualModule),
            },
            {
                path: 'manage',
                canLoad: [AuthenticationGuard],
                loadChildren: () => import('./views/operation/operation.module').then((m) => m.OperationModule),
            },
            // {
            //     path: 'manage',
            //     canLoad: [AuthenticationGuard],
            //         import('./views/escooter/subscription-package/escooter-subscription.module').then((m) => m.EscooterSubscriptionPackageModule),
            // },
        ],
    },
    // {
    //     path: 'security/auth',
    //     component: LoginComponent,
    // },
    { path: '**', component: P404Component },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {}
