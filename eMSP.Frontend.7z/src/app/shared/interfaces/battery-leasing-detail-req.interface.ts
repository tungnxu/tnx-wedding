import { IMainFiltering } from './main-filtering.interface';

export interface IBatteryLeasingDetail extends IMainFiltering {
    paid?: boolean;
}
