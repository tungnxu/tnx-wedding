export interface IOrderBy {
    key: string;
    value: boolean;
}
