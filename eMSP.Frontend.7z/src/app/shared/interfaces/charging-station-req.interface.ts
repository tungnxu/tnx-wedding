import { IMainFiltering } from './main-filtering.interface';

export interface IChargingStationSearchRequest extends IMainFiltering {
    city: string;
}
