import { IMainFiltering } from './main-filtering.interface';

export class IFilterChangePackageManual extends IMainFiltering {}

export class IUpdatePackageTypeRQ {
    subscriptionId: string;
    ticketId: string;
}
