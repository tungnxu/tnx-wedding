export interface IModalConfiguration {
    title: string;

    width?: string | number;

    height?: string | number;

    template?: string;

    component?: any;

    inputs?: { key: string; value: any }[];

    outputs?: { key: string; value: any }[];

    onClose?: (data: any) => void;

    onSubmit?: (data: any) => void;

    onCustomAction?: () => void;

    onModalClose?: () => void;

    closeFuncName?: string;

    submitFuncName?: string;
}
