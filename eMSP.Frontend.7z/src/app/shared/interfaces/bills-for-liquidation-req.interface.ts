import { IMainFiltering } from './main-filtering.interface';
import { IOrderBy } from './order-by.interface';

export class IBillsForLiquidationReq extends IMainFiltering {
    batterySubscriptionId?: string;
    odoStatus?: number;
    endOdoDate?: string;
}
