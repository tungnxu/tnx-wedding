export interface ICreateRoleReq {
    name: string;
    permissions: string[];
}

export interface IUpdateRoleReq extends ICreateRoleReq {
    id: string;
}
