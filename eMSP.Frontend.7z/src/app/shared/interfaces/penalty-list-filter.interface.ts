import { IMainFiltering } from './main-filtering.interface';

export class IPenaltyListFiltering extends IMainFiltering {
    enabled: boolean;
}
