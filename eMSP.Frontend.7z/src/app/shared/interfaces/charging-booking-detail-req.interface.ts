import { IMainFiltering } from './main-filtering.interface';

export interface IChargingBookingDetailSearchReq extends IMainFiltering {
    chargingBookingCode?: string;
    serialPin?: string;
    vehicleModel?: string;
    fullName?: string;
    idNumber?: string;
}
