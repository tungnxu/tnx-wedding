import { ChargingItem } from '../shared.model';

export interface ICreatePenaltyConfigurationReq {
    penaltyConfigurationDto: IPenaltyConfigurationDto;
}

export interface IPenaltyConfigurationDto {
    id?: string;
    appliedDate?: Date;
    type: number;
    appliedPrice: number;
    chargingStations: IChargingStationInfor[];
    enabled: boolean;
}

export interface IChargingStationInfor {
    chargingStationId: string;
    chargingStationName: string;
    chargingStationAddress: string;
}
