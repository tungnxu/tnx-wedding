import { IMainFiltering } from './main-filtering.interface';

export interface IBillListSearchRequest extends IMainFiltering {
    billStatus?: string;
    types?: string;
    paid?: string;
}
