import { BillInvoiceRequestModel } from '../models/invoice-info.model';
import { Showroom } from '../models/showroom.model';
import { IMainFiltering } from './main-filtering.interface';
import { IOrderBy } from './order-by.interface';

export interface IChargingBookingTransactionReportReq extends IMainFiltering {
    chargingBookingCode: string;
    chargingStationCity: string;
    chargingStationState: string;
    serialPin: string;
    vehicleModel: string;
    fullName: string;
    idNumber: string;
}

export interface IOtherTransactionReportReq extends IMainFiltering {
    customerId: string;
    vehicleId: string;
}

export interface IPayBillReq {
    billIds: string[];
    store: Showroom;
    invoiceInfo?: BillInvoiceRequestModel;
}
