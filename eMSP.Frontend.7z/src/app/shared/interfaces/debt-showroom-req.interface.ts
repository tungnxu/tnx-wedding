import { IMainFiltering } from './main-filtering.interface';

export interface IReportDebtShowRoom extends IMainFiltering {}
