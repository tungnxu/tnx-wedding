import { IOrderBy } from './order-by.interface';
import { IMainFiltering } from './main-filtering.interface';

export class IRuleSearch extends IMainFiltering {
    module?: string;
}
