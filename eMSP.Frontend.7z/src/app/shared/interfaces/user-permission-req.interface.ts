export interface ICreateUserPermissionReq {
    userName: string;
    roleIds: string[];
}

export interface IUpdateUserPermissionReq extends ICreateUserPermissionReq {
    id: string;
}

export interface ISaveJwtToCookieReq {
    idToken: string;
    expiredDate: Date;
}
