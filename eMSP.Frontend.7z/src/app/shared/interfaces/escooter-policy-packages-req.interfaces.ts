export interface ICreateUpdateEScooterPolicyPackages {
    id: string;
    packageId: string;
    title: string;
    content: string;
    language: string;
    enable: boolean;
    vehicleType: number;
    descriptions: string[];
}
