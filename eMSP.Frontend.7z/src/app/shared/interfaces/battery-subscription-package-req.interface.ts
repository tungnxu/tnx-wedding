export interface IBatterySubscriptionPackageEditReq {
    subscriptionId: string;
    id: string;
    packageType: number;
    vehicleModel: string;
    price: number;
    limitKm: number;
}
export interface IBatterySubscriptionPackageGetReq {
    id: string;
}

export interface IBatterySubscriptionPackagePostReq {
    Id: string;
}
export interface IBatterySubscriptionPackageChangeReq {
    subsciptionId: string;
    packageId: string;
}
