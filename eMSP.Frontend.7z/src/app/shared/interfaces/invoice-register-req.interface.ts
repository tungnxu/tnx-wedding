export interface IInvoiceRegisterSearchRequest {
    customerId: string;
    isDefault: boolean;
}
