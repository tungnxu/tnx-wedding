import { IOrderBy } from './order-by.interface';

export class IMainFiltering {
    searchText?: string;
    pageIndex?: number;
    pageSize?: number;
    direction?: string;
    sortBy?: string;
    order?: IOrderBy[];
    token?: string;
    name?: string;
    key?: string;
    fromDate?: string;
    toDate?: string;

    type?: string | number;
    vehicleId?: string;
    customerId?: string;
    status?: string;
}
