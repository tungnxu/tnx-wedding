export interface ISlide<T> {
    data: T[];
}
