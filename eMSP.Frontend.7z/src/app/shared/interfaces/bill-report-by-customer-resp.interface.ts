export interface IBillReportByCustomerResponse {
    customerId: string;
    fullName: string;
    email: string;
    phoneNumber: string;
    idNumber: string;
    address: string;
    amount?: number;
    discount?: number;
    finalAmount?: number;
}
