export interface ITableConfiguration {
    pageIndex: number;
    pageSize: number;
}
