export interface ILabelConfiguration {
    successMessage: string;
    errorMessage: string;
}
