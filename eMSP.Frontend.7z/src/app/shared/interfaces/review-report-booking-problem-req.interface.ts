export interface ReviewReportBookingProblemReq {
    id: string;
    approve: boolean;
    comment: string;
}
