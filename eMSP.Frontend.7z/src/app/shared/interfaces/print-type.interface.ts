export interface IPrintBatterySubscription {
    customerAddress: string;
    customerFullName: string;
    vehicleModel: string;
    dateNow: string;
    idNumber: string;
    vehicleID: string;
    vehicleVin: string;
}
