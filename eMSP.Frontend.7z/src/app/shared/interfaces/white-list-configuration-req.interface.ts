export interface ICreateWhiteListRQ {
    vehicleId: string;
    contractNo: string;
    customerId: string;
    ticketId: string;
    type: number;
}

export interface IChangeWhiteListStatusRQ {
    id: string;
    isActive: boolean;
}
