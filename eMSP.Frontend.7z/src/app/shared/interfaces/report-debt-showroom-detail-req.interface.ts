import { IMainFiltering } from './main-filtering.interface';

export interface IReportDebtShowRoomDetailReq extends IMainFiltering {
    storeCode: string;
    batterySerial: string;
    customerName: string;
    idCustomer: string;
    typeDebt?: number;
    vehicleModel: string;
}
