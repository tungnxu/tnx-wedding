import { IMainFiltering } from './main-filtering.interface';

export interface IChargingBookingReq extends IMainFiltering {
    idNumber: string;
}
