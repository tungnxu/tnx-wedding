import { BatteryProblem } from './../models/battery-problem.model';
import { IMainFiltering } from './main-filtering.interface';
import { Battery } from '../models/battery.model';
import { Showroom } from '../models/showroom.model';
import { BillInvoiceRequestModel } from '../models/invoice-info.model';
import { Bill } from '../models/bill.model';

export interface ICreateBatterySubscriptionReq {
    fullName: string;
    email: string;
    phoneNumber: string;
    plateNumber: string;
    idNumber: string;
    idNumberIssuedDate: string;
    idNumberIssuedPlace: string;
    address: string;
    customerId: string;
    sapCustomerId: string;
    customerGroupId: string;
    customerGroupName: string;
    showroomId: string;
    showroomName: string;
    vehicleId: string;
    vehicleType: string;
    vehicleModel: string;
    batteries: Battery[];
    taxRegistrationNumber: string;
    // isPrepayment: boolean;
    // prepaymentMonth: number;
}
export interface ISwapOwnerBatterySubscriptionReq {
    batterySubscriptionId: string;
    isAcceptLiquidation: boolean;
    batterySubscription: ICreateBatterySubscriptionReq;
}
export interface IBatterySubscriptionPackageSearchReq extends IMainFiltering {
    vehicleModel: string;
    vehicleType?: string;
}

export interface IPayBatterySubscriptionReq {
    batterySubscriptionId: string;
    prepaymentMonth: number;
    store: Showroom;
    invoiceInfo?: BillInvoiceRequestModel;
}

export interface IFindCustomerReq {
    searchText: string;
    type: number;
}

export interface ISuspendBatterySubscriptionReq {
    batterySubscriptionId: string;
    fromDate: Date;
    toDate: Date;
}

export interface IRegisterToChangeBatterySubscriptionPackageReq {
    batterySubscriptionId: string;
}

export interface ISwapOwnerReq extends ICreateBatterySubscriptionReq {
    batterySubscriptionId: string;
}

export interface ILiquidateBatterySubscriptionReq {
    liquidateBatterySubscriptionDto: ILiquidateBatterySubscriptionDto;
}

export interface ILiquidateBatterySubscriptionDto {
    // id: string;
    batteryProblems: BatteryProblem[];
    // isAcceptLiquidation: boolean;
    contractNo: string;
    billPaidInformation: Showroom;
}

export interface IBatterySubscriptionSearchRequest extends IMainFiltering {
    // batterySubscriptionPackageId?: string;
    fullName?: string;
}

export interface ICalculateRenewReq {
    customerId: string;
    vehicleId: string;
    numMonth: number;
}
