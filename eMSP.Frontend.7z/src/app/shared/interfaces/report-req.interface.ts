import { IMainFiltering } from './main-filtering.interface';

export interface ISAPTransactionSearchRequest extends IMainFiltering {
    billId: string;
}

export interface IReportBookingFiltering extends IMainFiltering {
    // plateNumber: string;
    email: string;
    phoneNumber: string;
}

export interface IReportOdoFiltering extends IMainFiltering {
    contractNo?: string;
    month?: number;
    year?: number;
}
