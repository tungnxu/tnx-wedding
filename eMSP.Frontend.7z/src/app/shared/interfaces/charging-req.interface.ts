export interface ICreateChargingConfigurationReq {
    chargingConfigurationDto: IChargingConfigurationDto;
}

export interface IChargingConfigurationDto {
    appliedDate: Date;
    appliedPrice: number;
    description: string;
    vehicleType: number;
    enabled: boolean;
    id: string;
    sync: boolean;
    type: string;
}
