import { IMainFiltering } from './main-filtering.interface';

export interface IInvoiceSearchRequest extends IMainFiltering {
    transactionId?: string;
}
