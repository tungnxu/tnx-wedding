export interface IGridData<T> {
    total: number;
    data: T;
}
