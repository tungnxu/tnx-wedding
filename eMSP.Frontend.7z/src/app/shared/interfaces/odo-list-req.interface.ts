import { IMainFiltering } from './main-filtering.interface';

export interface IOdoListSearchRequest extends IMainFiltering {
    customerId?: string;
    contractNo?: string;
    vehicleId?: string;
    initialOdo?: string;
    endOdo?: string;
    currentKm?: string;
    lastUpdate?: string;
    month?: number;
    year?: number;
}
