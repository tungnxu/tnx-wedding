export interface IJobDto {
    id?: string;
    startDate: Date;
    enabled: boolean;
    key: string;
    name: string;
    fromTime: string;
    toTime: string;
    frequency?: number;
    type: number;
    description: string;
    min?: number;
    hour?: number;
}

export interface ICreateOrUpdateJobReq {
    jobDto: IJobDto;
}
