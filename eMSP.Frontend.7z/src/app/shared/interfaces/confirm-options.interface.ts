export interface IConfirmOptions {
    closeValue: any;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    noConfirm?: boolean;
    noCancel?: boolean;
    ignoreBackdropClick?: boolean;
}
