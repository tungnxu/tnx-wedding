export interface ICustomerBalanceReq {
    customerId: string;
    vehicleId: string;
}
