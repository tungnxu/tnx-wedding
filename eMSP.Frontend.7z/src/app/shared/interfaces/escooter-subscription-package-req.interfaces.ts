export interface ICretateUpdateEScooterSubscriptionPackage {
    id?: string;
    packageType?: number;
    vehicleModel?: string;
    price: number;
    minCost: number;
    limitKm: number;
}
