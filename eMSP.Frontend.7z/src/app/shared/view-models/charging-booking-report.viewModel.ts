export class ChargingBookingReportViewModel {
    index: number;
    cookingTime: string;
    code: string;
    chargingDepotId: string;
    chargingDepotAddress: string;
    //public string ChargingDepotState { get; set; }
    chargingDepotCity: string;
    partnerId: string;
    vehicleId: string;
    plateNumber: string;
    customerId: string;
    fullName: string;
    address: string;
    phoneNumber: string;
    email: string;
    startChargeTime: string;
    endChargeTime: string;
}
