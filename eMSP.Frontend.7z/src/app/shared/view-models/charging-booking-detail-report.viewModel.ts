import { Role } from '../models/role.model';

export class ChargingBookingDetailReportViewModel {
    index: number;
    billCreatedDate: number;
    chargingBookingCode: string;
    chargingStationId: string;
    chargingStationName: string;
    chargingPointId: string;
    chargingConnectorId: string;
    chargingStationCity: string;
    chargingStationState: string;
    customerId: string;
    vehicleId: string;
    serialPin: string;
    vehicleModel: string;
    fullName: string;
    idNumber: string;
    startChargeTime: Date;
    endChargeTime: Date;
    startIdleTime: Date;
    endIdleTime: Date;
    startSOC: string;
    endSOC: string;
    totalKwCharged: string;
    amount: string;
    discount: string;
    finalAmount: string;
    paymentStatus: string;
    paymentMethod: string;
}
