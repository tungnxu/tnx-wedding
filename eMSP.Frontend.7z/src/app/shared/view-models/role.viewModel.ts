import { Role } from '../models/role.model';

export class RoleViewModel extends Role {
    selected?: boolean;
}
