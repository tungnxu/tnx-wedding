export class DebtShowroomReportViewModel {
    paidDate: string;
    storeCode: string;
    storeName: string;
    totalAmount: number;
}
