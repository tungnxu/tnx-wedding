export class Promotions {
    name: string;
    description: string;
    discount: number;
}
