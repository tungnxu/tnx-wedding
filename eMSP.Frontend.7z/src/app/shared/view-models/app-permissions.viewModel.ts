export interface IAppPermissionsViewModel {
    groupName: string;
    permissions: IPermissionViewModel[];
    masterSelected?: boolean;
}

export interface IPermissionViewModel {
    key: string;
    alias: string;
    checked: boolean;
}
