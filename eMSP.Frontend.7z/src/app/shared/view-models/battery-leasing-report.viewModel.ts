export class BatteryLeasingReportViewModel {
    contractNo: string;
    vehicleId: string;
    vehicleModel: string;
    batterySerial: string;
    fullName: string;
    idNumber: string;
    activeDate?: string;
    terminatedDate?: string;
    totalDebt: number;
    blockSoc?: boolean;
    targetSoc?: number;
    packageType: number;
    status: number;
}
