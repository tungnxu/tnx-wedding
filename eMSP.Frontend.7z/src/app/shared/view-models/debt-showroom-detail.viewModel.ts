import { Showroom } from '../models/showroom.model';

export class DebtShowroomDetailReportViewModel {
    billCode: string;
    customerId: string;
    vehicleId: string;
    vehicleModel: string;
    type: number;
    paidDate: Date;
    amount: number;
    discount: number;
    finalAmount: number;
    fullName: string;
    idNumber: string;
    batterySerial: string;
    paidAt: Showroom;
}
