export class BatteryLeasingReportViewModel {
    batterySerial: string;
    contractNo: string;
    currentKm: string;
    customerId: string;
    endOdo: string;
    fullName: string;
    idNumber: string;
    initialOdo: string;
    lastUpdate: string;
    month: string;
    vehicleId: string;
    year: string;
}
