export class UiConfigurationViewModel {
    clientDateFormat: string;
    serverDateFormat: string;
    currencyFormat?: string;
    chargingUnitFormat?: string;
    pageSizeGrid?: number;
    pageIndex?: number;
}
