import { Promotions } from './promotions.viewModel';

export class CalculateRenewViewModel {
    originalAmount: number;
    numMonth: number;
    promotions: Promotions[];
    totalAmount: number;
    extendedPlan: EndDateCalculateRenewViewModel;
}
export class EndDateCalculateRenewViewModel {
    endDate: Date;
}
