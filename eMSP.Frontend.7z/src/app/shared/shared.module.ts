import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AlertModule } from 'ngx-bootstrap/alert';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { CurrencyPipe } from './pipes/currency.pipe';
import { MainHeaderComponent } from './components/main-header/main-header.component';
import { MainGridComponent } from './components/main-grid/main-grid.component';
import { MainGridColumnComponent } from './components/main-grid-column/main-grid-column.component';
import { MainGridCheckboxColumnComponent } from './components/main-grid-checkbox-column/main-grid-checkbox-column.component';
import { MainFilterItemTemplateComponent } from './components/main-filter-item-template/main-filter-item-template.component';
import { MainFilterComponent } from './components/main-filter/main-filter.component';
import { PopoverModule } from 'ngx-bootstrap/popover';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { ModalComponent } from './components/modal/modal.component';
import { ConfirmComponent } from './components/confirm/confirm.component';
import { TruncatePipe } from './pipes/truncate.pipe';
import { RuleRefPipe } from './pipes/rule-ref.pipe';
import { DecodePipe } from './pipes/decode.pipe';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ChargingUnitPipe } from './pipes/charging-unit.pipe';
import { ShowroomSearchComponent } from './components/showroom-search/showroom-search.component';
import { RequestInvoiceComponent } from './components/request-invoice/request-invoice/request-invoice.component';
import { InvoiceInfoComponent } from './components/invoice-info/invoice-info.component';
@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        TabsModule.forRoot(),
        PaginationModule.forRoot(),
        TimepickerModule.forRoot(),
        BsDatepickerModule.forRoot(),
        AlertModule.forRoot(),
        ModalModule.forRoot(),
        CollapseModule.forRoot(),
        PopoverModule.forRoot(),
        TypeaheadModule.forRoot(),
        BsDropdownModule.forRoot(),
        ReactiveFormsModule,
    ],
    declarations: [
        CurrencyPipe,
        TruncatePipe,
        MainHeaderComponent,
        MainGridComponent,
        MainGridColumnComponent,
        MainGridCheckboxColumnComponent,
        MainFilterComponent,
        MainFilterItemTemplateComponent,
        ModalComponent,
        ConfirmComponent,
        RuleRefPipe,
        DecodePipe,
        ChargingUnitPipe,
        ShowroomSearchComponent,
        RequestInvoiceComponent,
        InvoiceInfoComponent,
    ],
    exports: [
        CurrencyPipe,
        TruncatePipe,
        MainHeaderComponent,
        MainGridComponent,
        MainGridColumnComponent,
        MainGridCheckboxColumnComponent,
        MainFilterComponent,
        MainFilterItemTemplateComponent,
        ModalComponent,
        ConfirmComponent,
        RuleRefPipe,
        DecodePipe,
        ChargingUnitPipe,
        ShowroomSearchComponent,
        RequestInvoiceComponent,
        InvoiceInfoComponent,
    ],
    providers: [],
})
export class SharedModule {}
