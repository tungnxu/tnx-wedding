export const jobTypeEn = {
    0: 'DAILY',
    1: 'NO_REPEAT',
    2: 'INTERVAL',
};
