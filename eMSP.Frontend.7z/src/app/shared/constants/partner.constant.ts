export const partnerPaymentTypeVi = {
    1: 'Trả thẳng',
    2: 'Đặt cọc',
    3: 'Trả góp',
};
