export const serviceTypeNameVi = {
    1: 'Thuê pin',
    2: 'Sạc pin',
    3: 'Phí phạt sạc pin',
    4: 'Phí thuê pin khác',
};

export const transactionTypeNameVi = {
    1: 'F1 - Công nợ',
    2: 'F2 - Trả thẳng thanh toán',
    3: 'F3 - Công nợ trả trước(Gia hạn gói thuê pin)',
    5: 'F5 - Cập nhật Invoice',
    6: 'F6 - Phân bổ doanh thu',
};
