export const penaltyConfigurationTypeVi = {
    0: 'Phí vắng mặt',
    1: 'Phí đỗ lâu',
    2: 'Phí hủy booking',
};
