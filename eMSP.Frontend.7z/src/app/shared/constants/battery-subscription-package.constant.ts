export const batterySubscriptionPackageTypeVi = {
    0: 'Linh hoạt',
    1: 'Cố định',
};
