export const eScooterTypeDataEn = {
    0: 'Description',
    1: 'Content',
};
