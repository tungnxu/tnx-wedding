export const chargingBookingStatusVi = {
    0: 'Chưa sạc',
    1: 'Đang sạc',
    2: 'Hoàn thành sạc',
    3: 'Hoàn thành',
    4: 'Lỗi',
    5: 'Đã hủy',
    6: 'Tạm giữ',
    7: 'Khách không đến',
};

// TODO BE cần trả ra dữ liệu chuẩn hơn
export const chargingBookingPaymentStatusVi = {
    false: 'Chưa thanh toán',
    true: 'Đã thanh toán',
};

export const transactionPaymentType = {
    true: 'Đã đặt trước',
    false: 'Vãng lai',
};
