export const vehicleTypeVi = {
    1: 'Car',
    2: 'Scooter',
    3: 'Bus',
};
