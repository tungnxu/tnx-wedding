export const customerSearchTypeVi = {
    1: 'CMND',
    // 2: 'Hộ chiếu',
    // 3: 'Giấy phép lái xe',
    // 4: 'Mã số thuế',
    5: 'SAPID',
    6: 'OneID',
    // 7: 'Email',
    // 8: 'Phone',
    9: 'Vin Xe',
};

export const batterySubscriptionStatusVi = {
    0: 'Đã tạo',
    1: 'Kích hoạt',
    2: 'Dừng hợp đồng',
    3: 'Chấm dứt HĐ',
};

export const batterySubscriptionNewStatusVi = {
    0: 'Open',
    1: 'Active',
    2: 'Deactivate',
    3: 'Terminated',
};
