export const reportBookingProblemReviewStatusVi = {
    0: 'Chưa phê duyệt',
    1: 'Loại',
    2: 'Đã phê duyệt',
};

export const reportBookingProblemReasonTypeVi = {
    CHARGING_PROBLEM: 'Phiên sạc không bắt đầu',
    OCCUPIED: 'Ai đó đã đỗ xe tại vị trí tôi đã đặt lịch',
    OTHER: 'Khác',
};
