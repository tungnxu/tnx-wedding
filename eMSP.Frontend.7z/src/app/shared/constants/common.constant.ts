export const routers = {
    login: 'security/auth',
    unAuthorized: '403',
    unAuthenticated: '401',
    dashboard: 'dashboard',
};

export const dateTimeConfig = {
    startYear: 2022,
};
