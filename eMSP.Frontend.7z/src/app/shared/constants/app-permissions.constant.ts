export const appPermissions = {
    AdminOnly: 'AdminOnly',

    BatterySubscriptionRead: 'BatterySubscriptionRead',
    BatterySubscriptionUpdate: 'BatterySubscriptionUpdate',
    BatterySubscriptionCreate: 'BatterySubscriptionCreate',

    BillRead: 'BillRead',
    BillCreate: 'BillCreate',
    BillUpdate: 'BillUpdate',

    ChargingBookingRead: 'ChargingBookingRead',
    ChargingBookingCreate: 'ChargingBookingCreate',
    ChargingBookingUpdate: 'ChargingBookingUpdate',
    ChargingBookingDelete: 'ChargingBookingDelete',

    ChargingConfigurationRead: 'ChargingConfigurationRead',
    ChargingConfigurationCreate: 'ChargingConfigurationCreate',
    ChargingConfigurationUpdate: 'ChargingConfigurationUpdate',
    ChargingConfigurationDelete: 'ChargingConfigurationDelete',

    ChargingItemRead: 'ChargingItemRead',
    ChargingItemCreate: 'ChargingItemCreate',
    ChargingItemUpdate: 'ChargingItemUpdate',
    ChargingItemDelete: 'ChargingItemDelete',

    PenaltyConfigurationRead: 'PenaltyConfigurationRead',
    PenaltyConfigurationCreate: 'PenaltyConfigurationCreate',
    PenaltyConfigurationDelete: 'PenaltyConfigurationDelete',

    BatterySubscriptionPackageRead: 'BatterySubscriptionPackageRead',
    BatterySubscriptionPackageCreate: 'BatterySubscriptionPackageCreate',
    BatterySubscriptionPackageUpdate: 'BatterySubscriptionPackageUpdate',
    BatterySubscriptionPackageDelete: 'BatterySubscriptionPackageDelete',

    EscooterBatteryPackageRead: 'EscooterBatteryPackageRead',
    EscooterBatteryPackageCreate: 'EscooterBatteryPackageCreate',
    EscooterBatteryPackageUpdate: 'EscooterBatteryPackageUpdate',
    EscooterBatteryPackageDelete: 'EscooterBatteryPackageDelete',

    EscooterBatterySubscriptionRead: 'EscooterBatterySubscriptionRead',
    EscooterBatterySubscriptionCreate: 'EscooterBatterySubscriptionCreate',
    EscooterBatterySubscriptionUpdate: 'EscooterBatterySubscriptionUpdate',
    EscooterBatterySubscriptionDelete: 'EscooterBatterySubscriptionDelete',

    PackagePolicyRead: 'PackagePolicyRead',
    PackagePolicyCreate: 'PackagePolicyCreate',
    PackagePolicyUpdate: 'PackagePolicyUpdate',
    PackagePolicyDelete: 'PackagePolicyDelete',

    EscooterInvoiceRead: 'EscooterInvoiceRead',
    EscooterInvoiceDetail: 'EscooterInvoiceDetail',

    OperatorChangeBatterySubscriptionManualRead: 'OperatorChangeBatterySubscriptionManualRead',
    OperatorChangeBatterySubscriptionManualCreate: 'OperatorChangeBatterySubscriptionManualCreate',

    OpenTargetSOCManualRead: 'OpenTargetSOCManualRead',
    OpenTargetSOCManualCreate: 'OpenTargetSOCManualCreate',

    OpenChargeManualRead: 'OpenChargeManualRead',
    OpenChargeManualReadCreate: 'OpenChargeManualReadCreate',

    ReportRead: 'ReportRead',

    EscooterOpenTargetSOCManualRead: 'EscooterOpenTargetSOCManualRead',
    EscooterOpenTargetSOCManualCreate: 'EscooterOpenTargetSOCManualCreate',

    EscooterOpenChargeManualRead: 'EscooterOpenChargeManualRead',
    EscooterOpenChargeManualCreate: 'EscooterOpenChargeManualCreate',
};
