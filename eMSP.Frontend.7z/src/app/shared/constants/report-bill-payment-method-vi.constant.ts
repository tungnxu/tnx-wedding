export const billPaymentMethodVi = {
    1: 'Chuyển khoản',
    2: 'Tiền mặt',
};
