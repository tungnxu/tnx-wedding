export const textMessages = {
    success_message: 'Thao tác thành công.',
};
