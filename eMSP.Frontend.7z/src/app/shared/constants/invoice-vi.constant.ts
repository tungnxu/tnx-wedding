export const invoiceVi = {
    1: 'Phí thuê pin',
    2: 'Phí sạc pin',
};
