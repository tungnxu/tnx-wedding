export const chargingBookingFee = {
    ChargingFee: 'CHARGING FEE',
    ChargingFeeUnit: '/Kwh',
    NoShowFee: 'NOSHOWN FEE',
    NoShowFeeUnit: '/Mins',
    IdleFee: 'IDLE_FEE',
    CancelFee: 'CANCEL_FEE',
};
