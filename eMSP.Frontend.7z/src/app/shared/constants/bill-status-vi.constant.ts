export const billStatusVi = {
    0: 'Tạm giữ',
    1: 'Hủy',
    2: 'Hoạt động',
};

export const billPaymentStatusVi = {
    false: 'Chưa thanh toán',
    true: 'Đã thanh toán',
};
