import { appPermissions } from './app-permissions.constant';

export const sideBarNavData: any[] = [
    {
        icon: 'vf-icon icon-coin',
        name: 'Quản lý giao dịch',
        children: [
            {
                icon: 'vf-icon icon-calendar',
                name: 'Quản lý Charging Booking',
                url: '/charging-booking/bookings',
                requiredPermission: appPermissions.ChargingBookingRead,
            },
            {
                icon: 'vf-icon icon-flash',
                name: 'Quản lý giao dịch sạc',
                url: '/charging-booking/transactions',
                requiredPermission: appPermissions.ChargingBookingRead,
            },
            {
                icon: 'vf-icon icon-calendar-1 ',
                name: 'Quản lý công nợ K/H',
                url: '/manage/debts',
                requiredPermission: appPermissions.BillRead,
            },
            {
                icon: 'vf-icon icon-bill',
                name: 'Danh sách bill',
                url: '/manage/bills',
                requiredPermission: appPermissions.BillRead,
            },
            {
                icon: 'vf-icon icon-invoice',
                name: 'Danh sách invoice',
                url: '/manage/invoices',
                requiredPermission: appPermissions.ChargingBookingRead,
            },
            // {
            //     icon: 'vf-icon icon-invoice',
            //     name: 'Hủy giao dịch bằng tay',
            //     url: '/charging-booking/cancel-transaction',
            //     requiredPermission: appPermissions.ChargingBookingRead,
            // },
        ],
    },
    {
        icon: 'vf-icon icon-file-1',
        name: 'Quản lý HĐ thuê pin',
        children: [
            {
                icon: 'vf-icon icon-file-2',
                name: 'Quản lý HĐ thuê pin',
                url: '/manage/battery-subcriptions',
                requiredPermission: appPermissions.BatterySubscriptionRead,
            },
            // {
            //     icon: 'vf-icon icon-charg',
            //     name: 'Quản lý giới hạn sạc',
            //     url: '/configuration/battery-contract/#',
            //     requiredPermission: appPermissions.BatterySubscriptionRead,
            // },
        ],
    },
    // {
    //     icon: 'vf-icon icon-letters',
    //     name: 'Quản lý khiếu nại',
    //     children: [
    //         {
    //             icon: 'vf-icon icon-computer',
    //             name: 'Báo vi phạm vị trí sạc bị chiếm',
    //             url: '/complain/report-booking-problems',
    //             requiredPermission: appPermissions.ChargingBookingRead,
    //         },
    //         // {
    //         //     icon: 'vf-icon icon-letters-1',
    //         //     name: 'Khiếu nại giao dịch',
    //         //     url: '/complain/report-booking/#',
    //         //     requiredPermission: appPermissions.ChargingBookingRead,
    //         // },
    //     ],
    // },
    {
        icon: 'vf-icon icon-operation',
        name: 'Quản lý vận hành',
        children: [
            {
                icon: 'vf-icon icon-change-btr-packages',
                name: 'Đổi gói cước thuê pin trong kỳ cước hiện tại',
                url: '/manage/change-battery-subscription-manual',
                requiredPermission: appPermissions.OperatorChangeBatterySubscriptionManualRead,
            },
            {
                icon: 'vf-icon icon-open-charge',
                name: 'Mở chặn sạc',
                url: '/manage/open-charge-manual-list',
                requiredPermission: appPermissions.OpenChargeManualRead,
            },
            {
                icon: 'vf-icon icon-open-target-soc',
                name: 'Mở chặn SOC',
                url: '/manage/open-target-soc-list',
                requiredPermission: appPermissions.OpenTargetSOCManualRead,
            },
        ],
    },
    {
        icon: 'vf-icon icon-chart',
        name: 'Báo cáo vận hành',
        children: [
            // { icon: 'vf-icon icon-file-report', name: 'Thuê pin', url: '/report/batteries', requiredPermission: appPermissions.AdminOnly },
            // { icon: 'vf-icon icon-file-report', name: 'Chi tiết Booking', url: '/report/booking', requiredPermission: appPermissions.AdminOnly },
            // { icon: 'vf-icon icon-file-report', name: 'Tài khoản', url: '/report/user-account', requiredPermission: appPermissions.AdminOnly },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Chi tiết giao dịch SAP',
                url: '/report/sap-transaction',
                requiredPermission: appPermissions.ReportRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Báo cáo tổng hợp thuê pin',
                url: '/report/battery-leasing',
                requiredPermission: appPermissions.ReportRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Báo cáo chi tiết thuê pin',
                url: '/report/battery-leasing-detail',
                requiredPermission: appPermissions.ReportRead,
            },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Công nợ đối tác',
            //     url: '/report/investments',
            //     requiredPermission: appPermissions.ReportRead,
            // },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Báo cáo giao dịch charging booking',
            //     url: '/report/charging-booking-transaction',
            //     requiredPermission: appPermissions.ReportRead,
            // },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Báo cáo giao dịch khác',
            //     url: '/report/other-transaction',
            //     requiredPermission: appPermissions.ReportRead,
            // },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Báo cáo ODO',
                url: '/report/odo',
                requiredPermission: appPermissions.ReportRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Báo cáo chi tiết giao dịch sạc',
                url: '/report/charging-booking-transaction',
                requiredPermission: appPermissions.ReportRead,
            },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Báo cáo chi tiết ODO',
            //     url: '/report/odo-detail',
            //     requiredPermission: appPermissions.ReportRead,
            // },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Tổng hợp công nợ SR',
                url: '/report/debt-showroom',
                requiredPermission: appPermissions.ReportRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Chi tiết công nợ tại SR',
                url: '/report/sr-revenue-detail',
                requiredPermission: appPermissions.ReportRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Báo cáo chi tiết Booking',
                url: '/report/charging-booking-detail',
                requiredPermission: appPermissions.ReportRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Danh sách chặn sạc',
                url: '/report/charging-blocking',
                requiredPermission: appPermissions.ReportRead,
            },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Báo cáo doanh thu ổ sạc',
            //     url: '/report/charging-revenue',
            //     requiredPermission: appPermissions.ReportRead,
            // },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Báo cáo đi quá định mức',
            //     url: '/report/out-of-battery-subscription-limit',
            //     requiredPermission: appPermissions.ReportRead,
            // },
            // {
            //     icon: 'vf-icon icon-file-report',
            //     name: 'Báo cáo thanh toán online',
            //     url: '/report/payment-online',
            //     requiredPermission: appPermissions.ReportRead,
            // },
        ],
    },
    {
        icon: 'vf-icon icon-price',
        name: 'Cấu hình giá sạc pin',
        children: [
            {
                icon: 'vf-icon icon-price-1',
                name: 'Cấu hình giá mặc định',
                url: '/configuration/charging/default',
                requiredPermission: appPermissions.ChargingConfigurationRead,
            },
            {
                icon: 'vf-icon icon-battery',
                name: 'Quản lý gói cước thuê pin',
                url: '/configuration/battery-subcriptions-package',
                requiredPermission: appPermissions.BatterySubscriptionPackageRead,
            },
            {
                icon: 'vf-icon icon-percent',
                name: 'Quản lý chương trình khuyến mại',
                url: '/configuration/multidimensional-charging',
                requiredPermission: appPermissions.AdminOnly,
            },
            {
                icon: 'vf-icon icon-letters-2',
                name: 'Cấu hình phí phạt',
                url: '/configuration/penalties',
                requiredPermission: appPermissions.PenaltyConfigurationRead,
            },
            {
                icon: 'vf-icon icon-letters-2',
                name: 'Danh sách trạm sạc',
                url: '/configuration/list-charging-station',
                requiredPermission: appPermissions.AdminOnly,
            },
            // {
            //     icon: 'vf-icon icon-battery',
            //     name: 'Cấu hình giá đền bù pin hỏng',
            //     url: '/configuration/battery-penalties',
            //     requiredPermission: appPermissions.AdminOnly,
            // },
        ],
    },
    {
        icon: 'vf-icon icon-system',
        name: 'Tham số hệ thống',
        children: [
            { icon: 'vf-icon icon-key', name: 'Phân quyền', url: '/system/user-permissions', requiredPermission: appPermissions.AdminOnly },
            { icon: 'vf-icon icon-roles', name: 'Vai trò', url: '/system/roles', requiredPermission: appPermissions.AdminOnly },
            {
                icon: 'vf-icon icon-schedule-config',
                name: 'Cấu hình đặt lịch',
                url: '/system/jobs',
                requiredPermission: appPermissions.AdminOnly,
            },
        ],
    },
    {
        icon: 'vf-icon icon-system',
        name: 'Quản lý xe máy điện',
        children: [
            {
                icon: 'vf-icon icon-key',
                name: 'Policy Package',
                url: '/manage/policy-package',
                requiredPermission: appPermissions.PackagePolicyRead,
            },
            {
                icon: 'vf-icon icon-file-2',
                name: 'Quản lý hợp đồng thuê pin',
                url: '/manage/escooter-battery-subscription',
                requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
            },
            {
                icon: 'vf-icon icon-file-2',
                name: 'Đăng ký gói cước',
                url: '/manage/emsp-escooter-subscription-package',
                requiredPermission: appPermissions.BatterySubscriptionPackageRead,
            },
            {
                icon: 'vf-icon icon-calendar-1',
                name: 'Quản lý công nợ K/H',
                url: '/manage/escooter-debt',
                requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
            },
            {
                icon: 'vf-icon icon-bill',
                name: 'Danh sách bill',
                url: '/escooter-report/bills',
                requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
            },
            {
                icon: 'vf-icon icon-file-report',
                name: 'Chi tiết giao dịch SAP',
                url: '/escooter-report/sap-transaction',
                requiredPermission: appPermissions.EscooterBatterySubscriptionRead,
            },
            {
                icon: 'vf-icon icon-invoice',
                name: 'Quản lý hóa đơn',
                url: '/manage/escooter-invoices',
                requiredPermission: appPermissions.EscooterInvoiceRead,
            },
            {
                icon: 'vf-icon icon-invoice',
                name: 'Mở khóa xe',
                url: '/manage/escooter-open-target-soc',
                requiredPermission: appPermissions.EscooterOpenTargetSOCManualRead,
            },
            {
                icon: 'vf-icon icon-invoice',
                name: 'Mở chặn sạc',
                url: '/manage/escooter-open-charging',
                requiredPermission: appPermissions.EscooterOpenChargeManualRead,
            },
            // {
            //     icon: 'vf-icon icon-file-2',
            //     name: 'Đăng ký gói cước',
            //     url: '/manage/emsp-escooter-subscription-package',
            //     requiredPermission: appPermissions.BatterySubscriptionPackageRead,
            // },
        ],
    },
];
