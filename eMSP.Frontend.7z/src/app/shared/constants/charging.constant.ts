export const chargingVehicleTypeVi = {
    0: 'Car',
    1: 'Scooter',
    2: 'Bus',
};
