import { Pipe, PipeTransform } from '@angular/core';
import { Rule } from '../../views/multidimensional-pricing-config/multidimensional-pricing-config.model';

@Pipe({
    name: 'rule',
})
export class RuleRefPipe implements PipeTransform {
    constructor() {}

    transform(source: Rule[]): string {
        let response = '';
        if (source != null || source.length > 0) {
            source.forEach((element, index) => {
                if (index === source.length - 1) {
                    response += element.code;
                } else {
                    response += element.code + ', ';
                }
            });
        }
        return response;
    }
}
