import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'chargingUnit',
})
export class ChargingUnitPipe implements PipeTransform {
    constructor() {}

    transform(source: number, chargingUnit: string): string {
        if (!source && source !== 0) {
            return '';
        }
        return source.toLocaleString('en-US') + (chargingUnit ? ' ' + chargingUnit : '');
    }
}
