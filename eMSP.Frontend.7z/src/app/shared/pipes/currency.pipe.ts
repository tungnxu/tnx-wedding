import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'currency',
})
export class CurrencyPipe implements PipeTransform {
    constructor() {}

    transform(source: number, currency: string): string {
        if (!source && source !== 0) {
            return '';
        }
        return source.toLocaleString('en-US') + (currency ? ' ' + currency : '');
    }
}
