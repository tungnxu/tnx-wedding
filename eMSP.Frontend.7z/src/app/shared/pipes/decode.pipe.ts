import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'decode',
})
export class DecodePipe implements PipeTransform {
    constructor() {}
    transform(source: string): string {
        if (!source) {
            return '';
        }
        const encodedString = source
            .replace('<p>', '')
            .replace('</p>', '')
            .replace('</pre>', '')
            .replace('<pre class="ql-syntax" spellcheck="false">', '');
        const textArea = document.createElement('textarea');
        textArea.innerHTML = encodedString;
        return textArea.value;
    }
}
