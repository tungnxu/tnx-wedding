import { ElementRef } from '@angular/core';

export class LookupItem {
    key?: string;
    value?: any;
    customClass?: string;
    icon?: string;
    count?: number;
    constructor(init?: Partial<LookupItem>) {
        Object.assign(this, init);
    }
}

export class LookupRequest<T> {
    title?: string;
    icon?: string;
    item?: MasterField;
    items?: MasterField[] = [];
    fields?: MasterField[] = [];
    current?: MasterField;
    closeCallback?: () => any;
    acceptCallback?: (item: MasterField) => any;
    constructor(init?: Partial<LookupRequest<T>>) {
        Object.assign(this, init);
    }
}

export class ActionRef {
    display?: string;
    value?: string;
    constructor(init?: Partial<ActionRef>) {
        Object.assign(this, init);
    }
}

export class MasterField {
    type?: string;
    name?: string;
    required?: boolean;
    constructor(init?: Partial<MasterField>) {
        Object.assign(this, init);
    }
}

export class ExtraButton {
    color?: string;
    icon?: string;
    text?: string;
    requiredData?: boolean;
    enabled?: boolean;
    callback?: (data?: any, loader?: any) => any;
    constructor(init?: Partial<ExtraButton>) {
        Object.assign(this, init);
    }
}

export class SummaryError {
    element: ElementRef;
    messages: string[];
    constructor(init?: Partial<SummaryError>) {
        Object.assign(this, init);
    }
}

export class ColumnRef {
    key?: string;
    value?: string;
    type?: string;
    icon?: string;
    constructor(init?: Partial<ColumnRef>) {
        Object.assign(this, init);
    }
}

export class MasterTab {
    name?: string;
    icon?: string;
    type?: string;
    url?: string;
    constructor(init?: Partial<MasterTab>) {
        Object.assign(this, init);
    }
}

export class ChargingEvsConnector {
    id?: string;
    standard?: string;
    format?: string;
    evseId?: string;
    powerType?: string;
    maxVoltage?: number;
    maxAmperage?: number;
    maxElectricPower?: number;
    termsAndConditions?: string;
    constructor(init?: Partial<ChargingEvsConnector>) {
        Object.assign(this, init);
    }
}

export class ChargingEvs {
    uid?: string;
    evseId?: string;
    floorLevel?: number;
    connectors?: ChargingEvsConnector[] = [];
    physicalReference?: string;
    createdTimestamp?: Date;
    lastUpdatedTimestamp?: Date;
    maxElectricPower?: number;
    termsAndConditions?: string;
    constructor(init?: Partial<ChargingEvs>) {
        Object.assign(this, init);
    }
}

export class ChargingItem {
    id?: string;
    itemId?: string;
    locationId?: string;
    name?: string;
    address?: string;
    evses?: ChargingEvs[] = [];
    city?: string;
    postalCode?: string;
    countryCode?: string;
    lastUpdated?: Date;
    constructor(init?: Partial<ChargingItem>) {
        Object.assign(this, init);
    }
}
