import { AbstractControl, FormGroup, ValidationErrors } from '@angular/forms';
import * as moment from 'moment';

export class ValidationHelper {
    public static hasError(formGroup: FormGroup, formControlName: string, error: string): boolean {
        return (
            (formGroup.controls[formControlName].dirty || formGroup.controls[formControlName].touched) && formGroup.hasError(error, formControlName)
        );
    }

    public static checkValidDate(input: Date): boolean {
        if (input && moment(input).isValid()) {
            return true;
        } else {
            return false;
        }
    }
}
