import { AbstractControl, FormGroup, ValidationErrors } from '@angular/forms';
import * as moment from 'moment';
import { IAppPermissionsViewModel } from '../view-models/app-permissions.viewModel';

export const getDetailRole = (permissions: string[], listPermission: IAppPermissionsViewModel[]) => {
    if (!permissions || permissions.length === 0 || !listPermission || listPermission.length === 0) {
        return '';
    }
    return listPermission
        .map((group) => {
            return { ...group, permissions: group.permissions.filter((per) => permissions.some((p) => per.key === p)) };
        })
        .filter((group) => group.permissions.length > 0)
        .map((group) => '- ' + group.groupName + ' [' + group.permissions.map((item) => item.alias).join(', ') + ']')
        .join('\n');
};
