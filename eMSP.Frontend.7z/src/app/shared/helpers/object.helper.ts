import { errorMessages } from '../constants/error-messages.constant';
import { Response } from '../models/response.model';

export const getPropertyValue = (obj: any, keys: string) => {
    try {
        return keys.split('.').reduce((cur, key) => {
            return cur[key];
        }, obj);
    } catch (e) {
        return null;
    }
};

export const isPrimitiveObject = (obj: any) => {
    return obj !== Object(obj);
};

export const getMessageEx = (obj: any): string => {
    if (obj?.error) {
        if (obj?.error.message) {
            return obj?.error.message;
        }
        return obj.error.errors.map((item) => item.errorMessage ?? item.message).join(', ');
    }
    return errorMessages.error_message;
};

export const getMessageResp = (obj: Response<any>): string => {
    if (obj?.errors) {
        return obj.errors.map((item) => item.errorMessage).join(', ');
    } else if (obj.message) {
        return obj.message;
    }

    return errorMessages.error_message;
};
