import { BatterySubscriptionStatus } from '../enums/battery-subscription-status.enum';

export class BatterySubscriptionHistory {
    id: string;
    appliedDate: Date;
    expiredDate: Date;
    batterySubscriptionId: string;
    status: BatterySubscriptionStatus;
}
