export class BillInvoiceRequestModel {
    public fullName: string;
    public email: string;
    public phoneNumber: string;
    public address: string;
    public taxCode: string;
}
