export class PricingModelTemplate {
    key?: string;
    value?: string;
    alias?: string;
}
