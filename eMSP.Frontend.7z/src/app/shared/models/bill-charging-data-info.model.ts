import { ChargingBookingStatus } from '../enums/charging-booking-status.enum';
import { ChargingBookingItem } from './charing-booking-item.model';

export class BillChargingDataInfo {
    bookingId: string;
    locationId: string;
    locationName: string;
    locationAddress: string;
    bookingTimeFrom?: Date;
    bookingTimeTo?: Date;
    pluggedTime?: Date;
    unPluggedTime?: Date;
    totalKWCharged?: number;
    items: ChargingBookingItem[];

    // chargingBookingId: string;
    // chargingStationId: string;
    // chargingStationName: string;
    // chargingStationAddress: string;
    // bookingTimeFrom?: Date;
    // bookingTimeTo?: Date;
    // pluggedTime?: Date;
    // unPluggedTime?: Date;
    // startChargeTime?: Date;
    // endChargeTime?: Date;
    totalKwCharged?: number;
    chargingBookingItems?: ChargingBookingItem[];
    // selfBooking: boolean;
    // status: ChargingBookingStatus;
}
