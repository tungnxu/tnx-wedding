import { BatterySubscriptionStatus } from './../enums/battery-subscription-status.enum';
import { BatterySubscriptionPackage } from './battery-subscription-package.model';
import { Battery } from './battery.model';
import { BillInvoiceRequestModel } from './invoice-info.model';
import { SocTarget } from './soc.model';

export class BatterySubscription {
    id: string;
    fullName: string;
    email: string;
    phoneNumber: string;
    contractNo?: string;
    activeDate?: Date;
    contractType?: number;
    plateNumber: string;
    idNumber: string;
    address: string;
    customerId: string;
    sapCustomerId: string;
    showroomId: string;
    showroomName: string;
    vehicleId: string;
    vehicleType: string;
    vehicleModel: string;
    batteries: Battery[];
    status: BatterySubscriptionStatus;
    expiredDate: Date;
    nextPaymentDate: Date;
    createdDate: Date;
    batteryDeposit: number;
    liquidationDate?: Date;
    invoiceInfo?: BillInvoiceRequestModel;
    packageType?: number;

    constructor(
        fullName: string,
        email: string,
        phoneNumber: string,
        idNumber: string,
        address: string,
        customerId: string,
        sapCustomerId: string,
        showroomId: string,
        showroomName: string,
        vehicleId: string = null
    ) {
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.idNumber = idNumber;
        this.address = address;
        this.customerId = customerId;
        this.sapCustomerId = sapCustomerId;
        this.showroomId = showroomId;
        this.showroomName = showroomName;
        this.vehicleId = vehicleId;
    }
}
export class BatterySubscriptionDetail {
    contractNo: string;
    vehicleId: string;
    customerId: string;
    actualKm: number;
    overKm: number;
    cost: number;
    currentDate: string;
    lastUpdate: string;
    package: BatterySubscriptionPackage;
    targetSoc: BatterySubscriptionTargetSoc;
    debt: BatterySubscriptionDebt;
    endOdo?: number;
}
export class BatterySubscriptionDebt {
    totalAmount: number;
    bills: BatterySubscriptionBills[];
}
export class BatterySubscriptionBills {
    id: string;
    amount: number;
    issuedDate: string;
}
export class BatterySubscriptionTargetSoc {
    block: boolean;
    target: number;
}

export class WhiteListBatterySubscription {
    subscriptionInfo: BatterySubscription;
    debtCharging: number;
    targetSoc: SocTarget;
}
