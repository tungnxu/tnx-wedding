export class EScooterPolicyPackage {
    id: string;
    packageId: string;
    language: string;
    title: string;
    packageName: string;
    type: number;
    content: string;
    descriptions?: string[];
    vehicleType: number;
}

export class PolicyPackage {
    id: string;
    packageName: string;
}
export class PolicyPackageDescription {
    index: number;
    description: string;
}
