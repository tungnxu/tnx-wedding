import { VehiclePurchaseContract } from './vehicle-purchase-contract.model';

export class Customer {
    fullName: string;
    email: string;
    phoneNumber: string;
    idNumber: string;
    address: string;
    customerId: string;
    sapCustomerId: string;
    showroomId: string;
    showroomName: string;
    customerGroupId: string;
    customerGroupName: string;
    vehiclePurchaseContracts: VehiclePurchaseContract[];
}
