import { BatterySubscriptionStatus } from '../enums/battery-subscription-status.enum';
import { Battery } from './battery.model';

export class Showroom {
    // storeAddress: string;
    storeCode: string;
    // storeDescription: string;
    storeName: string;
    storeType: string;
    // city: string;
    // district: string;
    // hotline: string;
    // openTime: string;
    // closeTime: string;

    constructor(
        // storeAddress: string,
        storeCode: string,
        // storeDescription: string,
        storeName: string,
        storeType: string
        // city: string,
        // district: string,
        // hotline: string,
        // openTime: string,
        // closeTime: string
    ) {
        // this.storeAddress = storeAddress;
        this.storeCode = storeCode;
        // this.storeDescription = storeDescription;
        this.storeName = storeName;
        this.storeType = storeType;
        // this.city = city;
        // this.district = district;
        // this.hotline = hotline;
        // this.openTime = openTime;
        // this.closeTime = closeTime;
    }
}
