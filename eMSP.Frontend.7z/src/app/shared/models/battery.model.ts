import { BatteryProblem } from './battery-problem.model';

export class Battery {
    id: string;
    serial: string;
    stock: string;
    capacity: string;
    type: string;
    status: string;
    enabled?: boolean;
    // Chưa chốt thông tin lỗi nên để tạm
    batteryProblems: BatteryProblem[];
}
