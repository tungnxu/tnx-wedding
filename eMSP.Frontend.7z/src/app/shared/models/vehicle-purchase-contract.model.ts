export class VehiclePurchaseContract {
    plateNumber: string;
    batteryIds: string[];
    batterySubscriptionId: string;
    imageUrl: string;
    vehicleId: string;
    vehicleType: string;
    vehicleModel: string;
}
