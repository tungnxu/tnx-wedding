import { BillSubType } from '../enums/bill-sub-type.enum';
import { BillType } from '../enums/bill-type.enum';
import { BillBatteryLeasingDataInfo } from './bill-battery-leasing-data-info.model';
import { BillChargingDataInfo } from './bill-charging-data-info.model';
import { Bill } from './bill.model';
import { PagingResponse } from './response.model';

export class BillsForLiquidationDto {
    existingBills?: PagingResponse<Bill>;
    totalAmount?: number;
}

// export class BillList {
//     id?: string;
//     billCode?: string;
//     vehicleId: string;
//     vehicleModel?: string;
//     serviceType?: string;
//     type?: number;
//     subType?: number;
//     issuedDate?: Date;
//     customerId: string;
//     createdDate?: Date;
//     lastModifiedDate?: Date;
//     issuedMonth?: number;
//     issuedYear?: number;
//     amount: number;
//     paid?: boolean;
//     finalAmount?: number;
//     billStatus?: string;
//     discount?: number;
//     lockTime?: Date;
//     lockBySource?: string;
//     binCode?: string;
//     cardNumber?: string;
// }
