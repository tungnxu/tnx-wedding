export class ChargingStation {
    id: string;
    name: string;
    itemId: string;
    address: string;
    createdDate: Date;
    extraData: ExtraData;
}

class ExtraData {
    profitCenter: string;
    businessPlace: string;
    vendorCode: string;
}
