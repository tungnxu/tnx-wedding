import { ChargingItem } from '../shared.model';

export class PartnerConfigurationSearchRequest {
    name?: string;
    key?: string;
    createdDate?: string;
    fromDate?: string;
    toDate?: string;
    fromTime?: string;
    toTime?: string;
    type?: string;
    enabled?: boolean;
    status?: boolean;
    pageIndex?: number;
    direction?: string;
    pageSize?: number;
    constructor(init?: Partial<PartnerConfigurationSearchRequest>) {
        Object.assign(this, init);
    }
}

export class TimeRef {
    from?: number;
    to?: number;
    constructor(init?: Partial<TimeRef>) {
        Object.assign(this, init);
    }
}

export class PartnerConfiguration {
    id?: string;
    partnerId?: string;
    partnerName?: string;
    type?: string;
    percentage?: number;
    charger?: Charger[] = [];
    edit?: boolean = false;
    constructor(init?: Partial<PartnerConfiguration>) {
        Object.assign(this, init);
    }
}

export class Charger {
    chargingId?: string;
    chargingName?: string;
    percentage?: number;
    constructor(init?: Partial<Charger>) {
        Object.assign(this, init);
    }
}
export class Partner {
    partnerCode: string;
    partnerName: string;
    headContact: string;
    email: string;
    phoneNumber: string;
    chargingItem: ChargingItem;
    paymentStartDate: string;
    contractEndDate: string;
    fixPricePaymentCycle: number;
    fixPricePaymentType: number;
    priceRentalCar: number;
    priceRentalMoto: number;
    sharingPaymentCycle: number;
    sharingPaymentType: number;
    electricityPaymentCycle: number;
    electricityPaymentType: number;
    sharingRatio: number;
    electricityPrice: number;
    isLocked: number;
    lockedDate: string;
}

// export class ChargingStation {
//     stationCode: string;
//     stationName: string;
//     portNumber: number;
//     chargingPostType: string;
// }

export class BillingCycleType {
    billingCycleKey: number;
    billingCycleValue: string;
}
