export class WhiteList {
    id: string;
    vehicleId: string;
    contractNo: string;
    customerId: string;
    fullName: string;
    createdDate: string;
    createdBy: string;
    ticketId: string;
    type: number;
    isActive: boolean;
}
