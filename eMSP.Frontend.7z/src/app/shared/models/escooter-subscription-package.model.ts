export class EScooterSubscriptionPackage {
    id: string;
    packageName: string;
    packageType: number;
    vehicleModel: string;
    price: number;
    limitKm: number;
    minCost: number;
}
