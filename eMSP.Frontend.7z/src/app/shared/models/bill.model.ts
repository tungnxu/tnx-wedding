import { BillSubType } from '../enums/bill-sub-type.enum';
import { BillType } from '../enums/bill-type.enum';
import { BillBatteryLeasingDataInfo } from './bill-battery-leasing-data-info.model';
import { BillChargingDataInfo } from './bill-charging-data-info.model';

export class Bill {
    id: string;
    fullName: string;
    phoneNumber: string;
    plateNumber: string;
    address: string;
    customerId: string;
    vehicleId: string;
    email: string;
    type: BillType;
    subType: BillSubType;
    amount: number;
    issuedDate?: Date;
    data: BillChargingDataInfo | BillBatteryLeasingDataInfo;
    leasingData?: BillBatteryLeasingDataInfo;
    discount?: number;
    finalAmount?: number;
    idNumber: string;
    invoiceNumber: string;
    debtBills?: BillList[];
    totalBillAmount?: number;
    sapDocument?: string;
}

export class BillList {
    id?: string;
    billCode?: string;
    vehicleId: string;
    vehicleModel?: string;
    serviceType?: string;
    type?: number;
    subType?: number;
    issuedDate?: Date;
    customerId: string;
    createdDate?: Date;
    lastModifiedDate?: Date;
    issuedMonth?: number;
    issuedYear?: number;
    amount: number;
    paid?: boolean;
    finalAmount?: number;
    billStatus?: string;
    discount?: number;
    lockTime?: Date;
    lockBySource?: string;
    binCode?: string;
    cardNumber?: string;
    data?: BillChargingDataInfo | BillBatteryLeasingDataInfo;
}

export class EscooterBill {
    customerId: string;
    totalDebtAmount: number;
}
