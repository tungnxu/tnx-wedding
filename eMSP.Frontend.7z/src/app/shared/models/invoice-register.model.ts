export class InvoiceRegister {
    customerId: string;
    customerName: string;
    address: string;
    phoneNumber: string;
    taxCode: string;
    email: string;
    isDefault: boolean;
    isEnterprise: boolean;
}
