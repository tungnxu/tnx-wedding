export class Response<T> {
    public success: boolean;
    public data: T;
    public message: any;
    public errors: ErrorValidate[];
}

export class PagingResponse<T> {
    public items: T[];
    public total: number;
}

export class ErrorValidate {
    public errorMessage: string;
}
