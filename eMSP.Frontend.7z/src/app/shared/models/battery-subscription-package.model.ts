export class BatterySubscriptionPackage {
    public id: string;
    public packageName: string;
    public currentPackage: boolean;
    public packageType: number;
    public vehicleModel: string;
    public price: number;
    public limitKm: number;
    public minCost: number;
    public applyDate: Date;
}
