import { BatterySubscriptionStatus } from '../enums/battery-subscription-status.enum';
import { BatterySubscriptionPackage } from './battery-subscription-package.model';

export class BatterySubscriptionDms {
    id: string;
    fullName: string;
    email: string;
    phoneNumber: string;
    plateNumber: string;
    idNumber: string;
    idNumberIssuedDate: string;
    idNumberIssuedPlace: string;
    address: string;
    customerId: string;
    sapCustomerId: string;
    showroomId: string;
    showroomName: string;
    vehicleId: string;
    vehicleType: string;
    vehicleModel: string;
    batterySubscriptionPackage: BatterySubscriptionPackage;
    status: BatterySubscriptionStatus;
    expiredDate: Date;
    nextPaymentDate: Date;
    createdDate: Date;
    batteries: string[];
    sustomerGroupId: string;
    sustomerGroupName: string;
}
