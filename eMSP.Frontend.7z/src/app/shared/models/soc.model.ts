export class SocTarget {
    block: boolean;
    target: number;
}
