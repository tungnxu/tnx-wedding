export class Odo {
    customerId?: string;
    contractNo?: string;
    vehicleId?: string;
    initialOdo?: number;
    endOdo?: number;
    currentKm?: number;
    lastUpdate?: string;
    month?: number;
    year?: number;
    histories?: number[][];
}
