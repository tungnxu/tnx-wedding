import { InvoiceType } from '../enums/invoice.enum';

export class Invoice {
    transactionId: string;
    invoiceIssuedDate: Date;
    invoiceNumber?: string;
    customerName?: string;
    amount?: number;
    serviceType?: InvoiceType;
    link?: string;
}
