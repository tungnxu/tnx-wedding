import { Rule, LookupItem } from '../../views/multidimensional-pricing-config/multidimensional-pricing-config.model';

export class DynamicRuleSetRequest {
    rules?: Rule[] = [];
    script?: string;
    variables?: LookupItem[] = [];
}
