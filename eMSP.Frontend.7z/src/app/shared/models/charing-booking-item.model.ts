export class ChargingBookingItem {
    id: string;
    bookingId: string;
    energy?: number;
    name: string;
    cost?: number;
    unit: string;
    price?: number;
    from?: Date;
    to?: Date;
}
