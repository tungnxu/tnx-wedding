export class OperatorBatteryPackage {
    id: string;
    createdDate: string;
    contractNo: string;
    vehicleId: string;
    customerId: string;
    fromType: number;
    toType: number;
    appliedDate: string;
    status: number;
    ticketId: string;
}
