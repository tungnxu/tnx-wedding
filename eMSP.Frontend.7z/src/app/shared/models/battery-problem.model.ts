export class BatteryProblem {
    id: string;
    code: string;
    name: string;
    problemFee: number;
    selected: boolean;
    serialNumber?: string;
}
