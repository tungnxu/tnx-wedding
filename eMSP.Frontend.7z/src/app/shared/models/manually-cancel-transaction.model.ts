export class ManuallyCancelTransaction {
    vehicleId: string;
    chargingBookingId?: string;
    ticketId?: string;
    createdDate?: Date;
    canceledDate?: Date;
    canceledBy?: string;
    amount?: number;
}

export class ChargingBookingDetail extends ManuallyCancelTransaction {
    fullName: string;
}

export class CancelBooking extends ManuallyCancelTransaction {
    bookingId: string;
}
