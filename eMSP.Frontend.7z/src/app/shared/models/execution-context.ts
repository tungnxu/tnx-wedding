export class ExecutionContext {
    userName: string;
    avatarUrl: string;
    accountIdentifier: string;
    name: string;
    idToken: string;
    roleNames: string[];
    permissions: string[];
    isAdmin: boolean;
    expiredDate: Date;

    constructor(
        userName: string,
        accountIdentifier: string,
        name: string,
        idToken: string,
        expiredDate: Date
        // roleNames: string[],
        // permissions: string[]
    ) {
        this.userName = userName;
        // this.avatarUrl = avatarUrl;
        this.accountIdentifier = accountIdentifier;
        this.name = name;
        this.idToken = idToken;
        this.expiredDate = expiredDate;
        // this.roleNames = roleNames;
        // this.permissions = permissions;
    }
}
