export class Vehicle {
    vehicleModelId: string;
    vehicleModel: string;
    vehicleType: number;
}
