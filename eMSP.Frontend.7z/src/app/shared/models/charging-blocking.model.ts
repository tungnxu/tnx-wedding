export class ChargingBlocking {
    id: string;
    customerId: string;
    contractNo: string;
    vehicleId: string;
    customerName: string;
    blockingStatus: string;
    limitSoc: string;
}
