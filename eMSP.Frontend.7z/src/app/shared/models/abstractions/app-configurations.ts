import { ExecutionContext } from '../execution-context';
import { UiConfigurationViewModel } from './../../view-models/ui-configuration.viewModel';

export abstract class AppConfigurations {
    abstract uiConfigurations: UiConfigurationViewModel;
    abstract emspContext: ExecutionContext;
}
