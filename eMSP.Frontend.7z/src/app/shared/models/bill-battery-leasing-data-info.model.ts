import { BatterySubscriptionPackageType } from '../enums/battery-subscriptions-package.enum';

export class BillBatteryLeasingDataInfo {
    batterySubscriptionId: string;
    // public BatteryPackageInfo PackageInfo
    initialOdo?: number;
    endOdo?: number;
    currentKm?: number;
    cycleCharge?: number;
    excessKm?: number;
    excessKmCharge?: number;
    extendNumMonth?: number;
    extendStartDate?: Date;
    extendEndDate?: Date;

    actualKm?: number;
    // contractNo: string;
    // cost: number;
    // endOdo: number;
    // fromDate: Date;
    // initialOdo: number;
    // lastUpdate: Date;
    // limitKm: number;
    // overKm: number;
    // packageType: BatterySubscriptionPackageType;
    // price: number;
    // toDate: Date;
}
