export class UserPermission {
    public id: string;
    public userName: string;
    public roleNames: string[];
}
