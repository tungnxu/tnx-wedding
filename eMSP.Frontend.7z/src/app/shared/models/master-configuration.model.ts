export class UIConfiguration {
    clientConfiguration?: ClientConfiguration;
    serverConfiguration?: ServerConfiguration;
    pricingModelConfiguration?: PricingModelConfiguration;
    pageIndex?: number;
    pageSizeGrid?: number;
}

export class ClientConfiguration {
    currencyFormat?: string;
    dateFormat?: string;
    chargingUnitFormat?: string;
}
export class ServerConfiguration {
    dateFormat: string;
}
export class PricingModelConfiguration {
    common: string;
    promotion: string;
    pricing: string;
}
