export class SAPTransaction {
    billId: string;
    customerId: string;
    vehicleId: string;
    serviceType: string;
    totalAmount?: number;
    transactionType: string;
    paymentType: string;
    paymentMethod: string;
    paymentTranId: string;
    paidDate?: Date;
    invoiceNumber: string;
    issuedInvoiceDate?: Date;
    uploadedSAPDate?: Date;
    sapBusinessPlace: string;
    sapSegment: string;
    sapDoc: string;
    sapMessage: string;
    sapProfitCenter: string;
    status: string;
    invoiceIssuedDate?: Date;
    sapCustomerId: string;
}
