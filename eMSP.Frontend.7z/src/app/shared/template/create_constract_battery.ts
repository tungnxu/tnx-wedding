export const createBatteryContract = `
<style>
    .page-title {
        text-align: center;
        font-size: 21.3px;
        margin: 0 0 10px;
    }

    h2,
    h3,
    p,
    div {
        margin: 0;
        padding: 0;
        font-size: 14.6px;
        line-height: 1.4;
    }

    p {
        padding-bottom: 10px;
    }

    .page-header .desc {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .page-header .desc p:first-child {
        margin-right: 15px;
    }

    .page-header {
        margin-bottom: 35px;
    }

    .block-content {
        margin-bottom: 30px;
    }

    h2.block-title {
        margin-bottom: 15px;
    }

    .field_item {
        display: flex;
        margin-bottom: 7.5px;
    }

    .field_bold {
        font-weight: 600;
    }

    .field_item {
        display: flex;
    }

    .field_item .label {
        width: 115px;
    }

    .field_item .value {
        position: relative;
        padding-left: 10px;
        width: calc(100% - 115px);
    }

    .field_item .value::before {
        content: ':';
        position: absolute;
        left: 0;
    }

    .field_group {
        display: flex;
    }

    .field_group .field_item {
        width: 50%;
    }

    .field_group .field_item span {
        margin-left: 10px;
    }

    .field_group .field_item:first-child .value {
        width: 90px;
    }

    ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    ul>li {
        position: relative;
        padding-left: 15px;
        margin-bottom: 10px;
    }

    ul>li::before {
        content: '-';
        position: absolute;
        left: 0;
    }

    ul>ul{
        padding-left: 15px;
        list-style: disc;
        margin-left: 15px;
    }

    ul>ul>li {
        padding: 0;
    }

    ul>ul>li::before {
        display: none;
    }

    .col-group {
        display: flex;
    }

    .col-50 {
        width: 50%;
    }

    #footer {
        padding-bottom: 100px;
    }

    #footer h3 {
        text-align: center;
    }
    * {

    font-family: TimesNewRoman, "Times New Roman", Times, Baskerville, Georgia, serif;
   }
</style>
<div class="page-header">
    <h1 class="page-title">HỢP ĐỒNG CHO THUÊ PIN</h1>
    <div class="desc">
        <p>Số: 123/2021/HĐDVP</p>
        <p>Ngày: dateNow</p>
    </div>
</div>
<div class="page-content">
    <div class="block-content">
        <h2 class="block-title">BÊN CHO THUÊ: CÔNG TY TNHH KINH DOANH THƯƠNG MẠI
            VÀ DỊCH VỤ VINFAST </br>(“VinFast Trading”)</h2>
        <div class="field_item">
            <div class="label">Mã số DN</div>
            <div class="value">0108926276</div>
        </div>
        <div class="field_item">
            <div class="label">Địa chỉ</div>
            <div class="value">Số 7 đường Bằng Lăng 1, Khu đô thị Sinh thái
                Vinhomes Riverside, phường Việt Hưng, quận Long Biên, Hà Nội
            </div>
        </div>
        <div class="field_item">
            <div class="label">Đại diện bởi</div>
            <div class="value">Nguyễn Thị A</div>
        </div>
        <div class="field_item">
            <div class="label">Chức vụ</div>
            <div class="value">CEO</div>
        </div>
    </div>
    <div class="block-content">
        <div class="field_item">
            <div class="label field_bold">BÊN THUÊ (“Khách Hàng”)</div>
            <div class="value field_bold">customerFullName</div>
        </div>
        <div class="field_item">
            <div class="label">Địa chỉ</div>
            <div class="value">customerAddress
            </div>
        </div>
        <div class="field_item">
            <div class="label">Ngày sinh</div>
            <div class="value">11/11/2011</div>
        </div>
        <div class="field_group">
            <div class="field_item">
                <div class="label">Số CMND/CCCD</div>
                <div class="value">idNumber</div>
                <span>do CA Hà Nội</span>
            </div>
            <div class="field_item">
                <div class="label">cấp ngày</div>
                <div class="value">24/11/2011</div>
            </div>
        </div>
    </div>

    <div class="block-content">
        <h2 class="block-title">ĐIỀU 1: THUÊ PIN VÀ BẢO QUẢN PIN</h2>
        <p>VinFast Trading (“VFT”) cung cấp cho Khách Hàng - đồng thời là chủ sở hữu
            Xe Máy Điện (“XMĐ”) dịch vụ cho thuê, đổi pin cho XMĐ: </p>
        <div class="col-group">
            <div class="col-50">
                <div class="field_item">
                    <div class="label field_bold">Loại xe</div>
                    <div class="value field_bold">vehicleModel</div>
                </div>

            </div>
            <div class="col-50">
                <div class="field_item">
                    <div class="label field_bold">Số khung</div>
                    <div class="value field_bold">vehicleID</div>
                </div>
                <div class="field_item">
                    <div class="label field_bold">Số máy</div>
                    <div class="value field_bold">vehicleVin</div>
                </div>
            </div>
        </div>
        <ul>
            <li>Khách Hàng đồng ý thuê một số lượng pin loại B (số lượng pin thuê cụ
                thể có thể thay đổi theo từng thời điểm và được hệ thống của VFT
                quản lý) và đặt cọc cho VFT số tiền 1.200.000 VNĐ/01 pin. Tiền đặt
                cọc không được tính lãi và được VFT hoàn trả khi kết thúc hợp đồng
                này.</li>
            <li>Khách Hàng có trách nhiệm sử dụng và bảo quản pin theo quy định của
                VFT. Nếu để xảy ra các lỗi sau, Khách Hàng sẽ phải bồi thường theo
                quy định của VFT :</li>
            <ul>
                <li>Mất pin, hoặc vỏ pin bị biến dạng, nứt, vỡ hoặc pin bị mất
                    Zplug: khách hàng phải đền bù nguyên giá là 8.600.000 VNĐ/1 pin
                    (đã bao gồm VAT);</li>
                <li>Trường hợp vỏ pin biến dạng ở nắp, thân hoặc đế nhưng pin vẫn
                    hoạt động tốt, khách hàng phải bồi thường 770.000 VNĐ/phần vỏ bị
                    biến dạng (đã bao gồm VAT).</li>
            </ul>
            <li>Các quy định về sử dụng và bảo quản pin và các quy định khác được
                qui định đẩy đủ cụ thể trong Chính sách Dịch vụ Pin và Các Điều kiện
                chung về dịch vụ pin được VFT công bố trên website và các điểm giao
                dịch cho thuê pin (đại lý ủy quyền, showroom).</li>
        </ul>
    </div>

    <div class="block-content">
        <h2 class="block-title">ĐIỀU 2: PHÍ THUÊ BAO PIN</h2>
        <ul>
            <li>Khách Hàng đồng ý thanh toán phí thuê bao pin hàng tháng với chính
                sách giá theo từng thời điểm khác nhau do VFT quy định.</li>
            <li>Phí thuê bao pin theo tháng được thu trước ngày 01 của tháng; Khách
                Hàng có thể đóng 1 tháng hoặc nhiều tháng một lúc.</li>
            <li>Khách Hàng hiểu và đồng ý rằng, trong trường hợp Khách Hàng trả phí
                thuê bao chậm quá 06 ngày tính từ ngày đến hạn, VFT có quyền khóa
                kết nối của XMĐ (xe không khởi động được) qua hệ thống tự động. Việc
                khóa kết nối sẽ chấm dứt ngay sau khi Khách Hàng hoàn thành các
                nghĩa vụ thanh toán.</li>
        </ul>
    </div>

    <div class="block-content">
        <h2 class="block-title">ĐIỀU 3: CAM KẾT KHÁC</h2>
        <ul>
            <li>Khách Hàng cam kết không được chuyển quyền sử dụng, cho mượn, cho
                thuê, cầm cố và đảm bảo cho việc thực hiện nghĩa vụ dân sự khác đối
                với PIN của VFT.</li>
            <li>Khi Khách Hàng chuyển nhượng XMĐ, Khách Hàng sẽ trả lại pin cho VFT
                và thanh lý Hợp Đồng hoặc một phần Hợp Đồng để VFT ký hợp đồng cho
                thuê pin với chủ mới của xe.</li>
            <li>VFT có quyền chuyển giao các quyền/nghĩa vụ theo hợp đồng này cho
                công ty con, công ty liên kết, hoặc trong trường hợp tổ chức lại
                doanh nghiệp, bao gồm sáp nhập vào một công ty khác hoặc được chia,
                hoặc tách hoặc được chuyển đổi hoặc bên thứ ba sau khi gửi cho Khách
                Hàng thông báo bằng văn bản ít nhất 05 ngày trước ngày chuyển giao.
            </li>
            <li>Các quyền và nghĩa vụ khác của Khách Hàng và VFT được quy định trong
                Chính sách Dịch vụ Pin và Các Điều kiện chung về dịch vụ pin được
                VFT công bố trên website và các điểm giao dịch cho thuê pin.</li>
            <li>Hợp Đồng tự động thanh lý khi Khách Hàng đã trả lại hết pin thuê cho
                VFT và hoàn thành đầy đủ các nghĩa vụ pháp lý theo Hợp Đồng.</li>
        </ul>
    </div>

</div>
<div id="footer">
    <div class="col-group">
        <div class="col-50">
            <h3>KHÁCH HÀNG</h3>
        </div>
        <div class="col-50">
            <h3>ĐẠI DIỆN VINFAST TRADING</h3>
        </div>
    </div>
</div> `;
