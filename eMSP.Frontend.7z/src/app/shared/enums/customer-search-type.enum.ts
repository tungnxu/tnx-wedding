export enum CustomerSearchType {
    IdNumber = 1,
    TaxRegistrationNumber = 2,
    Email = 3,
    PhoneNumber = 4,
}
