export enum BillPaymentMethod {
    ONEPAY = 1,
    CASH = 2,
}
