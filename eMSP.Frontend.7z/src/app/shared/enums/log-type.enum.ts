export enum LogType {
    Fatal = 'FATAL',
    Block = 'BLOCK',
    Critical = 'CRITICAL',
    High = 'HIGH',
    Normal = 'NORMAL',
    Low = 'LOW',
}
