export enum ReportBookingProblemStatus {
    OPEN = 0,
    CLOSE = 1,
}
