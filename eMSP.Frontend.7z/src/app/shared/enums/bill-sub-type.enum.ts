export enum BillSubType {
    RENEW = 1,
    MONTHLY = 2,
}
