export enum LiquiDateState {
    CHECK_DEBTS = 1,
    PAYMENT = 2,
}
