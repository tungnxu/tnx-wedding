export enum InvoiceType {
    'Phí thuê pin' = 1,
    'Phí sạc pin' = 2,
    'Phí thuê pin XMĐ' = 5,
    'Phí sạc pin XMĐ' = 6,
}
