export enum BatterySubscriptionPackageType {
    FLEXIBLE = 0,
    FIXED = 1,
}
