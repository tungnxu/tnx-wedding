export enum ChargingVehicleType {
    Car = 0,
    Scooter = 1,
    Bus = 2,
}
