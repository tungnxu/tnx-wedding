export enum BillStatus {
    ONHOLD = 0,
    INACTIVE = 1,
    ACTIVE = 2,
}
