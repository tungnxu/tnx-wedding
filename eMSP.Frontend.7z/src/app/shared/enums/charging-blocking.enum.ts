export enum ChargingBlockStatus {
    New = 0,
    Failure = 1,
    Locked = 2,
    UnLocked = 3,
}
