export enum EWhiteListType {
    SOC = 1,
    CHARGING = 2,
    ESCOOTER_SOC = 3,
    ESCOOTER_CHARGING = 4,
}
