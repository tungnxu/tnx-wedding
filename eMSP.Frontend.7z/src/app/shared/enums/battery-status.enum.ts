export enum BatteryStatus {
    Good = 1,
    Bad = 2,
}
