export enum JobType {
    DAILY = 0,
    NO_REPEAT = 1,
    INTERVAL = 2,
}
