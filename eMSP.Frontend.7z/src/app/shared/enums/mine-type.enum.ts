export enum MIMEType {
    Excel = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
}
