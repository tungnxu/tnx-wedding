export enum AppConfigurationKey {
    DATE = 'DATE',
    CLIENT = 'CLIENT',
    SERVER = 'SERVER',
    TABLE = 'TABLE',
    PAGE_SIZE = 'PAGE_SIZE',
    PAGE_INDEX = 'PAGE_INDEX',
    LABEL = 'LABEL',
    ERROR_MESSAGE = 'ERROR_MESSAGE',
    SUCCESS_MESSAGE = 'SUCCESS_MESSAGE',
    CURRENCY = 'CURRENCY',
    JOB_TYPE = 'JOB_TYPE',
    PRICING_MODEL = 'PRICING_MODEL',
    CHARGING_UNIT = 'CHARGING_UNIT',

    uiConfigurationKey = 'emsp_uiConfiguraion',
    pageSizeKey = 'emsp_pageSize',
    contextKey = 'emsp_context',
}
