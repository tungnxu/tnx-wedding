export enum ChargingConfigurationType {
    Default = 'DEFAULT',
}
