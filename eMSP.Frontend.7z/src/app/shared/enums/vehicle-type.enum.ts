export enum VehicleType {
    Car = 2,
    EScooter = 1,
}
