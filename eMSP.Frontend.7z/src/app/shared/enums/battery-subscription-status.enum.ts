export enum BatterySubscriptionStatus {
    Open = 0,
    Active = 1,
    Deactivate = 2,
    Terminated = 3,
}
