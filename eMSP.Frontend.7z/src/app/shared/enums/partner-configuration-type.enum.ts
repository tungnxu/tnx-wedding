export enum PartnerConfigurationType {
    Income = 'INCOME',
    Charger = 'CHARGER',
}

export enum PartnerPaymentType {
    FullPayment = 1,
    Deposit = 2,
    InstallmentPayment = 3,
}
