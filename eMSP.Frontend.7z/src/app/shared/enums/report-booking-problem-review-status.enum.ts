export enum ReportBookingProblemReviewStatus {
    DEFAULT = 0,
    REJECTED = 1,
    APPROVED = 2,
}
