export enum ChargingBookingStatus {
    Init = 0,
    Charging = 1,
    ChargeCompleted = 2,
    Completed = 3,
    Error = 4,
    Cancelled = 5,
    Onhold = 6,
    Noshow = 7,
}
