export enum PenaltyConfigurationType {
    NoShow = 0,
    Idle = 1,
    Cancel = 2,
}
