import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { IConfirmOptions } from '../../interfaces/confirm-options.interface';

@Component({
    selector: 'emsp-confirm',
    templateUrl: './confirm.component.html',
    styleUrls: ['./confirm.component.css'],
})
export class ConfirmComponent extends BaseComponent implements OnInit {
    @Input() options: IConfirmOptions;

    @Output() closed: EventEmitter<any> = new EventEmitter<any>();
    @Output() submited: EventEmitter<any> = new EventEmitter<any>();

    constructor() {
        super();
    }

    ngOnInit(): void {}

    public onModalClose(): void {
        this.closed.emit(this.options.closeValue || false);
    }
}
