import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ControlContainer, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { BaseComponent } from '../../../../base.component';
import { errorMessages } from '../../../constants/error-messages.constant';
import { ValidationHelper } from '../../../helpers/validation.helper';
import { BillInvoiceRequestModel } from '../../../models/invoice-info.model';

@Component({
    selector: 'emsp-request-invoice',
    templateUrl: './request-invoice.component.html',
    styleUrls: ['./request-invoice.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RequestInvoiceComponent extends BaseComponent implements OnInit {
    @Input() public invoiceInfo: BillInvoiceRequestModel;

    public validationHelper = ValidationHelper;
    public errorRequired = false;
    public errorMessages = errorMessages;
    public invoiceRequestForm: FormGroup;

    constructor(private readonly formBuilder: FormBuilder, public readonly cdr: ChangeDetectorRef) {
        super();
    }

    ngOnInit(): void {
        this.invoiceRequestForm = this.formBuilder.group({
            fullName: [
                {
                    value: this.invoiceInfo.fullName ?? '',
                },
                [Validators.required],
            ],
            phoneNumber: [
                {
                    value: this.invoiceInfo.phoneNumber ?? '',
                },
                [Validators.required],
            ],
            address: [
                {
                    value: this.invoiceInfo.address ?? '',
                },
                [Validators.required],
            ],
            email: [
                {
                    value: this.invoiceInfo.email ?? '',
                },
                [Validators.required],
            ],
            taxCode: [
                {
                    value: this.invoiceInfo.taxCode ?? '',
                },
            ],
        });
    }
}
