import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from '../../../base.component';
import { InvoiceRegister } from '../../models/invoice-register.model';

@Component({
    selector: 'emsp-invoice-info',
    templateUrl: './invoice-info.component.html',
    styleUrls: ['./invoice-info.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InvoiceInfoComponent extends BaseComponent implements OnInit {
    @Input() public invoiceCustomerInfo: InvoiceRegister;

    constructor() {
        super();
    }

    ngOnInit(): void {}
}
