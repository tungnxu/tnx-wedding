import { IGridData } from './../../interfaces/grid-data.interface';
import { MainGridColumnComponent } from './../main-grid-column/main-grid-column.component';
import {
    ChangeDetectionStrategy,
    Component,
    ContentChild,
    ContentChildren,
    EventEmitter,
    Input,
    OnInit,
    Output,
    QueryList,
    OnChanges,
    SimpleChanges,
    AfterViewInit,
    AfterContentInit,
    AfterContentChecked,
    ViewChild,
    ElementRef,
    AfterViewChecked,
} from '@angular/core';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { MainGridCheckboxColumnComponent } from '../main-grid-checkbox-column/main-grid-checkbox-column.component';
import { BaseComponent } from '../../../base.component';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';

@Component({
    selector: 'emsp-main-grid',
    templateUrl: './main-grid.component.html',
    styleUrls: ['./main-grid.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MainGridComponent
    extends BaseComponent
    implements OnInit, OnChanges, AfterContentInit, AfterViewInit, AfterContentChecked, AfterViewChecked
{
    @ContentChildren(MainGridColumnComponent) gridColumns: QueryList<MainGridColumnComponent>;
    @ContentChild(MainGridCheckboxColumnComponent) checkbox: MainGridCheckboxColumnComponent;
    @ViewChild('table') table: ElementRef<HTMLTableElement>;

    @Input() public requestFilter: IMainFiltering;
    @Input() public data: IGridData<any>;
    @Input() public pageable = true;
    @Input() public selectionKey: string;
    @Input() public showNumberColumn = true;
    @Input() public maxSize = 10;
    @Input() public usePagination = true;

    @Output() public filtered = new EventEmitter<IMainFiltering>();
    @Output() public selectedKeysChange = new EventEmitter<any[]>();
    @Output() public selectedItemsChange = new EventEmitter<any[]>();

    public loading = false;
    public total: number;
    public currentData: any[] = [];
    public checkAll = {
        indeterminate: false,
        checked: false,
    };
    public selectionField = 'selected';
    public totalColumn = 0;
    public gridSortByField: string;
    public arrRecordPageSize: number[] = [10, 20, 50, 100];

    constructor(private readonly appConfigurationStateService: AppConfigurationStateService) {
        super();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.data) {
            this.loading = false;
            this.updateCurrentData(changes.data.currentValue);
        }
    }

    ngOnInit(): void {}

    ngAfterContentInit(): void {
        if (this.checkbox && this.checkbox.selectionField) {
            this.selectionField = this.checkbox.selectionField;
        }
    }

    ngAfterContentChecked(): void {
        if (this.gridColumns?.length > 0) {
            this.totalColumn = this.gridColumns.length + (this.checkbox ? 1 : 0) + (this.showNumberColumn ? 1 : 0);
        }
    }

    ngAfterViewInit(): void {
        this.changeCheckAll();
    }

    ngAfterViewChecked(): void {
        if (this.table && this.table.nativeElement.offsetWidth > this.table.nativeElement.parentElement.offsetWidth) {
            this.table.nativeElement.parentElement.classList.add('table-responsive');
        }

        if (this.table.nativeElement.parentElement.offsetHeight >= window.innerHeight - 100) {
            this.table.nativeElement.parentElement.classList.add('active');
        }
    }

    public filter(): void {
        this.loading = true;
        this.filtered.emit(this.requestFilter);
    }

    public selectAll(): void {
        this.checkAll.indeterminate = false;
        for (const item of this.currentData) {
            item[this.selectionField] = this.checkAll.checked;
        }
        const selectedItems = this.currentData.filter((item) => item[this.selectionField]);
        this.selectedItemsChange.emit(selectedItems);
        this.selectedKeysChange.emit(selectedItems.map((item) => item[this.selectionKey]));
    }

    public selectItem(selectedItem: any): void {
        selectedItem[this.selectionField] = !selectedItem[this.selectionField];
        this.changeCheckAll();
    }

    public pageChanged(event: any): void {
        this.requestFilter.pageIndex = parseInt(event.page, 10) - 1;
        this.filter();
    }

    public onSortOrder(condition: { sortByField: string; sortDirection: string }): void {
        this.requestFilter.sortBy = condition.sortByField;
        this.requestFilter.direction = condition.sortDirection;
        this.gridSortByField = condition.sortByField;
        this.filter();
    }

    private updateCurrentData(gridData: IGridData<any>): void {
        if (gridData) {
            this.total = gridData.total || 0;
            this.currentData = gridData.data.map((data) => ({ ...data }));
            this.changeCheckAll();
        }
    }

    private changeCheckAll(): void {
        this.checkAll.indeterminate = false;
        const selectedItems = this.currentData.filter((item) => item[this.selectionField]);
        const numberOfSelectedItems = selectedItems.length;

        if (numberOfSelectedItems === this.currentData.length) {
            this.checkAll.checked = true;
        } else {
            if (numberOfSelectedItems === 0) {
                this.checkAll.checked = false;
            } else {
                this.checkAll.indeterminate = true;
            }
        }

        this.selectedItemsChange.emit(selectedItems);
        this.selectedKeysChange.emit(selectedItems.map((item) => item[this.selectionKey]));
    }

    public setRecordPageSize(size: number): void {
        this.requestFilter.pageSize = size;
        this.appConfigurationStateService.updatePageSizeGrid(this.requestFilter.pageSize);
        // this.filtered.emit(this.requestFilter);
    }
}
