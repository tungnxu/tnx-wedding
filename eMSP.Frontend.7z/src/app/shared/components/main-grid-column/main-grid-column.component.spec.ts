import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainGridColumnComponent } from './main-grid-column.component';

describe('MainGridColumnComponent', () => {
    let component: MainGridColumnComponent;
    let fixture: ComponentFixture<MainGridColumnComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [MainGridColumnComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MainGridColumnComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
