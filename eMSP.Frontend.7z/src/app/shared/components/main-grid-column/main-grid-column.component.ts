import {
    ChangeDetectionStrategy,
    Component,
    ContentChild,
    Input,
    OnInit,
    TemplateRef,
    OnChanges,
    AfterContentInit,
    SimpleChanges,
    EventEmitter,
    Output,
} from '@angular/core';
import { getPropertyValue } from '../../helpers/object.helper';

@Component({
    selector: 'emsp-main-grid-column',
    templateUrl: './main-grid-column.component.html',
    styleUrls: ['./main-grid-column.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MainGridColumnComponent implements OnInit, OnChanges, AfterContentInit {
    @ContentChild(TemplateRef) templateRef: TemplateRef<any>;

    @Input() public title: string;
    @Input() public class: string;
    @Input() public headerClass: string;
    @Input() public item: any;
    @Input() public content: TemplateRef<any>;
    @Input() public field: string;
    @Input() public sortByField: string;
    @Input() public gridSortByField: string;

    @Output() public sorted = new EventEmitter<{ sortByField: string; sortDirection: string }>();

    public hasCustomTemplate = false;
    public value: string = '';
    public isSortedByAsc = false;
    public isSorted = false;

    constructor() {}

    ngOnChanges(changes: SimpleChanges): void {
        this.value = this.title;
        if (this.item && !this.content && this.field) {
            this.value = getPropertyValue(this.item, this.field)?.toString();
        }
    }

    ngOnInit(): void {}

    ngAfterContentInit(): void {
        if (this.content) {
            this.hasCustomTemplate = true;
        }
    }

    public sort(): void {
        if (!this.sortByField) {
            return;
        }
        this.isSorted = true;
        this.isSortedByAsc = !this.isSortedByAsc;
        this.sorted.emit({ sortByField: this.sortByField, sortDirection: this.isSortedByAsc ? 'asc' : 'desc' });
    }
}
