import {
    ChangeDetectionStrategy,
    Component,
    ContentChildren,
    ElementRef,
    EventEmitter,
    HostListener,
    Input,
    OnInit,
    Output,
    QueryList,
    ViewChild,
} from '@angular/core';
import { PopoverDirective } from 'ngx-bootstrap/popover';
import { Observable, Observer, of, Subject } from 'rxjs';
import { catchError, debounceTime, map, switchMap, takeUntil, tap, withLatestFrom } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { BaseComponent } from '../../../base.component';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { ChargingItem } from '../../shared.model';
import { MainFilterItemTemplateComponent } from '../main-filter-item-template/main-filter-item-template.component';
import { DatePipe } from '@angular/common';
import { ValidationHelper } from '../../helpers/validation.helper';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { UiConfigurationViewModel } from '../../view-models/ui-configuration.viewModel';
import { AppConfigurationStateService } from '../../../core/services/app-configuration-state.service';
import { ChargingStationApiService } from '../../services/api-services/charging-station-api.service';

@Component({
    selector: 'emsp-main-filter',
    templateUrl: `./main-filter${environment.layout}.component.html`,
    styleUrls: ['./main-filter.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    providers: [DatePipe],
})
export class MainFilterComponent extends BaseComponent implements OnInit {
    @ContentChildren(MainFilterItemTemplateComponent) filterItemTemplates: QueryList<MainFilterItemTemplateComponent>;
    @ViewChild('popover') popover: PopoverDirective;

    @Input() public requestFilter: IMainFiltering;
    @Input() public useAdvanceSearch = true;

    @Output() public filtered = new EventEmitter<IMainFiltering>();

    public isShowSuggetions: boolean;
    public fromDate: Date;
    public toDate: Date;
    public keySearchText: string;
    public nameSearchText: string;
    public isClickFromDatePicker = false;

    public filteredByNameChargingItems$: Observable<ChargingItem[]>;
    public filteredByKeyChargingItems$: Observable<ChargingItem[]>;
    public uiConfigurations$: Observable<UiConfigurationViewModel>;

    //#region for default layout
    public showAdvanceFilter = false;
    public filteredByNameChargingsItems$: Observable<ChargingItem[]>;
    public chargingNameFilterChange$ = new Subject<KeyboardEvent>();
    public filteredByKeyChargingsItems$: Observable<ChargingItem[]>;
    public chargingKeyFilterChange$ = new Subject<KeyboardEvent>();
    public bsDatepickerConfig: Partial<BsDatepickerConfig>;
    //#endregion

    public filter$ = new Subject<void>();

    @HostListener('document:click', ['$event'])
    public handleClickDocument(event): void {
        if (!this.elementRef.nativeElement.contains(event.target)) {
            if (!this.isClickFromDatePicker) {
                this.popover && this.popover.hide();
            }
            this.isClickFromDatePicker = false;
        }
    }

    constructor(
        private readonly chargingStationApiService: ChargingStationApiService,
        private readonly datepipe: DatePipe,
        private readonly elementRef: ElementRef,
        private readonly appConfigurationStateService: AppConfigurationStateService
    ) {
        super();
    }

    ngOnInit(): void {
        this.uiConfigurations$ = this.appConfigurationStateService.uiConfigurations$.pipe(takeUntil(this.destroyed$));
        this.uiConfigurations$
            .pipe(
                tap(
                    (uiConfigurations) =>
                        (this.bsDatepickerConfig = {
                            dateInputFormat: uiConfigurations.clientDateFormat.toUpperCase(),
                            adaptivePosition: true,
                        })
                )
            )
            .subscribe();

        this.filteredByNameChargingItems$ = new Observable((observer: Observer<string>) => {
            observer.next(this.nameSearchText);
        }).pipe(
            debounceTime(300),
            switchMap((query: string) => {
                if (query) {
                    return this.chargingStationApiService.getAutoComplete({ name: query }).pipe(
                        catchError((ex) => {
                            console.log(ex);
                            return of(null);
                        }),
                        map((resp) => {
                            if (resp?.success) {
                                return resp.data.items;
                            }
                            return [];
                        })
                    );
                }

                return of([]);
            }),
            takeUntil(this.destroyed$)
        );

        this.filteredByKeyChargingItems$ = new Observable((observer: Observer<string>) => {
            observer.next(this.keySearchText);
        }).pipe(
            debounceTime(300),
            switchMap((query: string) => {
                if (query) {
                    return this.chargingStationApiService.getAutoComplete({ key: query }).pipe(
                        catchError((ex) => {
                            console.log(ex);
                            return of(null);
                        }),
                        map((resp) => {
                            if (resp?.success) {
                                return resp.data.items;
                            }
                            return [];
                        })
                    );
                }

                return of([]);
            }),
            takeUntil(this.destroyed$)
        );

        //#region for default layout
        this.filteredByNameChargingsItems$ = this.chargingNameFilterChange$.pipe(
            debounceTime(300),
            switchMap((event: KeyboardEvent) =>
                this.chargingStationApiService.getAutoComplete({ name: (event.target as HTMLInputElement).value }).pipe(
                    catchError((ex) => {
                        console.log(ex);
                        return of(null);
                    })
                )
            ),
            map((resp) => {
                if (resp?.success) {
                    this.isShowSuggetions = true;
                    return resp.data.items;
                }
                return [];
            }),
            takeUntil(this.destroyed$)
        );

        this.filteredByKeyChargingsItems$ = this.chargingKeyFilterChange$.pipe(
            debounceTime(300),
            switchMap((event: KeyboardEvent) =>
                this.chargingStationApiService.getAutoComplete({ key: (event.target as HTMLInputElement).value }).pipe(
                    catchError((ex) => {
                        console.log(ex);
                        return of(null);
                    })
                )
            ),
            map((resp) => {
                if (resp?.success) {
                    this.isShowSuggetions = true;
                    return resp.data.items;
                }
                return [];
            }),
            takeUntil(this.destroyed$)
        );
        //#endregion

        this.handleFilter();
    }

    public handleFilter(): void {
        this.filter$
            .pipe(
                withLatestFrom(this.uiConfigurations$),
                tap(([, uiConfigurations]) => {
                    if (this.popover) {
                        this.popover.hide();
                    }

                    // undefined is not show filter
                    if (this.requestFilter.fromDate !== undefined) {
                        if (ValidationHelper.checkValidDate(this.fromDate)) {
                            this.requestFilter.fromDate = this.fromDate
                                ? this.datepipe.transform(this.fromDate, uiConfigurations.serverDateFormat)
                                : '';
                        } else {
                            this.requestFilter.fromDate = '';
                            this.fromDate = null;
                        }
                    }

                    if (this.requestFilter.toDate !== undefined) {
                        if (ValidationHelper.checkValidDate(this.toDate)) {
                            this.requestFilter.toDate = this.toDate ? this.datepipe.transform(this.toDate, uiConfigurations.serverDateFormat) : '';
                        } else {
                            this.requestFilter.toDate = '';
                            this.toDate = null;
                        }
                    }

                    if (this.requestFilter.key !== undefined) {
                        this.requestFilter.key = this.requestFilter.key ?? '';
                    }

                    if (this.requestFilter.name !== undefined) {
                        this.requestFilter.name = this.requestFilter.name ?? '';
                    }

                    if (this.requestFilter.customerId !== undefined) {
                        this.requestFilter.customerId = this.requestFilter.customerId ?? '';
                    }

                    if (this.requestFilter.vehicleId !== undefined) {
                        this.requestFilter.vehicleId = this.requestFilter.vehicleId ?? '';
                    }
                    if (this.requestFilter.pageSize !== uiConfigurations.pageSizeGrid) {
                        this.appConfigurationStateService.updatePageSizeGrid(this.requestFilter.pageSize);
                    }
                    Object.keys(this.requestFilter).forEach((key) => {
                        if (typeof this.requestFilter[key] === 'string') {
                            this.requestFilter[key] = this.requestFilter[key].trim();
                        }
                    });
                    this.filtered.emit(this.requestFilter);
                }),
                takeUntil(this.destroyed$)
            )
            .subscribe();
    }

    public enter(event: KeyboardEvent): void {
        if (event && (event.code === 'Enter' || event.code === 'NumpadEnter')) {
            this.filter$.next();
        }
    }

    public onSelectChargingItemId(): void {
        this.requestFilter.key = this.keySearchText;
    }

    public onKeySearchTextChange(keySearchText): void {
        if (!keySearchText) {
            this.requestFilter.key = '';
        }
    }

    public onSelectChargingName(): void {
        this.requestFilter.name = this.nameSearchText;
    }

    public onNameSearchTextChange(nameSearchText): void {
        if (!nameSearchText) {
            this.requestFilter.name = '';
        }
    }

    public checkShowFilter(key: string): boolean {
        return this.requestFilter?.hasOwnProperty(key);
    }

    //#region for default layout
    public onSelectChargingItem(chargingItem: ChargingItem): void {
        this.requestFilter.key = chargingItem.itemId;
        this.isShowSuggetions = false;
    }
    //#endregion

    public bsDatepickerHide(): void {
        this.isClickFromDatePicker = true;
    }
}
