import { Component, ContentChild, OnInit, TemplateRef, Input } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { sideBarNavData } from '../../constants/side-bar.constant';
import { ExecutionContext } from '../../models/execution-context';

@Component({
    selector: 'emsp-main-header',
    templateUrl: './main-header.component.html',
    styleUrls: ['./main-header.component.css'],
})
export class MainHeaderComponent extends BaseComponent implements OnInit {
    @ContentChild(TemplateRef) templateRef: TemplateRef<any>;
    @Input() public titleCustom: string;

    public icon = '';
    public executionContext$: Observable<ExecutionContext>;

    constructor(public readonly activatedRoute: ActivatedRoute, private readonly router: Router) {
        super();
    }

    ngOnInit(): void {
        if (this.router.url) {
            this.getIcon(this.router.url);
        }
        this.router.events
            .pipe(
                filter((event) => event instanceof NavigationEnd),
                takeUntil(this.destroyed$)
            )
            .subscribe(() => {
                this.getIcon(this.router.url);
            });
    }

    private getIcon(url: string): void {
        this.icon = sideBarNavData.flatMap((data) => data.children).find((data) => data.url === url)?.icon || '';
    }
}
