import { Component, Input, OnInit } from '@angular/core';

@Component({
    selector: 'emsp-main-grid-checkbox-column',
    templateUrl: './main-grid-checkbox-column.component.html',
    styleUrls: ['./main-grid-checkbox-column.component.css'],
})
export class MainGridCheckboxColumnComponent implements OnInit {
    @Input() public useSelectAll: boolean = true;
    @Input() public headerClass: string;
    @Input() public class: string;
    @Input() public selectionField: string;
    constructor() {}

    ngOnInit(): void {}
}
