import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainGridCheckboxColumnComponent } from './main-grid-checkbox-column.component';

describe('MainGridCheckboxColumnComponent', () => {
    let component: MainGridCheckboxColumnComponent;
    let fixture: ComponentFixture<MainGridCheckboxColumnComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [MainGridCheckboxColumnComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MainGridCheckboxColumnComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
