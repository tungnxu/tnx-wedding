import { AfterViewInit, Component, ComponentFactoryResolver, ComponentRef, DoCheck, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { BaseComponent } from '../../../base.component';
import { IModalConfiguration } from '../../interfaces/modal-configuration.interface';
import * as R from 'ramda';

@Component({
    selector: 'emsp-modal',
    templateUrl: './modal.component.html',
    styleUrls: ['./modal.component.css'],
})
export class ModalComponent extends BaseComponent implements OnInit, AfterViewInit, DoCheck {
    @ViewChild('modalBody', { read: ViewContainerRef }) bodyContent: ViewContainerRef;

    @Input() public config: IModalConfiguration = {
        title: '',
        template: '',
        closeFuncName: 'closed',
        submitFuncName: 'submited',
    };
    public cmpRef: ComponentRef<any>;

    private inputPassed = false;

    constructor(private readonly bsModalRef: BsModalRef, private readonly componentFactoryResolver: ComponentFactoryResolver) {
        super();
    }

    ngOnInit(): void {
        this.destroyed$.subscribe(() => {
            if (this.cmpRef) {
                this.cmpRef.destroy();
            }

            if (this.config.onModalClose) {
                this.config.onModalClose();
            }
        });
    }

    ngAfterViewInit(): void {
        this.initialModal();
    }

    ngDoCheck(): void {
        if (!this.inputPassed && this.config.component) {
            this.initialModal();
            this.inputPassed = true;
        }
    }

    public close(): void {
        if (this.cmpRef.instance.onModalClose) {
            this.cmpRef.instance.onModalClose();
        }

        if (this.config.onModalClose) {
            this.config.onModalClose();
        }

        this.bsModalRef.hide();
    }

    private initialModal(): void {
        if (this.cmpRef) {
            this.cmpRef.destroy();
        }

        if (this.config.component) {
            const factory = this.componentFactoryResolver.resolveComponentFactory(this.config.component);
            this.cmpRef = this.bodyContent.createComponent(factory);
            this.cmpRef.instance[this.config.closeFuncName || 'closed'].subscribe((data) => {
                if (this.config.onClose) {
                    this.config.onClose(data);
                }

                this.bsModalRef.hide();
            });
            this.cmpRef.instance[this.config.submitFuncName || 'submited'].subscribe((data) => {
                if (this.config.onSubmit) {
                    this.config.onSubmit(data);
                }

                this.bsModalRef.hide();
            });

            if (this.config.inputs && this.config.inputs.length > 0) {
                for (const configInput of this.config.inputs) {
                    this.cmpRef.instance[configInput.key] = R.clone(configInput.value);
                }
            }

            if (this.config.outputs && this.config.outputs.length > 0) {
                for (const configOutput of this.config.outputs) {
                    this.cmpRef.instance[configOutput.key].subscribe((data) => {
                        if (configOutput.value && typeof configOutput.value === 'function') {
                            configOutput.value(data);
                        }
                    });
                }
            }
        }
    }
}
