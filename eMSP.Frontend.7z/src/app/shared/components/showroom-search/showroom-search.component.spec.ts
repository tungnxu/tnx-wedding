import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowroomSearchComponent } from './showroom-search.component';

describe('ShowroomSearchComponent', () => {
    let component: ShowroomSearchComponent;
    let fixture: ComponentFixture<ShowroomSearchComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ShowroomSearchComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ShowroomSearchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
