import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { Observable, Observer, of } from 'rxjs';
import { debounceTime, switchMap, catchError, map, takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../../base.component';
import { errorMessages } from '../../constants/error-messages.constant';
import { ValidationHelper } from '../../helpers/validation.helper';
import { Showroom } from '../../models/showroom.model';
import { BillApiService } from '../../services/api-services/bill-api.service';

@Component({
    selector: 'emsp-showroom-search',
    templateUrl: './showroom-search.component.html',
    styleUrls: ['./showroom-search.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ShowroomSearchComponent extends BaseComponent implements OnInit {
    @Input() public isRequire: boolean;
    @Input() public showroomInput: Showroom;

    @Output() searched: EventEmitter<Showroom> = new EventEmitter<Showroom>();
    public showroomSeach: string;
    public showroomName: string;
    public showroomSeachSelected: Showroom;
    public errorMessages = errorMessages;
    public searchShowRoomForm: FormGroup;
    public validationHelper = ValidationHelper;

    public showroom$: Observable<Showroom[]>;

    constructor(private readonly billApiService: BillApiService, public readonly cdr: ChangeDetectorRef, private readonly formBuilder: FormBuilder) {
        super();
    }

    ngOnInit(): void {
        this.searchShowRoomForm = this.formBuilder.group({
            showroomSearch: [
                {
                    value: this.showroomSeach ?? '',
                },
                [Validators.required],
            ],
        });
        this.showroom$ = new Observable((observer: Observer<string>) => {
            observer.next(this.showroomSeach);
        }).pipe(
            debounceTime(300),
            switchMap((search: string) => {
                if (search) {
                    return this.billApiService.seachShowroom(search).pipe(
                        catchError((ex) => {
                            return of(null);
                        }),
                        map((resp) => {
                            if (resp?.data) {
                                return resp.data;
                            }
                            return [];
                        })
                    );
                }

                return of([]);
            }),
            takeUntil(this.destroyed$)
        );
    }

    public enter(event: KeyboardEvent): void {}

    public search(): void {}

    public onSelectShowroom(event: TypeaheadMatch): void {
        this.showroomName = event.item?.storeName;
        this.searched.emit(event.item);
        this.cdr.detectChanges();
    }
    public onShowroomTextChange(showroomSeach: string): void {
        this.cdr.detectChanges();
        if (this.showroomInput) {
            this.searched.emit(null);
        }
        if (this.showroomName) {
            this.showroomName = '';
        }
    }
}
