import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MainFilterItemTemplateComponent } from './main-filter-item-template.component';

describe('MainFilterItemTemplateComponent', () => {
    let component: MainFilterItemTemplateComponent;
    let fixture: ComponentFixture<MainFilterItemTemplateComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [MainFilterItemTemplateComponent],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MainFilterItemTemplateComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
