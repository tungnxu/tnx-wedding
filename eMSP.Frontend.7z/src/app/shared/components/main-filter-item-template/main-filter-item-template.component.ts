import { ChangeDetectionStrategy, Component, ContentChild, Input, OnInit, TemplateRef } from '@angular/core';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';

@Component({
    selector: 'emsp-main-filter-item-template',
    templateUrl: './main-filter-item-template.component.html',
    styleUrls: ['./main-filter-item-template.component.css'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MainFilterItemTemplateComponent implements OnInit {
    @ContentChild(TemplateRef) templateRef: TemplateRef<any>;

    @Input() public content: TemplateRef<any>;
    @Input() public requestFilter: IMainFiltering;

    constructor() {}

    ngOnInit(): void {}
}
