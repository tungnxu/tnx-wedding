import { IUpdateRoleReq } from './../../interfaces/role-req.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { ICreateRoleReq } from '../../interfaces/role-req.interface';
import { Role } from '../../models/role.model';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({ providedIn: 'root' })
export class RoleApiService {
    private baseUrl: string;

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/system/roles`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<Role>>> {
        return this.httpClient.get<Response<PagingResponse<Role>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public cetAllRoles(): Observable<Role[]> {
        return this.httpClient.get<Role[]>(`${this.baseUrl}/all-roles`);
    }

    public create(request: ICreateRoleReq): Observable<Response<Role>> {
        return this.httpClient.post<Response<Role>>(`${this.baseUrl}/create`, request, {});
    }

    public update(request: IUpdateRoleReq): Observable<Response<Role>> {
        return this.httpClient.put<Response<Role>>(`${this.baseUrl}/update`, request, {});
    }

    public delete(id: string): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete/${id}`, {});
    }
}
