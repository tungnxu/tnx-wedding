import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';

@Injectable({
    providedIn: 'root',
})
export class FileApiService {
    private baseUrl: string;

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/files/`;
    }

    public getImage(vehicleId: string, fileName: string) {
        return this.httpClient.get(`${this.baseUrl}image/${encodeURIComponent(vehicleId)}/${fileName}`, {
            responseType: 'text',
        });
    }
}
