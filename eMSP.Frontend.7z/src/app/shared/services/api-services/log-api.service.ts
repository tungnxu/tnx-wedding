import { IMainFiltering } from './../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Log } from '../../../views/log/log.model';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class LogApiService {
    private baseUrl: string;
    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/logs`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<Log>>> {
        return this.httpClient.get<Response<PagingResponse<Log>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public retrieve(id: string): Observable<Response<Log>> {
        return this.httpClient.get<Response<Log>>(`${this.baseUrl}/retrieve/${id}`);
    }

    public delete(ids: string[]): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?ids=${ids}`);
    }
}
