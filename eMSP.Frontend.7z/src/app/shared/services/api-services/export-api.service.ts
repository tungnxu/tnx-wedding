import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IReportOdoFiltering, ISAPTransactionSearchRequest } from '../../interfaces/report-req.interface';
import { environment } from '../../../../environments/environment';
import { IChargingBookingReq } from '../../interfaces/charging-booking-req.interface';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { IBatteryLeasingDetail } from '../../interfaces/battery-leasing-detail-req.interface';
import { IChargingBookingDetailSearchReq } from '../../interfaces/charging-booking-detail-req.interface';
import { IReportDebtShowRoom } from '../../interfaces/debt-showroom-req.interface';
import { IOdoListSearchRequest } from '../../interfaces/odo-list-req.interface';
import { IBillListSearchRequest } from '../../interfaces/bill-list-req.interface';
import { IBatterySubscriptionSearchRequest } from '../../interfaces/battery-subscription-req.interface';

@Injectable({
    providedIn: 'root',
})
export class ExportApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/export`;
    }

    public exportSAPTransaction(req: ISAPTransactionSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/sap-transaction`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportChargingBookingTransaction(req: IChargingBookingReq): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/charging-booking-transaction`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportChargingBookingTransactionReport(req: IChargingBookingReq): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/charging-booking-transaction-report`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportBatteryLeasingReport(req: IMainFiltering): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/battery-leasing`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportBatteryLeasingDetailReport(req: IBatteryLeasingDetail): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/battery-leasing-detail`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportChargingBlockingReport(req: IOdoListSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/charging-blocking`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportChargingBookingReport(req: IChargingBookingDetailSearchReq): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/charging-booking`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportDebtShowRoomReport(req: IReportDebtShowRoom): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/sr-revenue`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportSRRevenueDetailReport(req: IReportDebtShowRoom): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/sr-revenue-details`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportOdoReport(req: IReportOdoFiltering): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/odo`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportBillReport(req: IBillListSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/bills`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportBatterySubscriptionReport(req: IBatterySubscriptionSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/battery-subscriptions`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportDebtsReport(req: IMainFiltering): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/customer-bills`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }
}
