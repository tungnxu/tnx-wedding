import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ISAPTransactionSearchRequest } from '../../interfaces/report-req.interface';
import { environment } from '../../../../environments/environment';
import { IBillListSearchRequest } from '../../interfaces/bill-list-req.interface';
import { IBatterySubscriptionSearchRequest } from '../../interfaces/battery-subscription-req.interface';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';

@Injectable({
    providedIn: 'root',
})
export class EscooterExportApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/escooter/export`;
    }

    public exportSAPTransaction(req: ISAPTransactionSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/sap-transaction`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportBills(req: IBillListSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/bills`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportEscooterBatterySubscriptionReport(req: IBatterySubscriptionSearchRequest): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/battery-subscriptions`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }

    public exportEscooterDebtListReport(req: IMainFiltering): Observable<any> {
        return this.httpClient.get(`${this.baseUrl}/customer-bills`, {
            params: req as any,
            responseType: 'arraybuffer',
        });
    }
}
