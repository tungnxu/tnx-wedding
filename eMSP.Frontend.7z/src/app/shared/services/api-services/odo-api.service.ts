import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { Odo } from '../../models/odo.model';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class OdoApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/odo/`;
    }

    public getOdoList(request: IMainFiltering): Observable<Response<PagingResponse<Odo>>> {
        return this.httpClient.get<Response<PagingResponse<Odo>>>(`${this.baseUrl}search`, {
            params: request as any,
        });
    }
}
