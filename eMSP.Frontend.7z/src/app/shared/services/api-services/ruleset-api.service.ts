import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DynamicRuleSetRequest } from '../../models/dynamic-rule-set.model';
import { IRuleSearch } from '../../interfaces/rule-search.interface';
import { RuleSet, Rule } from '../../../views/multidimensional-pricing-config/multidimensional-pricing-config.model';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class RulesetApiService {
    private baseUrl: string;
    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/pricing-model/rulesets`;
    }

    public search(request: IRuleSearch): Observable<Response<PagingResponse<RuleSet>>> {
        return this.httpClient.get<Response<PagingResponse<RuleSet>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public create(request: RuleSet): Observable<Response<RuleSet>> {
        return this.httpClient.post<Response<RuleSet>>(`${this.baseUrl}/create`, request);
    }

    public update(request: RuleSet): Observable<Response<RuleSet>> {
        return this.httpClient.put<Response<RuleSet>>(`${this.baseUrl}/update`, request);
    }

    public delete(ids: string[]): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?ids=${ids}`);
    }

    public execute<T>(request: DynamicRuleSetRequest): Observable<Response<T>> {
        return this.httpClient.post<Response<T>>(`${this.baseUrl}/execute`, request);
    }

    public checkCode(code: string): Observable<Response<boolean>> {
        return this.httpClient.get<Response<boolean>>(`${this.baseUrl}/checkCode?code=${code}`);
    }

    public getAvailableRule(id: string): Observable<Rule[]> {
        return this.httpClient.get<Rule[]>(`${this.baseUrl}/availableRule?id=${id}`);
    }
}
