import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Job } from '../../../views/job/job.model';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';
import { ICreateOrUpdateJobReq } from '../../interfaces/job-req.interface';

@Injectable({
    providedIn: 'root',
})
export class JobApiService {
    private baseUrl: string;
    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/jobs`;
    }

    public syncChargingList(): Observable<Response<PagingResponse<boolean>>> {
        return this.httpClient.get<Response<PagingResponse<boolean>>>(`${this.baseUrl}/sync/charging-list`);
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<Job>>> {
        return this.httpClient.get<Response<PagingResponse<Job>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public retrieve(id: string): Observable<Response<Job>> {
        return this.httpClient.get<Response<Job>>(`${this.baseUrl}/retrieve/${id}`);
    }

    public retrieveJobDetail(key: string): Observable<Response<Job>> {
        return this.httpClient.get<Response<Job>>(`${this.baseUrl}/retrieve/detail/${key}`);
    }

    public verifyKey(key: string): Observable<Response<Job>> {
        return this.httpClient.get<Response<Job>>(`${this.baseUrl}/verify/${key}`);
    }

    public execute(key: string): Observable<Response<boolean>> {
        return this.httpClient.get<Response<boolean>>(`${this.baseUrl}/execute/${key}`);
    }

    public create(req: ICreateOrUpdateJobReq): Observable<Response<Job>> {
        return this.httpClient.post<Response<Job>>(`${this.baseUrl}/create`, req);
    }

    public clone(request: Job[]): Observable<Response<Job[]>> {
        return this.httpClient.post<Response<Job[]>>(`${this.baseUrl}/clone`, request);
    }

    public update(req: ICreateOrUpdateJobReq): Observable<Response<Job>> {
        return this.httpClient.put<Response<Job>>(`${this.baseUrl}/update`, req);
    }

    public delete(ids: string[]): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?ids=${ids}`);
    }
}
