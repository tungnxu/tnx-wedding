import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { ChargingBlocking } from '../../models/charging-blocking.model';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class ChargingBlockApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/charging-blocking/`;
    }

    public getChargingBlockList(request: IMainFiltering): Observable<Response<PagingResponse<ChargingBlocking>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingBlocking>>>(`${this.baseUrl}search`, {
            params: request as any,
        });
    }
}
