import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IReportBookingFiltering, ISAPTransactionSearchRequest } from '../../interfaces/report-req.interface';
import { SAPTransaction } from '../../models/sap-transaction.model';
import { IChargingBookingTransactionReportReq } from '../../interfaces/bill-req.interface';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { ChargingBookingReportViewModel } from '../../view-models/charging-booking-report.viewModel';
import { TransactionReportViewModel } from '../../view-models/transaction-report.viewModel';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';
import { BatteryLeasingReportViewModel } from '../../view-models/battery-leasing-report.viewModel';
import { DebtShowroomReportViewModel } from '../../view-models/debt-showroom.viewModel';
import { IReportDebtShowRoomDetailReq } from '../../interfaces/report-debt-showroom-detail-req.interface';

@Injectable({
    providedIn: 'root',
})
export class ReportApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/report`;
    }

    public searchSAPTransaction(req: ISAPTransactionSearchRequest): Observable<Response<PagingResponse<SAPTransaction>>> {
        return this.httpClient.get<Response<PagingResponse<SAPTransaction>>>(`${this.baseUrl}/sap/search`, {
            params: req as any,
        });
    }

    public getChargingBookingTransactionReport(request: IChargingBookingTransactionReportReq): Observable<TransactionReportViewModel[]> {
        return this.httpClient.get<TransactionReportViewModel[]>(`${this.baseUrl}/charging-booking-transaction/search`, {
            params: request as any,
        });
    }

    public getOtherTransactionReport(request: IMainFiltering): Observable<TransactionReportViewModel[]> {
        return this.httpClient.get<TransactionReportViewModel[]>(`${this.baseUrl}/other-transaction/search`, {
            params: request as any,
        });
    }

    public getChargingBookingReport(request: IReportBookingFiltering): Observable<Response<PagingResponse<ChargingBookingReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingBookingReportViewModel>>>(`${this.baseUrl}/charging-booking/search`, {
            params: request as any,
        });
    }

    public getBatteryLeasingReport(request: IMainFiltering): Observable<Response<PagingResponse<BatteryLeasingReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<BatteryLeasingReportViewModel>>>(`${this.baseUrl}/battery-leasing`, {
            params: request as any,
        });
    }

    public getBatteryLeasingDetailReport(request: IMainFiltering): Observable<Response<PagingResponse<BatteryLeasingReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<BatteryLeasingReportViewModel>>>(`${this.baseUrl}/battery-leasing/detail`, {
            params: request as any,
        });
    }

    public getOdoReport(request: IMainFiltering): Observable<Response<PagingResponse<BatteryLeasingReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<BatteryLeasingReportViewModel>>>(`${this.baseUrl}/odo`, {
            params: request as any,
        });
    }

    public getDebtShowRoomReport(request: IMainFiltering): Observable<Response<PagingResponse<DebtShowroomReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<DebtShowroomReportViewModel>>>(`${this.baseUrl}/sr-revenue`, {
            params: request as any,
        });
    }

    public getDebtShowRoomDetailReport(request: IReportDebtShowRoomDetailReq): Observable<Response<PagingResponse<DebtShowroomReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<DebtShowroomReportViewModel>>>(`${this.baseUrl}/sr-revenue/details`, {
            params: request as any,
        });
    }

    public getChargingBookingDetailReport(request: IMainFiltering): Observable<Response<PagingResponse<ChargingBookingReportViewModel>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingBookingReportViewModel>>>(`${this.baseUrl}/charging-booking/search`, {
            params: request as any,
        });
    }
}
