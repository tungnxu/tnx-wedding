import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { EWhiteListType } from '../../enums/white-list-type.enum';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { IChangeWhiteListStatusRQ, ICreateWhiteListRQ } from '../../interfaces/white-list-configuration-req.interface';
import { WhiteListBatterySubscription } from '../../models/battery-subscription.model';
import { EscooterBill } from '../../models/bill.model';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class EscooterOperatorApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/escooter/operation`;
    }

    public whiteListSearch(request: IMainFiltering): Observable<Response<PagingResponse<any>>> {
        return this.httpClient.get<Response<PagingResponse<any>>>(`${this.baseUrl}/whitelist`, {
            params: request as any,
        });
    }

    public whiteListSocCreate(request: ICreateWhiteListRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/whitelist-soc-create`, request);
    }

    public whiteListChargingCreate(request: ICreateWhiteListRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/whitelist-charging-create`, request);
    }

    public getSubscription(vehicleID: string): Observable<Response<WhiteListBatterySubscription>> {
        return this.httpClient.get<Response<WhiteListBatterySubscription>>(`${this.baseUrl}/get-subscription/${vehicleID}`);
    }

    public getEscooterBill(customerID: string): Observable<Response<EscooterBill>> {
        return this.httpClient.get<Response<EscooterBill>>(`${this.baseUrl}/get-escooter-bills/${customerID}`);
    }

    public whiteListChangeStatus(request: IChangeWhiteListStatusRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/whitelist-change-status`, request);
    }
}
