import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ICreateUpdateEScooterPolicyPackages } from '../../interfaces/escooter-policy-packages-req.interfaces';
import { ICretateUpdateEScooterSubscriptionPackage } from '../../interfaces/escooter-subscription-package-req.interfaces';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { EScooterPolicyPackage } from '../../models/escooter-policy-package';
import { EScooterSubscriptionPackage } from '../../models/escooter-subscription-package.model';
import { EScooterBatterySubscription, EScooterBatterySubscriptionDetail } from '../../models/escooter-battery-subscription.model';
import { PagingResponse, Response } from '../../models/response.model';
import { IPayBillReq } from '../../interfaces/bill-req.interface';
import { ISAPTransactionSearchRequest } from '../../interfaces/report-req.interface';
import { SAPTransaction } from '../../models/sap-transaction.model';
import { IInvoiceSearchRequest } from '../../interfaces/invoice-req.interface';
import { Invoice } from '../../models/invoice.model';
import { Bill } from '../../models/bill.model';
import {
    IBatterySubscriptionPackageChangeReq,
    IBatterySubscriptionPackagePostReq,
} from '../../interfaces/battery-subscription-package-req.interface';
import { BatterySubscriptionPackage } from '../../models/battery-subscription-package.model';

@Injectable({
    providedIn: 'root',
})
export class EScooterApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}`;
    }

    public searchEScooterBatterySubscription(req: IMainFiltering): Observable<Response<PagingResponse<EScooterBatterySubscription>>> {
        return this.httpClient.get<Response<PagingResponse<EScooterBatterySubscription>>>(`${this.baseUrl}/escooter/batteries-subscriptions/search`, {
            params: req as any,
        });
    }

    public retrieve(id: string): Observable<Response<EScooterBatterySubscriptionDetail>> {
        return this.httpClient.get<Response<EScooterBatterySubscriptionDetail>>(`${this.baseUrl}/escooter/batteries-subscriptions/retrieve/${id}`);
    }

    public searchEScooterBatteryPackages(req: IMainFiltering): Observable<Response<PagingResponse<EScooterSubscriptionPackage>>> {
        return this.httpClient.get<Response<PagingResponse<EScooterSubscriptionPackage>>>(`${this.baseUrl}/escooter/packages/search`, {
            params: req as any,
        });
    }

    public createEScooterSubscribeBatteryPackages(req: ICretateUpdateEScooterSubscriptionPackage): Observable<Response<any>> {
        return this.httpClient.post<Response<PagingResponse<EScooterSubscriptionPackage>>>(`${this.baseUrl}/escooter/packages/create`, req);
    }

    public updateEScooterSubscribeBatteryPackages(req: ICretateUpdateEScooterSubscriptionPackage, idPackage: string): Observable<Response<any>> {
        return this.httpClient.put<Response<PagingResponse<EScooterSubscriptionPackage>>>(
            `${this.baseUrl}/escooter/packages/update/${idPackage}`,
            req
        );
    }

    public searchEscooterPolicyPackages(req: IMainFiltering): Observable<Response<PagingResponse<EScooterPolicyPackage>>> {
        return this.httpClient.get<Response<PagingResponse<EScooterPolicyPackage>>>(`${this.baseUrl}/escooter/policy-package/search`, {
            params: req as any,
        });
    }

    public getPackagesPolicy(): Observable<Response<EScooterPolicyPackage[]>> {
        return this.httpClient.get<Response<EScooterPolicyPackage[]>>(`${this.baseUrl}/escooter/policy-package/list-battery-package`, {});
    }

    public createPolicyPackage(req: ICreateUpdateEScooterPolicyPackages): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/escooter/policy-package/create`, req);
    }

    public deletePolicyPackage(id: string[]): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/escooter/policy-package/delete?id=${id}`, {});
    }

    public updatePolicyPackage(request: ICreateUpdateEScooterPolicyPackages): Observable<Response<ICreateUpdateEScooterPolicyPackages>> {
        return this.httpClient.put<Response<ICreateUpdateEScooterPolicyPackages>>(`${this.baseUrl}/escooter/policy-package`, request, {});
    }

    public getBillsByCustomerId(request: IMainFiltering): Observable<Response<any>> {
        return this.httpClient.get<Response<any>>(`${this.baseUrl}/escooter/bills/get-bills-by-customer-id`, {
            params: request as any,
        });
    }

    public getDebtBillsByCustomerId(request: IMainFiltering): Observable<Response<any>> {
        return this.httpClient.get<Response<any>>(`${this.baseUrl}/escooter/bills/get-debt-bills-by-customer-id`, {
            params: request as any,
        });
    }
    public searchInvoice(request: IInvoiceSearchRequest): Observable<Response<PagingResponse<Invoice>>> {
        return this.httpClient.get<Response<PagingResponse<Invoice>>>(`${this.baseUrl}/escooter/bills/transaction-F5`, {
            params: request as any,
        });
    }

    public searchCustomerBills(request: IMainFiltering): Observable<Response<any>> {
        return this.httpClient.get<Response<any>>(`${this.baseUrl}/escooter/bills/get-customer-bills`, {
            params: request as any,
        });
    }

    public pay(req: IPayBillReq): Observable<Response<boolean>> {
        return this.httpClient.post<Response<boolean>>(`${this.baseUrl}/escooter/bills/pay`, req);
    }

    public getBillList(request: IMainFiltering): Observable<Response<PagingResponse<Bill>>> {
        return this.httpClient.get<Response<PagingResponse<Bill>>>(`${this.baseUrl}/escooter/bills`, {
            params: request as any,
        });
    }

    public searchSAPTransaction(req: ISAPTransactionSearchRequest): Observable<Response<PagingResponse<SAPTransaction>>> {
        return this.httpClient.get<Response<PagingResponse<SAPTransaction>>>(`${this.baseUrl}/escooter/report/sap/search`, {
            params: req as any,
        });
    }

    public getDetailBill(request: IInvoiceSearchRequest): Observable<Response<PagingResponse<Bill>>> {
        return this.httpClient.get<Response<PagingResponse<Bill>>>(`${this.baseUrl}/escooter/bills/detail-transaction`, {
            params: request as any,
        });
    }

    public searchPackage(req: IBatterySubscriptionPackagePostReq): Observable<Response<BatterySubscriptionPackage>> {
        return this.httpClient.get<Response<BatterySubscriptionPackage>>(`${this.baseUrl}/escooter/batteries-subscriptions/package-lists`, {
            params: req as any,
        });
    }

    public changePackage(req: IBatterySubscriptionPackageChangeReq): Observable<Response<BatterySubscriptionPackage>> {
        return this.httpClient.post<Response<BatterySubscriptionPackage>>(`${this.baseUrl}/escooter/batteries-subscriptions/request-package`, req);
    }
}
