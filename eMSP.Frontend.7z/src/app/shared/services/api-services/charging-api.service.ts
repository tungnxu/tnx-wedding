import { ICreateChargingConfigurationReq } from '../../interfaces/charging-req.interface';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ChargingConfiguration, ChargingValidationRequest } from '../../../views/charging/charging.model';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class ChargingApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/charging/configurations`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<ChargingConfiguration>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingConfiguration>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public create(request: ICreateChargingConfigurationReq): Observable<Response<ChargingConfiguration>> {
        return this.httpClient.post<Response<ChargingConfiguration>>(`${this.baseUrl}/create`, request, {});
    }

    public update(request: ChargingConfiguration): Observable<Response<ChargingConfiguration>> {
        return this.httpClient.put<Response<ChargingConfiguration>>(`${this.baseUrl}/update`, request, {});
    }

    public delete(ids: string[]): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?ids=${ids}`, {});
    }

    public ValidateItem(request: ChargingValidationRequest): Observable<Response<boolean>> {
        return this.httpClient.post<Response<boolean>>(`${this.baseUrl}/ValidateItem`, request, {});
    }
}
