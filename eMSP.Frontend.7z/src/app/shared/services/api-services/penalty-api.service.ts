import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PenaltyConfiguration } from '../../../views/penalty/penalty.model';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';
import { ICreatePenaltyConfigurationReq } from '../../interfaces/penalty-req.interface';

@Injectable({
    providedIn: 'root',
})
export class PenaltyApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/configurations/penalties`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<PenaltyConfiguration>>> {
        return this.httpClient.get<Response<PagingResponse<PenaltyConfiguration>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public create(req: ICreatePenaltyConfigurationReq): Observable<Response<PenaltyConfiguration>> {
        return this.httpClient.post<Response<PenaltyConfiguration>>(`${this.baseUrl}/create`, req, {});
    }

    public update(request: PenaltyConfiguration): Observable<Response<PenaltyConfiguration>> {
        return this.httpClient.put<Response<PenaltyConfiguration>>(`${this.baseUrl}/update`, request, {});
    }

    public delete(ids: string[]): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?ids=${ids}`, {});
    }
}
