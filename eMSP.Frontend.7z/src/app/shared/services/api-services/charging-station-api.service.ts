import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { ChargingStation } from '../../models/charging-station.model';
import { PagingResponse, Response } from '../../models/response.model';
import { ChargingItem, LookupItem } from '../../shared.model';

@Injectable({
    providedIn: 'root',
})
export class ChargingStationApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/charging/stations`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<ChargingStation>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingStation>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public getAutoComplete(request: IMainFiltering): Observable<Response<ChargingItem>> {
        return this.httpClient.get<Response<ChargingItem>>(`${this.baseUrl}/auto-complete`, {
            params: request as any,
        });
    }
}
