import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { ReportBookingProblem } from '../../../views/report-booking-problem/report-booking-problem.model';
import { ChargingBooking } from '../../../views/charging-booking/charging-booking.model';
import { ReviewReportBookingProblemReq } from '../../interfaces/review-report-booking-problem-req.interface';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';
import { IChargingBookingReq } from '../../interfaces/charging-booking-req.interface';
import { ManuallyCancelTransaction } from '../../models/manually-cancel-transaction.model';

@Injectable({
    providedIn: 'root',
})
export class ChargingBookingApiService {
    private baseUrl: string;

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/charging-booking`;
    }

    public search(request: IChargingBookingReq): Observable<Response<PagingResponse<ChargingBooking>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingBooking>>>(`${this.baseUrl}/bookings`, {
            params: request as any,
        });
    }

    public cancel(id: string): Observable<Response<ChargingBooking>> {
        return this.httpClient.put<Response<ChargingBooking>>(`${this.baseUrl}/cancel`, { ChargingBookingId: id }, {});
    }

    public transactionsSearch(request: IMainFiltering): Observable<Response<PagingResponse<ChargingBooking>>> {
        return this.httpClient.get<Response<PagingResponse<ChargingBooking>>>(`${this.baseUrl}/transactions`, {
            params: request as any,
        });
    }

    public getReportBookingProblems(request: IMainFiltering): Observable<Response<PagingResponse<ReportBookingProblem>>> {
        return this.httpClient.get<Response<PagingResponse<ReportBookingProblem>>>(`${this.baseUrl}/tickets`, {
            params: request as any,
        });
    }

    public reviewReportBookingProblem(req: ReviewReportBookingProblemReq): Observable<Response<ReportBookingProblem>> {
        return this.httpClient.post<Response<ReportBookingProblem>>(`${this.baseUrl}/tickets/review`, { Data: req }, {});
    }

    public getCancelBookingList(request: IMainFiltering): Observable<Response<PagingResponse<ManuallyCancelTransaction>>> {
        return this.httpClient.get<Response<PagingResponse<ManuallyCancelTransaction>>>(`${this.baseUrl}/cancel-bookings`, {
            params: request as any,
        });
    }

    public getChargingBookingDetail(id: string): Observable<Response<PagingResponse<ManuallyCancelTransaction>>> {
        return this.httpClient.get<Response<PagingResponse<ManuallyCancelTransaction>>>(`${this.baseUrl}/detail?id=${id}`);
    }
}
