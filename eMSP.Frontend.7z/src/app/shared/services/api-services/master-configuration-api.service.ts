import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';
import { LookupItem } from '../../shared.model';
import { UIConfiguration } from '../../models/master-configuration.model';

@Injectable({
    providedIn: 'root',
})
export class MasterConfigurationApiService {
    private baseUrl: string;
    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/system/user-permissions`;
    }

    public getUserInterfaceConfigurations(): Observable<Response<UIConfiguration>> {
        return this.httpClient.get<Response<UIConfiguration>>(`${this.baseUrl}/ui-configurations`);
    }

    public find(request: LookupItem): Observable<Response<UIConfiguration>> {
        return this.httpClient.post<Response<UIConfiguration>>(`${this.baseUrl}/find-execution-context`, request, {});
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<UIConfiguration>>> {
        return this.httpClient.get<Response<PagingResponse<UIConfiguration>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }
}
