import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserPermission } from '../../models/user-permission.model';
import { ICreateUserPermissionReq, ISaveJwtToCookieReq, IUpdateUserPermissionReq } from '../../interfaces/user-permission-req.interface';
import { ExecutionContext } from '../../models/execution-context';
import { IAppPermissionsViewModel } from '../../view-models/app-permissions.viewModel';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class UserPermissionApiService {
    private baseUrl: string;

    constructor(private readonly httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/system/user-permissions`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<UserPermission>>> {
        return this.httpClient.get<Response<PagingResponse<UserPermission>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public create(request: ICreateUserPermissionReq): Observable<Response<UserPermission>> {
        return this.httpClient.post<Response<UserPermission>>(`${this.baseUrl}/create`, request, {});
    }

    public update(request: IUpdateUserPermissionReq): Observable<Response<UserPermission>> {
        return this.httpClient.put<Response<UserPermission>>(`${this.baseUrl}/update`, request, {});
    }

    public delete(ids: string): Observable<Response<boolean>> {
        return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?id=${ids}`, {});
    }

    public findExecutionContext(): Observable<Response<ExecutionContext>> {
        return this.httpClient.get<Response<ExecutionContext>>(`${this.baseUrl}/find-execution-context`);
    }

    public getAllPermissions(): Observable<IAppPermissionsViewModel[]> {
        return this.httpClient.get<IAppPermissionsViewModel[]>(`${this.baseUrl}/get-all-permissions`);
    }

    public saveJwtToCookie(request: ISaveJwtToCookieReq): Observable<void> {
        return this.httpClient.post<void>(`${this.baseUrl}/save-jwt-to-cookie`, request, {});
    }
}
