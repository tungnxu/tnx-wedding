import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { IFilterChangePackageManual, IUpdatePackageTypeRQ } from '../../interfaces/operator-change-battery-subscription-rq.interface';
import { IChangeWhiteListStatusRQ, ICreateWhiteListRQ } from '../../interfaces/white-list-configuration-req.interface';
import { WhiteListBatterySubscription } from '../../models/battery-subscription.model';
import { OperatorBatteryPackage } from '../../models/operator.model';
import { PagingResponse, Response } from '../../models/response.model';

@Injectable({
    providedIn: 'root',
})
export class OperatorApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/operation`;
    }

    public searchChangePackage(request: IFilterChangePackageManual): Observable<any> {
        return this.httpClient.get<Response<PagingResponse<OperatorBatteryPackage>>>(`${this.baseUrl}/search-change-package`, {
            params: request as any,
        });
    }

    public getSubscription(vehicleID: string): Observable<Response<WhiteListBatterySubscription>> {
        return this.httpClient.get<Response<WhiteListBatterySubscription>>(`${this.baseUrl}/get-subscription/${vehicleID}`);
    }

    public updatePackageType(request: IUpdatePackageTypeRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/update-package-type`, request);
    }

    public whiteListSearch(request: IMainFiltering): Observable<Response<PagingResponse<any>>> {
        return this.httpClient.get<Response<PagingResponse<any>>>(`${this.baseUrl}/whitelist`, {
            params: request as any,
        });
    }

    public whiteListSocCreate(request: ICreateWhiteListRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/whitelist-soc-create`, request);
    }
    public whiteListChargingCreate(request: ICreateWhiteListRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/whitelist-charging-create`, request);
    }

    public whiteListChangeStatus(request: IChangeWhiteListStatusRQ): Observable<Response<any>> {
        return this.httpClient.post<Response<any>>(`${this.baseUrl}/whitelist-change-status`, request);
    }
}
