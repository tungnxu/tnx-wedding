import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import {
    ICalculateRenewReq,
    ICreateBatterySubscriptionReq,
    IFindCustomerReq,
    ILiquidateBatterySubscriptionReq,
    IPayBatterySubscriptionReq,
    IRegisterToChangeBatterySubscriptionPackageReq,
    ISuspendBatterySubscriptionReq,
    ISwapOwnerBatterySubscriptionReq,
} from '../../interfaces/battery-subscription-req.interface';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { BatterySubscriptionHistory } from '../../models/battery-subscription-history.model';
import { BatterySubscription, BatterySubscriptionDetail } from '../../models/battery-subscription.model';
import { Customer } from '../../models/customer.model';
import { environment } from '../../../../environments/environment';
import { CalculateRenewViewModel } from '../../view-models/calculate-renew.viewModel';
import { PagingResponse, Response } from '../../models/response.model';
import { BatterySubscriptionPackage } from '../../models/battery-subscription-package.model';
import { IBatterySubscriptionPackageChangeReq, IBatterySubscriptionPackageGetReq } from '../../interfaces/battery-subscription-package-req.interface';
import { BatteryProblem } from '../../models/battery-problem.model';

@Injectable({
    providedIn: 'root',
})
export class BatterySubscriptionApiService {
    private baseApiUrl = `${environment.apiUrl}/batteries/subscriptions/`;

    constructor(private readonly httpClient: HttpClient) {}

    public search(req: IMainFiltering): Observable<Response<PagingResponse<BatterySubscription>>> {
        return this.httpClient.get<Response<PagingResponse<BatterySubscription>>>(`${this.baseApiUrl}search`, {
            params: req as any,
        });
    }

    public findCustomerFromOneProfile(req: IFindCustomerReq): Observable<Customer> {
        return this.httpClient.get<Customer>(`${this.baseApiUrl}find-customer-from-one-profile`, {
            params: req as any,
        });
    }

    public findByCustomerInfo(req: IFindCustomerReq): Observable<Customer> {
        return this.httpClient.get<Customer>(`${this.baseApiUrl}find-by-customer-info`, {
            params: req as any,
        });
    }

    public retrieve(id: string): Observable<Response<BatterySubscriptionDetail>> {
        return this.httpClient.get<Response<BatterySubscriptionDetail>>(`${this.baseApiUrl}retrieve/${id}`);
    }

    public pay(req: IPayBatterySubscriptionReq): Observable<Response<BatterySubscription>> {
        return this.httpClient.post<Response<BatterySubscription>>(`${this.baseApiUrl}pay`, req);
    }

    public create(req: ICreateBatterySubscriptionReq): Observable<Response<BatterySubscription>> {
        return this.httpClient.post<Response<BatterySubscription>>(`${this.baseApiUrl}create`, req);
    }

    public swapOwner(req: ISwapOwnerBatterySubscriptionReq): Observable<Response<BatterySubscription>> {
        return this.httpClient.post<Response<BatterySubscription>>(`${this.baseApiUrl}swap-owner`, req);
    }

    public suspend(req: ISuspendBatterySubscriptionReq): Observable<Response<BatterySubscriptionHistory>> {
        return this.httpClient.post<Response<BatterySubscriptionHistory>>(`${this.baseApiUrl}suspend`, req);
    }

    public registerToChangeBatterySubscriptionPackage(
        req: IRegisterToChangeBatterySubscriptionPackageReq
    ): Observable<Response<BatterySubscriptionHistory>> {
        return this.httpClient.post<Response<BatterySubscriptionHistory>>(`${this.baseApiUrl}register-to-change-battery-subscription-package`, req);
    }

    public liquidate(req: ILiquidateBatterySubscriptionReq): Observable<Response<BatterySubscription>> {
        return this.httpClient.post<Response<BatterySubscription>>(`${this.baseApiUrl}liquidate`, req);
    }

    public findDraftById(id: string): Observable<Response<BatterySubscription>> {
        return this.httpClient.get<Response<BatterySubscription>>(`${this.baseApiUrl}find-draft/${id}`);
    }

    public reactivate(id: string): Observable<Response<BatterySubscriptionHistory>> {
        return this.httpClient.post<Response<BatterySubscriptionHistory>>(`${this.baseApiUrl}reactivate/${id}`, {});
    }

    public active(id: string): Observable<Response<BatterySubscription>> {
        return this.httpClient.put<Response<BatterySubscription>>(`${this.baseApiUrl}active/${id}`, {});
    }

    public calculateRenew(req: ICalculateRenewReq): Observable<Response<CalculateRenewViewModel>> {
        return this.httpClient.post<Response<CalculateRenewViewModel>>(`${this.baseApiUrl}calculate-renew`, req);
    }

    public searchPackage(req: IBatterySubscriptionPackageGetReq): Observable<Response<BatterySubscriptionPackage>> {
        return this.httpClient.get<Response<BatterySubscriptionPackage>>(`${this.baseApiUrl}packages`, {
            params: req as any,
        });
    }

    public changePackage(req: IBatterySubscriptionPackageChangeReq): Observable<Response<BatterySubscriptionPackage>> {
        return this.httpClient.post<Response<BatterySubscriptionPackage>>(`${this.baseApiUrl}request-package`, req);
    }

    public getBatteryProblem(): Observable<Response<BatteryProblem[]>> {
        return this.httpClient.get<Response<BatteryProblem[]>>(`${this.baseApiUrl}battery-problem`, {});
    }
}
