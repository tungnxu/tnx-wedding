import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IBatterySubscriptionPackageEditReq } from '../../interfaces/battery-subscription-package-req.interface';
import { environment } from '../../../../environments/environment';
import { PagingResponse, Response } from '../../models/response.model';
import { BatterySubscriptionPackage } from '../../models/battery-subscription-package.model';

@Injectable({
    providedIn: 'root',
})
export class BatterySubscriptionPackageApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/battery/packages`;
    }

    public search(request: IMainFiltering): Observable<Response<PagingResponse<BatterySubscriptionPackage>>> {
        return this.httpClient.get<Response<PagingResponse<BatterySubscriptionPackage>>>(`${this.baseUrl}/search`, {
            params: request as any,
        });
    }

    public getVehicles(req?: IMainFiltering): Observable<Response<PagingResponse<string>>> {
        return this.httpClient.get<Response<PagingResponse<string>>>(`${this.baseUrl}/vehicles`, {
            params: req as any,
        });
    }

    public create(request: IBatterySubscriptionPackageEditReq): Observable<Response<IBatterySubscriptionPackageEditReq>> {
        return this.httpClient.post<Response<IBatterySubscriptionPackageEditReq>>(`${this.baseUrl}/create`, request);
    }

    public update(request: IBatterySubscriptionPackageEditReq): Observable<Response<IBatterySubscriptionPackageEditReq>> {
        return this.httpClient.post<Response<IBatterySubscriptionPackageEditReq>>(`${this.baseUrl}/update/${request.id}`, request);
    }
    public getVehiclesByType(type: number): Observable<Response<PagingResponse<string>>> {
        return this.httpClient.get<Response<PagingResponse<string>>>(`${environment.apiUrl}/vehicles?type=${type}`);
    }

    // public delete(ids: string[]): Observable<Response<boolean>> {
    //     return this.httpClient.delete<Response<boolean>>(`${this.baseUrl}/delete?ids=${ids}`);
    // }
}
