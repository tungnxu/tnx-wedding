import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IMainFiltering } from '../../interfaces/main-filtering.interface';
import { Bill } from '../../models/bill.model';
import { IBillReportByCustomerResponse } from '../../interfaces/bill-report-by-customer-resp.interface';
import { ICustomerBalanceReq } from '../../interfaces/customer-balance-req.interface';
import { IPayBillReq } from '../../interfaces/bill-req.interface';
import { Showroom } from '../../models/showroom.model';
import { environment } from '../../../../environments/environment';
import { IInvoiceRegisterSearchRequest } from '../../interfaces/invoice-register-req.interface';
import { InvoiceRegister } from '../../models/invoice-register.model';
import { PagingResponse, Response } from '../../models/response.model';
import { IBillsForLiquidationReq } from '../../interfaces/bills-for-liquidation-req.interface';
import { BillsForLiquidationDto } from '../../models/bills-for-liquidation-dto.model';

@Injectable({
    providedIn: 'root',
})
export class BillApiService {
    private baseUrl: string;

    constructor(private httpClient: HttpClient) {
        this.baseUrl = `${environment.apiUrl}/bills/`;
    }

    public getBillList(request: IMainFiltering): Observable<Response<PagingResponse<Bill>>> {
        return this.httpClient.get<Response<PagingResponse<Bill>>>(`${this.baseUrl}`, {
            params: request as any,
        });
    }

    public getBillsByCustomerId(request: IMainFiltering): Observable<Response<PagingResponse<Bill>>> {
        return this.httpClient.get<Response<PagingResponse<Bill>>>(`${this.baseUrl}get-bills-by-customer-id`, {
            params: request as any,
        });
    }

    public getDeptBillsByCustomerId(request: IMainFiltering): Observable<Response<PagingResponse<Bill>>> {
        return this.httpClient.get<Response<PagingResponse<Bill>>>(`${this.baseUrl}get-debt-bills-by-customer-id`, {
            params: request as any,
        });
    }

    public getCustomerBills(request: IMainFiltering): Observable<Response<PagingResponse<IBillReportByCustomerResponse>>> {
        return this.httpClient.get<Response<PagingResponse<IBillReportByCustomerResponse>>>(`${this.baseUrl}get-customer-bills`, {
            params: request as any,
        });
    }

    public pay(req: IPayBillReq): Observable<Response<boolean>> {
        return this.httpClient.post<Response<boolean>>(`${this.baseUrl}pay`, req);
    }

    public getCustomerBalance(request: ICustomerBalanceReq): Observable<Response<number>> {
        return this.httpClient.get<Response<number>>(`${this.baseUrl}get-customer-balance`, {
            params: request as any,
        });
    }

    public seachShowroom(request: string): Observable<Showroom[]> {
        return this.httpClient.get<Showroom[]>(`${this.baseUrl}search-showroom`, {
            params: { searchText: request } as any,
        });
    }

    public searchCustomerInvoice(request: IInvoiceRegisterSearchRequest): Observable<Response<InvoiceRegister>> {
        return this.httpClient.get<Response<InvoiceRegister>>(`${this.baseUrl}customer-invoice`, {
            params: request as any,
        });
    }

    public getBillsForLiquidationDto(request: IBillsForLiquidationReq): Observable<Response<BillsForLiquidationDto>> {
        return this.httpClient.get<Response<BillsForLiquidationDto>>(`${this.baseUrl}get-bills-for-liquidation`, {
            params: request as any,
        });
    }
}
