import { IModalConfiguration } from './../interfaces/modal-configuration.interface';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { Injectable } from '@angular/core';
import { ModalComponent } from '../components/modal/modal.component';
import { IConfirmOptions } from '../interfaces/confirm-options.interface';
import { Observable } from 'rxjs';
import { ConfirmComponent } from '../components/confirm/confirm.component';

@Injectable({
    providedIn: 'root',
})
export class ModalService {
    constructor(private readonly bsModalService: BsModalService) {}

    public openModal(configuration: IModalConfiguration, options?: ModalOptions): BsModalRef {
        const bsModalRef = this.bsModalService.show(ModalComponent, options);
        bsModalRef.content.config = configuration;
        return bsModalRef;
    }

    public confirm(options: IConfirmOptions): Observable<any | boolean> {
        return new Observable((obs) => {
            this.openModal(
                {
                    title: options.title || '',
                    component: ConfirmComponent,
                    inputs: [
                        {
                            key: 'options',
                            value: options,
                        },
                    ],
                    onSubmit: (val) => {
                        obs.next(val || true);
                        obs.complete();
                    },
                    onClose: (value) => {
                        obs.next(value || false);
                        obs.complete();
                    },
                    onModalClose: () => obs.complete(),
                },
                {
                    class: 'modal-confirm',
                    ignoreBackdropClick: options.ignoreBackdropClick,
                }
            );
        });
    }
}
